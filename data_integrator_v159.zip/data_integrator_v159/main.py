"""
main.py
-------
Point d'entree de Data Integrator (chargement de donnees ICI Assurance).

Lancement :
    py -m pip install -r requirements.txt
    py main.py

Prerequis systeme : Microsoft ODBC Driver 17 ou 18 for SQL Server.
"""

import sys
import traceback

from PySide6.QtWidgets import QApplication, QDialog, QMessageBox

from core.log_manager import setup_logging, get_logger
from core.auth_config import AuthConfigManager
from ui.login_dialog import LoginDialog
from ui.main_window import MainWindow
from ui.theme import THEME_QSS


class SafeApplication(QApplication):
    """
    QApplication qui intercepte TOUTE exception survenant pendant le
    traitement d'un evenement Qt (clic sur un bouton, changement de
    selection, tout ce qui passe par un signal/slot connecte quelque part
    dans l'IHM).

    C'est necessaire car sys.excepthook (voir install_global_exception_hook)
    ne suffit pas dans un contexte PySide6 : une exception Python levee a
    l'interieur d'un slot appele depuis le code C++ de Qt peut faire planter
    l'application entiere avant meme que sys.excepthook n'ait l'occasion de
    s'en occuper correctement, car Qt ne sait pas gerer une exception Python
    qui remonte a travers sa pile d'appels C++.

    En surchargeant notify() — le point de passage UNIQUE par lequel Qt
    distribue tous les evenements — on attrape ici toute exception avant
    qu'elle n'atteigne ce point fragile, on la journalise, on informe
    l'utilisateur, et l'application continue de tourner normalement.
    """

    def notify(self, receiver, event) -> bool:
        try:
            return super().notify(receiver, event)
        except Exception as e:
            tb_text = traceback.format_exc()
            try:
                get_logger().error("Exception non geree pendant le traitement d'un evenement Qt :\n%s", tb_text)
            except Exception:
                pass
            try:
                QMessageBox.critical(
                    None,
                    "Erreur inattendue",
                    "Une erreur inattendue s'est produite pendant une action. Elle a ete "
                    "enregistree dans le journal (logs/app.log).\n\nL'application reste ouverte.\n\n"
                    f"Detail : {e}",
                )
            except Exception:
                pass
            return False


def install_global_exception_hook():
    """
    Filet de securite applicatif : toute exception non geree (dans le thread
    principal ou dans un slot Qt) est journalisee et affichee dans une boite
    de dialogue au lieu de faire planter/fermer l'application silencieusement.
    """
    logger = get_logger()

    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return

        tb_text = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
        logger.error("Exception non geree :\n%s", tb_text)

        try:
            QMessageBox.critical(
                None,
                "Erreur inattendue",
                "Une erreur inattendue s'est produite. Elle a ete enregistree dans le "
                f"journal (logs/app.log).\n\nL'application reste ouverte.\n\nDetail : {exc_value}",
            )
        except Exception:
            pass  # si meme l'affichage de l'erreur echoue, on ne relance surtout pas

    sys.excepthook = handle_exception


def install_thread_safety_net(app: QApplication):
    """
    Filet de securite final contre l'avertissement/plantage "QThread:
    Destroyed while thread is still running" : quel que soit le chemin qui
    a mene a la fermeture de l'application (fenetre principale fermee,
    dialogue ferme en plein calcul, etc.), on attend/arrete proprement tout
    thread encore actif juste avant que Qt ne detruise reellement les objets.
    """
    from core.thread_registry import wait_for_all
    from core.log_manager import get_logger

    def on_about_to_quit():
        get_logger().info("Fermeture de l'application : verification des threads encore actifs...")
        wait_for_all(timeout_ms=5000)

    app.aboutToQuit.connect(on_about_to_quit)


def main():
    setup_logging()  # doit etre appele avant toute autre initialisation
    install_global_exception_hook()
    app = SafeApplication(sys.argv)
    app.setApplicationName("Data Integrator")
    app.setStyleSheet(THEME_QSS)
    install_thread_safety_net(app)

    # Authentification centralisee (V148) : tant qu'elle n'a pas ete
    # explicitement activee par un administrateur (ecran "Authentification"),
    # l'application se lance normalement, sans ecran de connexion.
    current_user = None
    auth_config_manager = AuthConfigManager()
    if auth_config_manager.config.active:
        login_dialog = LoginDialog(auth_config_manager.config)
        if login_dialog.exec() != QDialog.DialogCode.Accepted:
            get_logger().info("Connexion annulee : fermeture de l'application.")
            sys.exit(0)
        current_user = login_dialog.authenticated_user
        get_logger().info("Connexion reussie : %s %s (%s)", current_user.prenom, current_user.nom, current_user.login)

    window = MainWindow(current_user=current_user)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

from __future__ import annotations

import re
import unicodedata

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QComboBox, QPushButton,
    QTableWidget, QTableWidgetItem, QLabel, QCheckBox, QMessageBox,
    QHeaderView, QInputDialog, QMenu, QDialog, QLineEdit, QAbstractItemView,
    QPlainTextEdit, QFileDialog
)

from core.config_manager import ConfigManager, DOMAINES, EXPECTED_DATABASE
from core.merge_config import MergeConfigManager, MatchingRule
from core.merge_engine import run_merge, detect_new_values
from core.db import build_engine
from core.target_schemas import TargetSchemaManager
from core.log_manager import default_log_cb as _default_log_cb
from ui.elevation import apply_card_elevation
from ui.table_picker_dialog import TablePickerDialog
from ui.value_alias_dialog import ValueAliasManagerDialog

DOMAIN_LABELS = {"Adhesion": "Adhésion", "Sinistre": "Sinistre", "FIC": "FIC", "Reclamation": "Réclamation"}

IGNORE = "<ignore>"


class NoScrollComboBox(QComboBox):
    """
    V131, suite a un signalement utilisateur (grille de mapping "trop
    sensible au mouvement de la souris") : par defaut, QComboBox capte
    l'evenement de molette meme sans avoir le focus (sans avoir ete
    cliquee) — des qu'on fait defiler la grande grille de mapping et que
    le curseur passe au-dessus de n'importe laquelle des nombreuses
    cellules a menu deroulant, la valeur de CETTE cellule change
    silencieusement au lieu de faire defiler la page. Cette sous-classe
    ignore la molette tant que le menu n'a pas explicitement le focus
    (apres un clic) — la molette fait alors defiler normalement la
    grille, jamais une valeur au simple survol.
    """

    def wheelEvent(self, event):
        if self.hasFocus():
            super().wheelEvent(event)
        else:
            event.ignore()


def _normalize(name: str) -> str:
    """Normalisation pour l'association automatique : insensible a la casse,
    aux espaces, accents/caracteres speciaux et separateurs. Les caracteres
    accentues sont translitteres vers leur equivalent sans accent (e.g. 'é'
    -> 'e') plutot que simplement retires, sans quoi 'numéropolice' et
    'numeropolice' ne se reconnaitraient pas comme identiques."""
    sans_accents = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]", "", sans_accents.lower())


class AliasManagerDialog(QDialog):
    """
    Dialogue de gestion du dictionnaire de correspondances EN/FR (V76),
    alimente progressivement par l'utilisateur : chaque paire (nom source,
    colonne cible reelle) permet a l'association automatique de reconnaitre
    une colonne dont le nom n'a rien de commun avec la colonne cible apres
    normalisation (ex: 'police_number' -> 'Numéro_Police')."""

    def __init__(self, alias_manager, cibles_possibles: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Dictionnaire de correspondances (EN/FR, etc.)")
        self.setMinimumSize(560, 420)
        self.alias_manager = alias_manager
        self.cibles_possibles = cibles_possibles

        layout = QVBoxLayout()
        info = QLabel(
            "Alimente progressivement les correspondances entre un nom de colonne source "
            "(ex: \u00abpolice_number\u00bb) et le nom exact de la colonne cible reelle (ex: \u00abNuméro_Police\u00bb), "
            "utilisees automatiquement des le prochain ajout de table au mapping."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#5c6577; font-style:italic;")
        layout.addWidget(info)

        self.propositions_group = QGroupBox("💡 Suggestions a verifier (jamais utilisees tant que non acceptees)")
        prop_layout = QVBoxLayout(self.propositions_group)
        prop_info = QLabel(
            "Correspondances devinees par deduction semantique, sans confirmation directe — a verifier "
            "toi-meme (ex: en consultant un vrai fichier source) avant d'accepter, pour ne jamais risquer "
            "de fausser un mapping sur une simple supposition."
        )
        prop_info.setWordWrap(True)
        prop_info.setStyleSheet("color:#8a6d00; font-style:italic;")
        prop_layout.addWidget(prop_info)

        self.propositions_table = QTableWidget(0, 2)
        self.propositions_table.setHorizontalHeaderLabels(["Nom source suggere", "Colonne cible proposee"])
        self.propositions_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.propositions_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.propositions_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.propositions_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.propositions_table.setMaximumHeight(160)
        prop_layout.addWidget(self.propositions_table)

        prop_btn_row = QHBoxLayout()
        accept_btn = QPushButton("✅ Accepter la selection")
        accept_btn.clicked.connect(self._on_accept_proposition)
        reject_btn = QPushButton("❌ Rejeter la selection")
        reject_btn.clicked.connect(self._on_reject_proposition)
        prop_btn_row.addWidget(accept_btn)
        prop_btn_row.addWidget(reject_btn)
        prop_btn_row.addStretch()
        prop_layout.addLayout(prop_btn_row)
        layout.addWidget(self.propositions_group)

        confirmed_label = QLabel("✅ Correspondances confirmees (utilisees par l'association automatique) :")
        confirmed_label.setStyleSheet("font-weight:600;")
        layout.addWidget(confirmed_label)

        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Nom source (alias)", "Colonne cible reelle"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        layout.addWidget(self.table)

        add_row = QHBoxLayout()
        self.alias_edit = QLineEdit()
        self.alias_edit.setPlaceholderText("Nom source, ex: police_number")
        self.cible_edit = QComboBox()
        self.cible_edit.setEditable(True)
        self.cible_edit.addItems(self.cibles_possibles)
        self.cible_edit.setCurrentText("")
        add_btn = QPushButton("➕ Ajouter")
        add_btn.clicked.connect(self._on_add)
        add_row.addWidget(self.alias_edit, stretch=1)
        add_row.addWidget(QLabel("→"))
        add_row.addWidget(self.cible_edit, stretch=1)
        add_row.addWidget(add_btn)
        layout.addLayout(add_row)

        btn_row = QHBoxLayout()
        remove_btn = QPushButton("🗑️ Supprimer la ligne selectionnee")
        remove_btn.clicked.connect(self._on_remove)
        close_btn = QPushButton("Fermer")
        close_btn.setObjectName("primaryBtn")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(remove_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

        self.setLayout(layout)
        self._refresh_table()
        self._refresh_propositions_table()

    def _refresh_table(self):
        self.table.setRowCount(len(self.alias_manager.aliases))
        for row, a in enumerate(self.alias_manager.aliases):
            self.table.setItem(row, 0, QTableWidgetItem(a.alias))
            self.table.setItem(row, 1, QTableWidgetItem(a.cible))

    def _refresh_propositions_table(self):
        self.propositions_table.setRowCount(len(self.alias_manager.propositions))
        for row, p in enumerate(self.alias_manager.propositions):
            self.propositions_table.setItem(row, 0, QTableWidgetItem(p.alias))
            self.propositions_table.setItem(row, 1, QTableWidgetItem(p.cible))
        self.propositions_group.setVisible(bool(self.alias_manager.propositions))

    def _on_accept_proposition(self):
        row = self.propositions_table.currentRow()
        if row < 0:
            return
        alias = self.propositions_table.item(row, 0).text()
        self.alias_manager.accept_proposition(alias)
        self._refresh_propositions_table()
        self._refresh_table()

    def _on_reject_proposition(self):
        row = self.propositions_table.currentRow()
        if row < 0:
            return
        alias = self.propositions_table.item(row, 0).text()
        self.alias_manager.reject_proposition(alias)
        self._refresh_propositions_table()

    def _on_add(self):
        alias = self.alias_edit.text().strip()
        cible = self.cible_edit.currentText().strip()
        if not alias or not cible:
            QMessageBox.information(self, "Champs requis", "Renseigne le nom source et la colonne cible.")
            return
        self.alias_manager.add(alias, cible)
        self.alias_edit.clear()
        self._refresh_table()

    def _on_remove(self):
        row = self.table.currentRow()
        if row < 0:
            return
        alias = self.table.item(row, 0).text()
        self.alias_manager.remove(alias)
        self._refresh_table()


class SchemaEditorDialog(QDialog):
    """
    Dialogue permettant de modifier/charger la structure cible d'un domaine
    directement en collant une requete SQL SELECT ... FROM (V78) — plutot
    que de necessiter une modification du code a chaque evolution de la
    vraie table de destination."""

    def __init__(self, schema_manager, domaine_par_defaut: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Modifier la structure cible depuis une requete SQL")
        self.setMinimumSize(640, 520)
        self.schema_manager = schema_manager
        self._colonnes_analysees: list[str] = []

        layout = QVBoxLayout()

        info = QLabel(
            "Colle ci-dessous une requete SQL Server de la forme \u00abSELECT [Colonne1], [Colonne2], ... FROM [Table]\u00bb "
            "(ex: genere par \u00abScript Table as SELECT\u00bb dans SSMS). Les colonnes cible du domaine choisi seront "
            "entierement remplacees par celles extraites de cette requete, dans le meme ordre."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#5c6577; font-style:italic;")
        layout.addWidget(info)

        domain_row = QHBoxLayout()
        domain_row.addWidget(QLabel("Domaine concerne :"))
        self.domain_combo = QComboBox()
        for d in DOMAINES:
            self.domain_combo.addItem(DOMAIN_LABELS.get(d, d), d)
        idx = self.domain_combo.findData(domaine_par_defaut)
        if idx >= 0:
            self.domain_combo.setCurrentIndex(idx)
        domain_row.addWidget(self.domain_combo)
        domain_row.addStretch()
        layout.addLayout(domain_row)

        self.sql_edit = QPlainTextEdit()
        self.sql_edit.setPlaceholderText(
            "SELECT  [ID_Adhesion]\n      ,[Numéro_Police]\n      ,[Libellé_Distributeur]\n      ...\n  FROM [TECH_BI].[dbo].[SRC_Adhesion_Transforme_Contenu]"
        )
        self.sql_edit.setFont(QFont("Consolas", 9))
        layout.addWidget(self.sql_edit, stretch=1)

        analyze_btn = QPushButton("🔍 Analyser la requete")
        analyze_btn.clicked.connect(self._on_analyze)
        layout.addWidget(analyze_btn)

        self.preview_label = QLabel("")
        self.preview_label.setWordWrap(True)
        self.preview_label.setStyleSheet("color:#1a8f4c; font-weight:600;")
        layout.addWidget(self.preview_label)

        self.preview_list = QTableWidget(0, 1)
        self.preview_list.setHorizontalHeaderLabels(["Colonnes extraites (dans l'ordre)"])
        self.preview_list.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.preview_list.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.preview_list.verticalHeader().setVisible(False)
        self.preview_list.setMaximumHeight(180)
        layout.addWidget(self.preview_list)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Annuler")
        cancel_btn.clicked.connect(self.reject)
        self.apply_btn = QPushButton("✅ Appliquer cette structure")
        self.apply_btn.setObjectName("primaryBtn")
        self.apply_btn.setEnabled(False)
        self.apply_btn.clicked.connect(self._on_apply)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(self.apply_btn)
        layout.addLayout(btn_row)

        self.setLayout(layout)

    def _on_analyze(self):
        from core.target_schemas import parse_sql_select_columns
        try:
            colonnes = parse_sql_select_columns(self.sql_edit.toPlainText())
        except ValueError as e:
            QMessageBox.warning(self, "Analyse impossible", str(e))
            self.preview_label.setText("")
            self.preview_list.setRowCount(0)
            self.apply_btn.setEnabled(False)
            return

        self._colonnes_analysees = colonnes
        self.preview_label.setText(f"✅ {len(colonnes)} colonne(s) reconnue(s), dans l'ordre.")
        self.preview_list.setRowCount(len(colonnes))
        for i, col in enumerate(colonnes):
            self.preview_list.setItem(i, 0, QTableWidgetItem(col))
        self.apply_btn.setEnabled(True)

    def _on_apply(self):
        if not self._colonnes_analysees:
            return
        domaine = self.domain_combo.currentData()
        confirm = QMessageBox.question(
            self, "Confirmer le remplacement",
            f"Remplacer entierement la structure cible de {self.domain_combo.currentText()} par ces "
            f"{len(self._colonnes_analysees)} colonne(s) ? Toute correspondance de mapping deja enregistree "
            "vers une colonne qui disparaitrait de la nouvelle structure sera perdue.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return
        self.schema_manager.set_schema(domaine, self._colonnes_analysees)
        self.accept()


class FusionTab(QWidget):
    """
    Onglet de fusion, organise comme l'ecran "Union All Transformation" de
    SSIS : une grille pivot avec une LIGNE par colonne cible (colonne de
    sortie) et une COLONNE par table source ajoutee au mapping (portant le
    nom de sa table). Chaque cellule indique le nom de la colonne dans cette
    table source pour cette colonne cible, ou <ignore> si cette table n'a pas
    d'equivalent. Tout est directement editable dans la grille ; ajouter une
    nouvelle table source ajoute une colonne et tente une association
    automatique par nom sur les colonnes cible deja connues (les colonnes non
    reconnues deviennent de nouvelles lignes).
    """

    def __init__(self, config: ConfigManager, log_cb=None, parent=None):
        super().__init__(parent)
        self.config = config
        self.log_cb = log_cb or _default_log_cb
        self.merge_config = MergeConfigManager(log_cb=self.log_cb)
        self.schema_manager = TargetSchemaManager(log_cb=self.log_cb)
        from core.column_aliases import ColumnAliasManager
        self.alias_manager = ColumnAliasManager(log_cb=self.log_cb)
        from core.value_aliases import ValueAliasManager
        self.value_alias_manager = ValueAliasManager(log_cb=self.log_cb)

        self._table_columns_cache: dict[str, list[str]] = {}
        self._pivot_table_keys: list[tuple[str, str]] = []
        self._pivot_targets: list[str] = []
        self._extra_empty_targets: list[str] = []
        self._loading = False
        self._dirty = False
        self._current_loaded_domain = None
        # V150 : boutons qui ECRIVENT une configuration partagee
        # (target_schemas.json, column_aliases.json, matching.json) ou
        # lancent la fusion reelle (ecriture en base) — grises pour un
        # utilisateur dont le role n'est pas Administrateur, via
        # set_read_only(). Les actions purement consultatives (precharger,
        # charger la structure, exporter) restent toujours disponibles.
        self._write_buttons: list[QPushButton] = []

        layout = QVBoxLayout(self)

        header_row = QHBoxLayout()
        header_row.addWidget(QLabel("Domaine :"))
        self.domain_combo = QComboBox()
        for d in DOMAINES:
            self.domain_combo.addItem(DOMAIN_LABELS.get(d, d), d)
        self.domain_combo.currentIndexChanged.connect(self._on_domain_changed)
        header_row.addWidget(self.domain_combo)
        header_row.addStretch()
        layout.addLayout(header_row)

        pivot_group = QGroupBox("🔀  Mapping des colonnes (une ligne par colonne cible, une colonne par table source)")
        pivot_layout = QVBoxLayout(pivot_group)

        pivot_info = QLabel(
            "Comme dans SSIS (Union All) : chaque colonne porte le nom de sa table source. "
            "Chaque table ajoutee (1ere ou suivante) tente d'abord une association automatique par nom "
            "(normalise : casse/espaces/accents ignores) avec une ligne cible deja existante ; en cas de "
            "correspondance certaine, la colonne s'y aligne directement. Sinon, elle cree sa propre nouvelle "
            "ligne (visible en \u00ab<ignore>\u00bb pour les autres tables) plutot que d'etre devinee a tort — a verifier "
            "et completer manuellement si besoin (menu deroulant sur la cellule, renommage d'une ligne). "
            "Clic-droit sur un en-tete pour voir les colonnes encore non mappees d'une table, ou pour la "
            "retirer du mapping."
        )
        pivot_info.setWordWrap(True)
        pivot_info.setStyleSheet("color:#5c6577; font-style:italic;")
        pivot_layout.addWidget(pivot_info)

        self.pivot_table = QTableWidget(0, 1)
        self.pivot_table.setHorizontalHeaderLabels(["Colonne cible"])
        self.pivot_table.verticalHeader().setVisible(False)
        self.pivot_table.itemChanged.connect(self._on_target_renamed)
        self.pivot_table.horizontalHeader().setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.pivot_table.horizontalHeader().customContextMenuRequested.connect(self._on_header_context_menu)
        self.pivot_table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.pivot_table.customContextMenuRequested.connect(self._on_cell_context_menu)
        pivot_layout.addWidget(self.pivot_table, stretch=1)

        pivot_btn_row = QHBoxLayout()
        add_table_btn = QPushButton("➕ Ajouter une table au mapping")
        add_table_btn.setObjectName("primaryBtn")
        add_table_btn.clicked.connect(self._add_table_to_pivot)
        self._write_buttons.append(add_table_btn)
        preload_btn = QPushButton("⚡ Precharger les tables deja chargees")
        preload_btn.setObjectName("ghostBtn")
        preload_btn.setToolTip("Ajoute les sources deja configurees dans le Chargement ET deja chargees avec succes au moins une fois, pas encore presentes dans le mapping")
        preload_btn.clicked.connect(lambda: self._preload_all_tables(uniquement_deja_chargees=True))
        preload_all_btn = QPushButton("🌐 Precharger TOUT")
        preload_all_btn.setObjectName("ghostBtn")
        preload_all_btn.setToolTip("Ajoute TOUTES les sources configurees dans le Chargement pour ce domaine, meme celles jamais chargees en base (tentative de lecture des colonnes, ignorees si echec)")
        preload_all_btn.clicked.connect(lambda: self._preload_all_tables(uniquement_deja_chargees=False))
        load_schema_btn = QPushButton("📋 Charger la structure cible reelle")
        load_schema_btn.setObjectName("ghostBtn")
        load_schema_btn.setToolTip("Recharge les colonnes cible manquantes depuis la structure actuellement enregistree pour ce domaine")
        load_schema_btn.clicked.connect(self._load_real_target_schema)
        edit_schema_btn = QPushButton("📐 Modifier la structure (SQL)")
        edit_schema_btn.setObjectName("ghostBtn")
        edit_schema_btn.setToolTip("Remplacer la structure cible d'un domaine en collant une requete SQL SELECT ... FROM, sans modification du code")
        edit_schema_btn.clicked.connect(self._open_schema_editor)
        self._write_buttons.append(edit_schema_btn)
        alias_btn = QPushButton("🌐 Dictionnaire EN/FR")
        alias_btn.setObjectName("ghostBtn")
        alias_btn.setToolTip("Gerer les correspondances entre un nom de colonne source (ex: police_number) et le nom exact de la colonne cible reelle (ex: Numéro_Police), utilisees par l'association automatique")
        alias_btn.clicked.connect(self._open_alias_manager)
        self._write_buttons.append(alias_btn)
        value_alias_btn = QPushButton("🌍 Référentiel valeurs (pays, etc.)")
        value_alias_btn.setObjectName("ghostBtn")
        value_alias_btn.setToolTip(
            "Harmonise des saisies libres incoherentes pour une colonne cible donnee "
            "(ex: Pays_Client — «Fr»/«FR»/«France» -> «France»), "
            "appliquees automatiquement a la fusion. Inclut une detection des nouvelles valeurs presentes en base."
        )
        value_alias_btn.clicked.connect(self._open_value_alias_manager)
        self._write_buttons.append(value_alias_btn)
        export_excel_btn = QPushButton("📤 Exporter en Excel")
        export_excel_btn.setObjectName("ghostBtn")
        export_excel_btn.setToolTip("Exporte le mapping actuellement affiche (ce domaine) dans un fichier Excel, avec la meme disposition que les documents de reference (une ligne par colonne cible, une colonne par table source)")
        export_excel_btn.clicked.connect(self._export_mapping_to_excel)
        self.save_mapping_btn = QPushButton("💾 Enregistrer le mapping")
        self.save_mapping_btn.setObjectName("primaryBtn")
        self.save_mapping_btn.clicked.connect(self._save_mapping)
        self._write_buttons.append(self.save_mapping_btn)
        self.dirty_label = QLabel("")
        pivot_btn_row.addWidget(add_table_btn)
        pivot_btn_row.addWidget(preload_btn)
        pivot_btn_row.addWidget(preload_all_btn)
        pivot_btn_row.addWidget(load_schema_btn)
        pivot_btn_row.addWidget(edit_schema_btn)
        pivot_btn_row.addWidget(alias_btn)
        pivot_btn_row.addWidget(value_alias_btn)
        pivot_btn_row.addWidget(export_excel_btn)
        pivot_btn_row.addStretch()
        pivot_btn_row.addWidget(self.dirty_label)
        pivot_btn_row.addWidget(self.save_mapping_btn)
        pivot_layout.addLayout(pivot_btn_row)
        layout.addWidget(pivot_group, stretch=3)

        exec_group = QGroupBox("▶️  Execution de la fusion")
        exec_layout = QVBoxLayout(exec_group)

        target_row = QHBoxLayout()
        target_row.addWidget(QLabel("Table de fusion cible :"))
        self.target_combo = QComboBox()
        self.target_combo.setEditable(True)
        target_row.addWidget(self.target_combo, stretch=1)
        refresh_btn = QPushButton("🔄")
        refresh_btn.setFixedWidth(36)
        refresh_btn.clicked.connect(self._refresh_target_tables)
        target_row.addWidget(refresh_btn)
        exec_layout.addLayout(target_row)

        self.vider_checkbox = QCheckBox("Vider la table de fusion avant execution")
        exec_layout.addWidget(self.vider_checkbox)

        run_row = QHBoxLayout()
        self.run_btn = QPushButton("▶  Lancer la fusion pour ce domaine")
        self.run_btn.setObjectName("primaryBtn")
        self.run_btn.clicked.connect(self._run_fusion)
        self._write_buttons.append(self.run_btn)
        self.status_label = QLabel("")
        run_row.addWidget(self.run_btn)
        run_row.addWidget(self.status_label)
        run_row.addStretch()
        exec_layout.addLayout(run_row)

        layout.addWidget(exec_group)

        apply_card_elevation(pivot_group)
        apply_card_elevation(exec_group)

        self._load_domain(DOMAINES[0])

    # ------------------------------------------------------------------

    def _current_domain(self) -> str:
        return self.domain_combo.currentData()

    def _on_domain_changed(self):
        if self._dirty:
            confirm = QMessageBox.question(
                self, "Modifications non enregistrees",
                "Le mapping du domaine actuel a des modifications non enregistrees.\n\n"
                "Enregistrer avant de changer de domaine ?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Save,
            )
            if confirm == QMessageBox.StandardButton.Cancel:
                self.domain_combo.blockSignals(True)
                idx = self.domain_combo.findData(self._current_loaded_domain)
                if idx >= 0:
                    self.domain_combo.setCurrentIndex(idx)
                self.domain_combo.blockSignals(False)
                return
            elif confirm == QMessageBox.StandardButton.Save:
                self._save_mapping()
            else:
                self.merge_config.load()  # annule les modifications en memoire, recharge depuis le disque
                self.log_cb("warning", "Modifications non enregistrees abandonnees.")
        self._load_domain(self._current_domain())

    def _load_domain(self, domaine: str):
        # La structure cible reelle (V74/V77) est TOUJOURS rechargee ici,
        # automatiquement : contrairement aux regles de mapping (persistees
        # dans merge_config.json), la liste des colonnes cible vides restait
        # sinon perdue a chaque redemarrage de l'application (elle n'existait
        # qu'en memoire, le temps de la session). Comme les colonnes cible
        # ne sont pas extensibles (V77), s'assurer qu'elles sont toujours
        # integralement visibles evite qu'une colonne cible reelle encore
        # non mappee ne disparaisse simplement de la vue.
        self._extra_empty_targets = list(self.schema_manager.get_schema(domaine))
        self.target_combo.setEditText(self.merge_config.get_target_table(domaine))
        self.vider_checkbox.setChecked(self.merge_config.get_vider_avant_fusion(domaine))
        self._rebuild_pivot()
        self._current_loaded_domain = domaine
        self._dirty = False
        self._update_dirty_label()
        # Precharge automatiquement, en silence, toutes les sources deja
        # configurees dans le Chargement pour ce domaine (V83) : l'ecran
        # Fusion doit montrer TOUS les TPA par defaut, a l'utilisateur de
        # decocher ceux qui ne doivent pas participer a la fusion — plutot
        # que de les faire apparaitre un par un via un clic manuel. Appele
        # APRES la reinitialisation de l'indicateur "non enregistre", pour
        # que celui-ci reflete correctement un ajout automatique de tables.
        self._preload_all_tables(uniquement_deja_chargees=False, silent=True)
        # V117, sur demande explicite de l'utilisateur : les tables du
        # mapping Fusion doivent correspondre EXACTEMENT aux sources
        # reellement configurees dans le Chargement, ni plus ni moins.
        # Le prechargement ci-dessus AJOUTE les sources manquantes ; ce
        # nettoyage RETIRE a l'inverse toute table du mapping qui ne
        # correspond plus a aucune source actuelle (ancienne table
        # renommee ou supprimee depuis) — evite les doublons/colonnes
        # fantomes qui pouvaient s'accumuler au fil des modifications.
        self._remove_orphaned_mapping_tables()

    # ------------------------------------------------------------------
    # Enregistrement explicite du mapping
    # ------------------------------------------------------------------

    def _mark_dirty(self):
        self._dirty = True
        self._update_dirty_label()

    def _update_dirty_label(self):
        if self._dirty:
            self.dirty_label.setText("●  Modifications non enregistrees")
            self.dirty_label.setStyleSheet("color:#B3261E; font-weight:600;")
        else:
            self.dirty_label.setText("✅  Enregistre")
            self.dirty_label.setStyleSheet("color:#1a8f4c; font-weight:600;")

    def _save_mapping(self):
        self.merge_config.save()
        self._dirty = False
        self._update_dirty_label()
        domaine = self._current_domain()
        self.log_cb("success", f"Mapping enregistre pour le domaine {DOMAIN_LABELS.get(domaine, domaine)}.")

    # ------------------------------------------------------------------
    # Construction / reconstruction de la grille pivot
    # ------------------------------------------------------------------

    def _rebuild_pivot(self):
        domaine = self._current_domain()
        rules = self.merge_config.rules_for_domain(domaine)

        table_keys = list(dict.fromkeys((r.type_tpa, r.table_source) for r in rules if r.type_tpa and r.table_source))
        rule_targets = list(dict.fromkeys(r.colonne_cible for r in rules if r.colonne_cible))

        # V118, suite a un signalement utilisateur (menu deroulant limite a
        # <ignore> + la seule colonne deja choisie, au lieu de proposer
        # toutes les colonnes reelles de la table) : le cache utilise pour
        # remplir ce menu (_table_columns_cache) n'est alimente QUE par une
        # requete SQL en direct (prechargement de cette session). Si une
        # table n'a pas ete rechargee depuis SQL Server dans la session en
        # cours, son cache reste vide — alors meme que le mapping deja
        # ENREGISTRE connait deja, via ses regles existantes, une bonne
        # partie (voire la totalite) des vraies colonnes de cette table.
        # On complete donc systematiquement le cache, pour toute table du
        # mapping, avec l'ensemble des colonnes source deja vues dans ses
        # regles enregistrees — sans jamais ecraser un cache "live" plus
        # recent et potentiellement plus complet issu d'un vrai
        # prechargement SQL de cette session.
        for type_tpa, table_source in table_keys:
            colonnes_connues_du_mapping = sorted({
                r.colonne_source for r in rules
                if r.type_tpa == type_tpa and r.table_source == table_source and r.colonne_source
            })
            cache_existant = set(self._table_columns_cache.get(table_source, []))
            fusion = cache_existant | set(colonnes_connues_du_mapping)
            if fusion != cache_existant:
                self._table_columns_cache[table_source] = sorted(fusion)

        # La structure cible reelle (V74/V77), quand elle existe pour ce
        # domaine, est FIXE et doit toujours primer sur l'ordre dans lequel
        # les regles de mapping ont ete decouvertes (qui depend de l'ordre
        # d'ajout des tables TPA, pas de l'ordre reel de la table de
        # destination) — sans quoi l'affichage se desordonnerait au fil des
        # tables ajoutees.
        schema_order = self.schema_manager.get_schema(domaine)
        if schema_order:
            targets = list(schema_order)
            for t in rule_targets:
                if t not in targets:
                    targets.append(t)
        else:
            targets = rule_targets
        for extra in self._extra_empty_targets:
            if extra not in targets:
                targets.append(extra)

        self._pivot_table_keys = table_keys
        self._pivot_targets = targets

        lookup = {(r.type_tpa, r.table_source, r.colonne_cible): r for r in rules}

        self._loading = True
        self.pivot_table.blockSignals(True)
        self.pivot_table.clear()
        self.pivot_table.setColumnCount(1 + len(table_keys))
        headers = ["Colonne cible"]
        for t, tbl in table_keys:
            total_cols = len(self._table_columns_cache.get(tbl, []))
            mappees = sum(1 for r in rules if r.type_tpa == t and r.table_source == tbl and r.colonne_source and r.colonne_cible)
            compteur = f" ({mappees}/{total_cols})" if total_cols else ""
            headers.append(f"{self._table_header_label(t, tbl, domaine)}{compteur}")
        self.pivot_table.setHorizontalHeaderLabels(headers)
        self.pivot_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.pivot_table.setColumnWidth(0, 200)
        # V116, suite a un signalement utilisateur (texte illisible, coupe) :
        # le mode Stretch divisait la largeur disponible a parts EGALES
        # entre toutes les colonnes TPA, quel que soit leur nombre — avec
        # 11 TPA ou plus, chaque colonne devenait trop etroite pour
        # afficher son contenu. Remplace par une largeur fixe et genereuse
        # (190px, suffisante pour lire un nom de colonne source normal),
        # avec defilement horizontal du tableau plutot que compression :
        # le nombre de TPA affiches n'affecte plus la lisibilite des
        # autres.
        for col in range(1, len(headers)):
            self.pivot_table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.Interactive)
            self.pivot_table.setColumnWidth(col, 260)
        # +1 pour la ligne dediee aux cases "Inclure dans la fusion" (V83),
        # toujours en row 0, avant toutes les lignes de colonnes cible.
        self.pivot_table.setRowCount(len(targets) + 1)
        self.pivot_table.verticalHeader().setDefaultSectionSize(36)

        inclure_label = QTableWidgetItem("☑ Inclure dans la fusion")
        font_label = inclure_label.font()
        font_label.setBold(True)
        inclure_label.setFont(font_label)
        inclure_label.setFlags(inclure_label.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.pivot_table.setItem(0, 0, inclure_label)
        for col, (type_tpa, table_source) in enumerate(table_keys, start=1):
            checkbox = QCheckBox()
            checkbox.setChecked(self.merge_config.is_tpa_inclus(domaine, type_tpa, table_source))
            checkbox.toggled.connect(
                lambda checked, t=type_tpa, tbl=table_source: self._on_tpa_inclus_toggled(t, tbl, checked)
            )
            cell_wrap = QWidget()
            wrap_layout = QHBoxLayout(cell_wrap)
            wrap_layout.addWidget(checkbox)
            wrap_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            wrap_layout.setContentsMargins(0, 0, 0, 0)
            self.pivot_table.setCellWidget(0, col, cell_wrap)

        for target_row, target in enumerate(targets):
            row = target_row + 1  # decale d'une ligne par la ligne de cases a cocher
            target_item = QTableWidgetItem(target)
            font = target_item.font()
            font.setBold(True)
            target_item.setFont(font)
            self.pivot_table.setItem(row, 0, target_item)

            for col, (type_tpa, table_source) in enumerate(table_keys, start=1):
                rule = lookup.get((type_tpa, table_source, target))
                combo = NoScrollComboBox()
                combo.setEditable(True)
                combo.addItem(IGNORE)
                for real_col in self._table_columns_cache.get(table_source, []):
                    if real_col != IGNORE:
                        combo.addItem(real_col)
                current_value = rule.colonne_source if (rule and rule.colonne_source) else IGNORE
                if combo.findText(current_value) < 0 and current_value != IGNORE:
                    combo.addItem(current_value)
                combo.setCurrentText(current_value)
                if current_value == IGNORE:
                    combo.setStyleSheet("color:#B3261E;")
                combo.currentTextChanged.connect(
                    lambda text, r=row, c=col: self._on_pivot_cell_changed(r, c, text)
                )
                combo.setMinimumHeight(30)
                self.pivot_table.setCellWidget(row, col, combo)

        self.pivot_table.blockSignals(False)
        self._loading = False

    def _table_header_label(self, type_tpa: str, table_source: str, domaine: str) -> str:
        """Construit un en-tete de colonne lisible (V83) : privilegie
        \"Type (Pays)\" quand la source correspondante est retrouvee dans le
        Chargement (ex: \u00abSPB (Italie)\u00bb), sinon un nom de table raccourci
        (retire le prefixe commun \u00abdbo.SRC_{Domaine}_Avant_Transformer_\u00bb),
        plutot que d'afficher le nom de table complet, souvent long et
        redondant entre plusieurs TPA du meme type."""
        from core.config_manager import types_avec_plusieurs_pays, label_tpa
        source = next((s for s in self.config.sources if s.domaine == domaine and s.table == table_source), None)
        if source and source.pays:
            types_multi_pays = types_avec_plusieurs_pays(self.config.sources, domaine)
            return label_tpa(type_tpa, source.pays, types_multi_pays)
        prefix = f"dbo.SRC_{domaine}_Avant_Transformer_"
        if table_source.startswith(prefix):
            return f"{type_tpa} — {table_source[len(prefix):]}"
        return f"{type_tpa} — {table_source.split('.')[-1]}"

    def _on_tpa_inclus_toggled(self, type_tpa: str, table_source: str, checked: bool):
        domaine = self._current_domain()
        self.merge_config.set_tpa_inclus(domaine, type_tpa, table_source, checked)
        self.log_cb("info", f"{type_tpa} ({table_source}) {'inclus dans' if checked else 'exclu de'} la fusion {DOMAIN_LABELS.get(domaine, domaine)}.")

    # ------------------------------------------------------------------
    # Edition de la grille
    # ------------------------------------------------------------------

    def _on_pivot_cell_changed(self, row: int, col: int, text: str):
        if self._loading or col == 0:
            return
        domaine = self._current_domain()
        target = self.pivot_table.item(row, 0).text().strip()
        if not target or col - 1 >= len(self._pivot_table_keys):
            return
        type_tpa, table_source = self._pivot_table_keys[col - 1]

        existing = next(
            (r for r in self.merge_config.rules_for_domain(domaine)
             if r.type_tpa == type_tpa and r.table_source == table_source and r.colonne_cible == target),
            None,
        )
        text = text.strip()
        if text == IGNORE or not text:
            if existing:
                self.merge_config.remove_rule(existing.id, persist=False)
                self.log_cb("info", f"Mapping retire : {table_source} / {target}")
                self._mark_dirty()
        else:
            if existing:
                if existing.colonne_source != text:
                    self.merge_config.update_rule(existing.id, persist=False, colonne_source=text)
                    self._mark_dirty()
            else:
                rule = MatchingRule.new(domaine, type_tpa, table_source, text, target)
                self.merge_config.add_rule(rule, persist=False)
                self.log_cb("info", f"Mapping ajoute : {table_source}.{text} -> {target}")
                self._mark_dirty()

        widget = self.pivot_table.cellWidget(row, col)
        if widget:
            widget.setStyleSheet("" if text and text != IGNORE else "color:#B3261E;")

    def _on_target_renamed(self, item: QTableWidgetItem):
        if self._loading or item.column() != 0 or item.row() == 0:
            return  # row 0 = ligne des cases "Inclure dans la fusion", jamais une colonne cible
        row = item.row() - 1  # decalage : row 0 du tableau = ligne des cases a cocher
        if row >= len(self._pivot_targets):
            return
        old_target = self._pivot_targets[row]
        new_target = item.text().strip()
        if not new_target or new_target == old_target:
            self._loading = True
            item.setText(old_target)
            self._loading = False
            return

        domaine = self._current_domain()
        for r in self.merge_config.rules_for_domain(domaine):
            if r.colonne_cible == old_target:
                self.merge_config.update_rule(r.id, persist=False, colonne_cible=new_target)
        if old_target in self._extra_empty_targets:
            self._extra_empty_targets.remove(old_target)
            self._extra_empty_targets.append(new_target)
        self._pivot_targets[row] = new_target
        self._mark_dirty()
        self.log_cb("info", f"Colonne cible renommee : {old_target} -> {new_target}")

    # ------------------------------------------------------------------
    # Ajout de tables / colonnes cible
    # ------------------------------------------------------------------

    def _add_table_to_pivot(self):
        connection = self.config.get_active_connection()
        domaine = self._current_domain()
        chargement_sources = [s for s in self.config.sources if s.domaine == domaine]
        dialog = TablePickerDialog(
            connection=connection, parent=self,
            domaine=domaine, chargement_sources=chargement_sources,
        )
        if not dialog.exec():
            return
        type_tpa, table_source, columns = dialog.result()
        if (type_tpa, table_source) in self._pivot_table_keys:
            QMessageBox.information(self, "Deja presente", "Cette table est deja dans le mapping de ce domaine.")
            return

        nb_associees, nb_non_mappees = self._add_columns_for_table(type_tpa, table_source, columns)
        self.log_cb(
            "success",
            f"Table {table_source} ({type_tpa}) ajoutee au mapping {DOMAIN_LABELS.get(domaine, domaine)} : "
            f"{nb_associees} colonne(s) associee(s) automatiquement, "
            f"{nb_non_mappees} colonne(s) non mappee(s) (<ignore>, structure cible fixe) — a mapper manuellement si besoin.",
        )
        self._mark_dirty()
        self._rebuild_pivot()

    def _add_columns_for_table(self, type_tpa: str, table_source: str, columns: list[str]) -> tuple[int, int]:
        """
        Logique commune d'ajout des colonnes d'une table au mapping (utilisee
        aussi bien pour un ajout individuel que pour le prechargement en
        masse, V72) : chaque colonne tente une association automatique par
        nom normalise (casse/espaces/accents ignores) contre les colonnes
        cible REELLES et FIXES (structure de la table de destination finale,
        V74) ; a defaut, le dictionnaire de correspondances EN/FR (V76) est
        consulte, pour les cas ou le nom source n'a rien de commun avec le
        nom cible (ex: 'police_number' vs 'Numéro_Police').

        IMPORTANT (V77) : les colonnes cible ne sont PAS extensibles — ce
        sont les vraies colonnes de la table de destination SQL Server, sur
        laquelle il est materiellement impossible d'inserer une colonne qui
        n'existe pas. Une colonne source sans correspondance (ni directe, ni
        via le dictionnaire) NE CREE JAMAIS de nouvelle ligne : elle reste
        simplement non mappee (<ignore>) pour cette table, la table restant
        neanmoins visible comme colonne du pivot pour permettre un
        rapprochement manuel ulterieur (renommage, dictionnaire EN/FR).

        N'appelle PAS _rebuild_pivot() elle-meme, pour permettre un appel en
        boucle efficace (une seule reconstruction a la fin du lot)."""
        self._table_columns_cache[table_source] = columns
        domaine = self._current_domain()
        targets_normalises = {_normalize(t): t for t in self._pivot_targets}
        nb_associees = 0
        nb_non_mappees = 0

        for col_name in columns:
            cible_existante = targets_normalises.get(_normalize(col_name))
            if not cible_existante:
                # Aucune correspondance directe par nom normalise : on tente
                # le dictionnaire de correspondances EN/FR (ou autre),
                # uniquement si la cible qu'il propose existe reellement
                # parmi les colonnes cible (jamais de creation a partir du
                # dictionnaire seul, pour rester previsible).
                cible_alias = self.alias_manager.resolve(col_name)
                if cible_alias:
                    cible_existante = targets_normalises.get(_normalize(cible_alias))
            if cible_existante:
                nb_associees += 1
                rule = MatchingRule.new(domaine, type_tpa, table_source, col_name, cible_existante)
            else:
                # Ne cree JAMAIS de nouvelle colonne cible (V77) : la regle
                # est enregistree avec une cible vide, ce qui suffit a faire
                # apparaitre la table comme colonne du pivot (pour permettre
                # de la mapper manuellement ensuite) sans jamais etendre la
                # liste fixe des colonnes cible reelles.
                nb_non_mappees += 1
                rule = MatchingRule.new(domaine, type_tpa, table_source, col_name, "")
            self.merge_config.add_rule(rule, persist=False)

        return nb_associees, nb_non_mappees

    def _preload_all_tables(self, uniquement_deja_chargees: bool = True, silent: bool = False):
        """
        Precharge en une seule fois les sources deja configurees dans le
        Chargement pour le domaine courant, qui ne sont pas encore dans le
        mapping (V72) : evite de cliquer "Ajouter une table" une par une
        pour chaque TPA/pays.

        Par defaut (V75), ne precharge que les sources DEJA CHARGEES avec
        succes au moins une fois (via l'historique des chargements, V59) :
        evite de tenter inutilement des tables qui n'existent pas encore
        cote SQL Server et de multiplier les avertissements. Le bouton
        "Precharger TOUT" permet d'inclure aussi les sources jamais
        chargees, a la demande explicite.

        silent=True (V83) : n'affiche aucune boite de dialogue (juste des
        messages dans la console), pour un appel automatique silencieux a
        chaque changement de domaine, sans interrompre l'utilisateur avec
        des popups s'il n'y a rien a faire ou pas de connexion active.

        Une table dont la lecture des colonnes echoue malgre tout (pas
        encore chargee en base, table absente) est ignoree avec un
        avertissement, sans bloquer le prechargement des autres."""
        connection = self.config.get_active_connection()
        if not connection:
            if not silent:
                QMessageBox.warning(self, "Aucune connexion", "Aucune connexion active configuree.")
            return

        domaine = self._current_domain()
        chargement_sources = [s for s in self.config.sources if s.domaine == domaine]
        a_precharger = [s for s in chargement_sources if (s.type, s.table) not in self._pivot_table_keys]

        nb_ignorees_jamais_chargees = 0
        if uniquement_deja_chargees:
            from core.load_history import LoadHistoryManager
            history = LoadHistoryManager()
            total_avant_filtre = len(a_precharger)
            a_precharger = [s for s in a_precharger if history.has_been_loaded(s.table)]
            nb_ignorees_jamais_chargees = total_avant_filtre - len(a_precharger)

        if not a_precharger:
            if silent:
                return
            if nb_ignorees_jamais_chargees:
                QMessageBox.information(
                    self, "Rien a precharger",
                    f"Aucune source deja chargee a precharger ({nb_ignorees_jamais_chargees} source(s) jamais chargee(s) ignoree(s) — "
                    "utilise \"Precharger TOUT\" pour les inclure quand meme).",
                )
            else:
                QMessageBox.information(self, "Rien a precharger", "Toutes les sources de ce domaine sont deja dans le mapping.")
            return

        from core.db import list_columns
        nb_tables_ok = 0
        nb_tables_echec = 0
        nb_associees_total = 0
        nb_non_mappees_total = 0

        for source in a_precharger:
            try:
                columns = list_columns(connection, source.table)
            except Exception as e:
                nb_tables_echec += 1
                self.log_cb("warning", f"Prechargement : impossible de lire les colonnes de {source.table} ({source.pays}/{source.type}) — {e}")
                continue
            if not columns:
                nb_tables_echec += 1
                self.log_cb("warning", f"Prechargement : aucune colonne trouvee pour {source.table} ({source.pays}/{source.type}) — table pas encore chargee ?")
                continue
            nb_associees, nb_non_mappees = self._add_columns_for_table(source.type, source.table, columns)
            nb_tables_ok += 1
            nb_associees_total += nb_associees
            nb_non_mappees_total += nb_non_mappees

        if nb_tables_ok:
            self._mark_dirty()
        self._rebuild_pivot()

        message = (
            f"Prechargement termine pour {DOMAIN_LABELS.get(domaine, domaine)} : "
            f"{nb_tables_ok} table(s) ajoutee(s) ({nb_associees_total} colonne(s) associee(s) automatiquement, "
            f"{nb_non_mappees_total} colonne(s) non mappee(s))."
        )
        if nb_tables_echec:
            message += f" {nb_tables_echec} table(s) ignoree(s) (voir la console)."
        if nb_ignorees_jamais_chargees:
            message += f" {nb_ignorees_jamais_chargees} source(s) jamais chargee(s) non incluse(s) (voir \"Precharger TOUT\")."
        self.log_cb("success" if nb_tables_ok else "warning", message)

    def _remove_orphaned_mapping_tables(self, silent: bool = True):
        """
        V117, sur demande explicite de l'utilisateur (\"les tables presentes
        dans la fusion doivent etre exactement ce que j'ai au chargement\") :
        retire du mapping toute table (type_tpa, table_source) qui ne
        correspond plus a AUCUNE source reellement configuree dans le
        Chargement pour ce domaine — typiquement une ancienne table
        renommee ou supprimee depuis cote Chargement, dont le mapping etait
        reste present et continuait a s'afficher comme une colonne
        independante (source des doublons/colonnes fantomes observes).
        Complement symetrique de _preload_all_tables (qui AJOUTE les
        sources manquantes ; celle-ci RETIRE les tables qui n'ont plus
        lieu d'etre).
        """
        domaine = self._current_domain()
        sources_reelles = {(s.type, s.table) for s in self.config.sources if s.domaine == domaine}
        rules = self.merge_config.rules_for_domain(domaine)
        tables_dans_mapping = {(r.type_tpa, r.table_source) for r in rules if r.type_tpa and r.table_source}
        orphelines = tables_dans_mapping - sources_reelles

        for type_tpa, table_source in sorted(orphelines):
            self.merge_config.remove_table(domaine, type_tpa, table_source, persist=False)
            self.log_cb(
                "info" if silent else "warning",
                f"{'[Nettoyage auto] ' if silent else ''}{type_tpa} ({table_source}) retire du mapping : "
                f"ne correspond plus a aucune source du Chargement pour ce domaine.",
            )
        if orphelines:
            self.merge_config.save()

    def _export_mapping_to_excel(self):
        """
        V135, sur demande explicite de l'utilisateur : exporte le mapping
        du domaine actuellement affiche vers un fichier Excel, avec la
        MEME disposition que les documents de reference que l'utilisateur
        envoie pour verification (une ligne par colonne cible, une colonne
        par table source) — permet une comparaison directe, ligne par
        ligne, sans etape de transcription manuelle.
        """
        if not self._pivot_targets or not self._pivot_table_keys:
            QMessageBox.information(self, "Rien a exporter", "Aucune colonne ou aucune table dans le mapping actuel de ce domaine.")
            return

        domaine = self._current_domain()
        nom_domaine = DOMAIN_LABELS.get(domaine, domaine)
        chemin_defaut = f"Mapping_{nom_domaine}.xlsx"
        chemin, _ = QFileDialog.getSaveFileName(self, "Exporter le mapping en Excel", chemin_defaut, "Fichiers Excel (*.xlsx)")
        if not chemin:
            return

        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment

            wb = Workbook()
            ws = wb.active
            ws.title = f"Correspondance {nom_domaine}"[:31]

            gras = Font(bold=True)
            fond_entete = PatternFill(start_color="D9E6F5", end_color="D9E6F5", fill_type="solid")
            centre = Alignment(horizontal="center", vertical="center")

            # En-tete : Colonne cible + une colonne par table source, meme
            # libelle que celui affiche a l'ecran (sans parentheses, V134)
            ws.cell(row=1, column=1, value="Colonne cible").font = gras
            for col_idx, (type_tpa, table_source) in enumerate(self._pivot_table_keys, start=2):
                cell = ws.cell(row=1, column=col_idx, value=self._table_header_label(type_tpa, table_source, domaine))
                cell.font = gras
                cell.fill = fond_entete
                cell.alignment = centre

            # Une ligne par colonne cible, ligne 1 = "Inclure dans la fusion"
            # ignoree (pas pertinente pour un document de reference statique)
            for target_idx, target in enumerate(self._pivot_targets):
                ligne_excel = target_idx + 2
                pivot_row = target_idx + 1  # +1 pour la ligne "Inclure dans la fusion" en position 0
                ws.cell(row=ligne_excel, column=1, value=target).font = gras
                for tpa_idx, (type_tpa, table_source) in enumerate(self._pivot_table_keys):
                    col_idx = tpa_idx + 2
                    widget = self.pivot_table.cellWidget(pivot_row, tpa_idx + 1)
                    valeur = widget.currentText() if widget else IGNORE
                    if valeur and valeur != IGNORE:
                        ws.cell(row=ligne_excel, column=col_idx, value=valeur)

            ws.column_dimensions[ws.cell(row=1, column=1).column_letter].width = 32
            for col_idx in range(2, len(self._pivot_table_keys) + 2):
                ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = 24
            ws.freeze_panes = "B2"

            wb.save(chemin)
            QMessageBox.information(self, "Export reussi", f"Mapping exporte avec succes vers :\n{chemin}")
            self.log_cb("success", f"Mapping {nom_domaine} exporte vers {chemin}.")
        except Exception as e:
            QMessageBox.critical(self, "Erreur d'export", f"Impossible d'exporter le mapping : {e}")
            self.log_cb("error", f"Echec de l'export Excel du mapping {nom_domaine} : {e}")

    def _open_alias_manager(self):
        domaine = self._current_domain()
        cibles_possibles = list(dict.fromkeys(self._pivot_targets + self.schema_manager.get_schema(domaine)))
        dialog = AliasManagerDialog(self.alias_manager, cibles_possibles, parent=self)
        dialog.exec()

    def _open_value_alias_manager(self):
        domaine = self._current_domain()
        cibles_possibles = list(dict.fromkeys(self._pivot_targets + self.schema_manager.get_schema(domaine)))
        colonne_defaut = "Pays_Client" if "Pays_Client" in cibles_possibles else (cibles_possibles[0] if cibles_possibles else "")

        def _detect(colonne_cible: str) -> int:
            rules = self.merge_config.rules_for_domain(domaine)
            conn = self.config.get_active_connection()
            engine = build_engine(conn)
            return detect_new_values(engine, rules, domaine, colonne_cible, self.value_alias_manager, log_cb=self.log_cb)

        dialog = ValueAliasManagerDialog(
            self.value_alias_manager, cibles_possibles, colonne_defaut,
            detect_callback=_detect, parent=self,
        )
        dialog.exec()

    def _open_schema_editor(self):
        domaine = self._current_domain()
        dialog = SchemaEditorDialog(self.schema_manager, domaine, parent=self)
        if dialog.exec():
            # La structure du domaine choisi dans le dialogue (pas forcement
            # celui affiche a l'ecran) a pu changer : on ne recharge
            # completement que si c'est bien le domaine actuellement affiche,
            # pour ne pas perdre de modifications non enregistrees sur un
            # autre domaine par effet de bord.
            domaine_modifie = dialog.domain_combo.currentData()
            if domaine_modifie == self._current_domain():
                self._load_domain(domaine_modifie)
            self.log_cb("success", f"Structure cible mise a jour pour {DOMAIN_LABELS.get(domaine_modifie, domaine_modifie)} ({len(dialog._colonnes_analysees)} colonne(s)).")

    def _load_real_target_schema(self):
        """
        Precharge les colonnes cible du mapping directement depuis la vraie
        structure de la table de destination finale (V74, confirmee par
        l'utilisateur depuis SQL Server), dans leur ordre exact — plutot que
        de les laisser se definir arbitrairement par la premiere table TPA
        ajoutee. Les colonnes deja presentes (venant d'une table deja
        ajoutee) sont conservees telles quelles, seules les colonnes
        manquantes de la structure reelle sont ajoutees comme nouvelles
        lignes vides, a la fin de la liste actuelle."""
        domaine = self._current_domain()
        schema = self.schema_manager.get_schema(domaine)
        if not schema:
            QMessageBox.information(self, "Structure indisponible", f"Aucune structure cible reelle connue pour le domaine {DOMAIN_LABELS.get(domaine, domaine)}.")
            return

        deja_presentes = set(self._pivot_targets)
        colonnes_manquantes = [c for c in schema if c not in deja_presentes]

        if not colonnes_manquantes:
            QMessageBox.information(self, "Deja a jour", "Toutes les colonnes de la structure cible reelle sont deja presentes dans le mapping.")
            return

        for col in colonnes_manquantes:
            self._extra_empty_targets.append(col)
        self._rebuild_pivot()
        self.log_cb(
            "success",
            f"{len(colonnes_manquantes)} colonne(s) de la structure cible reelle de {DOMAIN_LABELS.get(domaine, domaine)} "
            f"ajoutee(s) au mapping (sur {len(schema)} au total).",
        )

    # ------------------------------------------------------------------
    # Suppression (menus contextuels)
    # ------------------------------------------------------------------

    def _on_header_context_menu(self, pos):
        col = self.pivot_table.horizontalHeader().logicalIndexAt(pos)
        if col <= 0 or col - 1 >= len(self._pivot_table_keys):
            return
        type_tpa, table_source = self._pivot_table_keys[col - 1]
        menu = QMenu(self)
        show_unmapped_action = menu.addAction(f"👁 Voir les colonnes non mappées de {table_source}")
        remove_action = menu.addAction(f"🗑️ Retirer {table_source} du mapping")
        chosen = menu.exec(self.pivot_table.horizontalHeader().mapToGlobal(pos))
        if chosen == remove_action:
            self._remove_table_column(type_tpa, table_source)
        elif chosen == show_unmapped_action:
            self._show_unmapped_columns(type_tpa, table_source)

    def _show_unmapped_columns(self, type_tpa: str, table_source: str):
        """
        Affiche les colonnes REELLES de cette table qui ne sont mappees vers
        AUCUNE colonne cible (\u00ab<ignore>\u00bb dans le pivot) — utile en un coup
        d'oeil quand une table utilise une nomenclature tres differente des
        autres (ex: colonnes en anglais alors que la 1ere table qui a defini
        les colonnes cible est en francais), sans avoir a ouvrir chaque
        cellule une par une pour decouvrir ce qui est disponible."""
        domaine = self._current_domain()
        rules = self.merge_config.rules_for_domain(domaine)
        colonnes_mappees = {
            r.colonne_source for r in rules
            if r.type_tpa == type_tpa and r.table_source == table_source and r.colonne_cible
        }
        toutes_colonnes = self._table_columns_cache.get(table_source, [])
        non_mappees = [c for c in toutes_colonnes if c not in colonnes_mappees]

        if not toutes_colonnes:
            QMessageBox.information(
                self, "Colonnes non mappées",
                f"Aucune colonne connue pour {table_source} (essaie de retirer puis rajouter cette table).",
            )
            return

        texte = (
            f"Table {table_source} ({type_tpa})\n"
            f"{len(colonnes_mappees)}/{len(toutes_colonnes)} colonne(s) mappée(s) vers une colonne cible.\n\n"
        )
        if non_mappees:
            texte += f"Colonnes ENCORE NON mappées ({len(non_mappees)}) :\n" + "\n".join(f"  • {c}" for c in non_mappees)
        else:
            texte += "Toutes les colonnes de cette table sont mappées."
        QMessageBox.information(self, f"Colonnes non mappées — {table_source}", texte)

    def _remove_table_column(self, type_tpa: str, table_source: str):
        domaine = self._current_domain()
        rules_to_remove = [
            r for r in self.merge_config.rules_for_domain(domaine)
            if r.type_tpa == type_tpa and r.table_source == table_source
        ]
        for r in rules_to_remove:
            self.merge_config.remove_rule(r.id, persist=False)
        self.log_cb("warning", f"Table {table_source} retiree du mapping ({len(rules_to_remove)} correspondance(s) supprimee(s)).")
        self._mark_dirty()
        self._rebuild_pivot()

    def _on_cell_context_menu(self, pos):
        item = self.pivot_table.itemAt(pos)
        row_widget = item.row() if item else self.pivot_table.rowAt(pos.y())
        if row_widget <= 0:
            return  # row 0 = ligne des cases "Inclure dans la fusion", pas de menu contextuel
        row = row_widget - 1  # decalage : row 0 du tableau = ligne des cases a cocher
        if row >= len(self._pivot_targets):
            return
        target = self._pivot_targets[row]
        menu = QMenu(self)
        merge_action = menu.addAction(f"🔗 Fusionner « {target} » avec une autre ligne")
        remove_action = menu.addAction(f"🗑️ Supprimer la colonne cible « {target} »")
        chosen = menu.exec(self.pivot_table.viewport().mapToGlobal(pos))
        if chosen == remove_action:
            self._remove_target_row(target)
        elif chosen == merge_action:
            self._merge_target_row(target)

    def _merge_target_row(self, target: str):
        """
        Fusionne la ligne (colonne cible) donnee avec une autre ligne
        existante en une seule ligne combinee (V73), par exemple
        \u00abdate d'achat\u00bb + \u00abdate_of_purchase\u00bb -> \u00abdate d'achat / date_of_purchase\u00bb.
        Utile quand differents TPA utilisent des noms differents (langue,
        convention) pour un concept identique, qui se sont donc retrouves
        sur des lignes separees faute de correspondance automatique. Toutes
        les correspondances des deux lignes d'origine sont redirigees vers
        la ligne fusionnee, sans rien perdre."""
        autres_lignes = [t for t in self._pivot_targets if t != target]
        if not autres_lignes:
            QMessageBox.information(self, "Fusion impossible", "Il n'y a aucune autre ligne avec laquelle fusionner.")
            return

        autre, ok = QInputDialog.getItem(
            self, "Fusionner deux lignes cible",
            f"Fusionner « {target} » avec :",
            autres_lignes, 0, False,
        )
        if not ok or not autre:
            return

        nom_par_defaut = f"{target} / {autre}"
        nom_fusionne, ok = QInputDialog.getText(
            self, "Nom de la ligne fusionnee",
            "Nom de la ligne cible combinee (modifiable) :",
            text=nom_par_defaut,
        )
        nom_fusionne = nom_fusionne.strip()
        if not ok or not nom_fusionne:
            return

        domaine = self._current_domain()
        nb_redirigees = 0
        for r in self.merge_config.rules_for_domain(domaine):
            if r.colonne_cible in (target, autre):
                self.merge_config.update_rule(r.id, persist=False, colonne_cible=nom_fusionne)
                nb_redirigees += 1
        for t in (target, autre):
            if t in self._extra_empty_targets:
                self._extra_empty_targets.remove(t)

        self.log_cb(
            "success",
            f"Lignes « {target} » et « {autre} » fusionnees en « {nom_fusionne} » ({nb_redirigees} correspondance(s) redirigee(s)).",
        )
        self._mark_dirty()
        self._rebuild_pivot()

    def _remove_target_row(self, target: str):
        domaine = self._current_domain()
        rules_to_remove = [r for r in self.merge_config.rules_for_domain(domaine) if r.colonne_cible == target]
        for r in rules_to_remove:
            self.merge_config.remove_rule(r.id, persist=False)
        if target in self._extra_empty_targets:
            self._extra_empty_targets.remove(target)
        self.log_cb("warning", f"Colonne cible « {target} » supprimee ({len(rules_to_remove)} correspondance(s)).")
        self._mark_dirty()
        self._rebuild_pivot()

    # ------------------------------------------------------------------
    # Verification base cible / execution
    # ------------------------------------------------------------------

    def _confirm_target_database(self) -> bool:
        c = self.config.get_active_connection()
        if c.database.strip().upper() == EXPECTED_DATABASE.upper():
            return True

        confirm = QMessageBox.warning(
            self, "Verification de la base cible",
            f"La base de donnees active pour l'environnement \u00ab{c.nom}\u00bb est "
            f"\u00ab{c.database}\u00bb, alors que les tables de fusion doivent normalement "
            f"se trouver dans \u00ab{EXPECTED_DATABASE}\u00bb.\n\n"
            "Veux-tu vraiment continuer et fusionner dans cette base ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if confirm != QMessageBox.StandardButton.Yes:
            self.log_cb("warning", f"Fusion annulee : base active \u00ab{c.database}\u00bb differente de \u00ab{EXPECTED_DATABASE}\u00bb attendue.")
            return False
        self.log_cb("warning", f"Confirmation utilisateur : fusion malgre une base differente de {EXPECTED_DATABASE} ({c.database}).")
        return True

    def _refresh_target_tables(self):
        try:
            conn = self.config.get_active_connection()
            from core.db import list_tables
            tables = list_tables(conn)
        except Exception as e:
            self.log_cb("error", f"Impossible de charger les tables de fusion depuis {self.config.get_active_connection().database} : {e}")
            QMessageBox.warning(self, "Erreur", f"Impossible de charger les tables : {e}")
            return
        current = self.target_combo.currentText()
        self.target_combo.clear()
        self.target_combo.addItems(tables)
        self.target_combo.setEditText(current)

    def _run_fusion(self):
        domaine = self._current_domain()
        target_table = self.target_combo.currentText().strip()
        vider = self.vider_checkbox.isChecked()
        if not target_table:
            QMessageBox.warning(self, "Table manquante", "Renseigne une table de fusion cible.")
            return

        if not self._confirm_target_database():
            return

        if self._dirty:
            self._save_mapping()
            self.log_cb("info", "Mapping enregistre automatiquement avant le lancement de la fusion.")

        self.merge_config.set_target_table(domaine, target_table)
        self.merge_config.set_vider_avant_fusion(domaine, vider)

        rules = self.merge_config.rules_for_domain(domaine)
        if not rules:
            QMessageBox.information(self, "Aucune regle", "Ajoute au moins une table au mapping avant de lancer la fusion.")
            return

        # Ne retient que les regles des tables TPA actuellement cochees
        # (V83, case "Inclure dans la fusion") : une table decochee reste
        # visible dans le mapping (pour continuer a la corriger si besoin)
        # sans jamais participer a l'execution reelle de la fusion.
        tpa_exclus = {
            (t, tbl) for t, tbl in self._pivot_table_keys
            if not self.merge_config.is_tpa_inclus(domaine, t, tbl)
        }
        if tpa_exclus:
            rules = [r for r in rules if (r.type_tpa, r.table_source) not in tpa_exclus]
            noms_exclus = ", ".join(f"{t} ({tbl.split('.')[-1]})" for t, tbl in tpa_exclus)
            self.log_cb("info", f"TPA exclu(s) de cette execution (case decochee) : {noms_exclus}.")
        if not rules:
            QMessageBox.information(self, "Aucune source incluse", "Toutes les tables du mapping sont decochees — coche au moins un TPA avant de lancer la fusion.")
            return

        self.status_label.setText("Fusion en cours...")
        self.run_btn.setEnabled(False)
        try:
            conn = self.config.get_active_connection()
            engine = build_engine(conn)
            result = run_merge(
                engine=engine, domaine=domaine, rules=rules,
                target_table=target_table, vider_avant=vider, log_cb=self.log_cb,
                sources=self.config.sources, value_alias_manager=self.value_alias_manager,
            )
            if result.sql_executed:
                self.log_cb("info", f"Requete SQL executee (UNION ALL) :\n{result.sql_executed}")
            if result.success:
                self.status_label.setText(f"✅ {result.total_rows} ligne(s) fusionnee(s)")
            else:
                self.status_label.setText(f"⚠ Termine avec {len(result.errors)} erreur(s)")
        except Exception as e:
            self.status_label.setText("❌ Erreur")
            self.log_cb("error", f"Erreur fusion : {e}")
            QMessageBox.warning(self, "Erreur", str(e))
        finally:
            self.run_btn.setEnabled(not getattr(self, "_read_only", False))

    def set_read_only(self, read_only: bool) -> None:
        """V150 : grise les actions qui ECRIVENT une configuration partagee
        (structure cible, dictionnaire EN/FR, mapping) ou lancent la fusion
        reelle (ecriture en base), et bloque l'edition directe de la grille
        pivot, pour un utilisateur dont le role n'est pas Administrateur.
        Les actions purement consultatives (precharger, charger la
        structure reelle, exporter en Excel) restent toujours disponibles."""
        self._read_only = read_only
        for btn in self._write_buttons:
            btn.setEnabled(not read_only)
            btn.setToolTip("Action reservee au role Administrateur." if read_only else "")
        self.pivot_table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers if read_only
            else QAbstractItemView.EditTrigger.DoubleClicked | QAbstractItemView.EditTrigger.EditKeyPressed
        )

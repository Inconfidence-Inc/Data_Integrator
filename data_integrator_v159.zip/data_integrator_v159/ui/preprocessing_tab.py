from __future__ import annotations

import shutil
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QPushButton, QLabel,
    QLineEdit, QTableWidget, QTableWidgetItem, QAbstractItemView,
    QHeaderView, QCheckBox, QMessageBox, QFileDialog
)

from core.config_manager import ConfigManager, SourceConfig, PreprocessingRulesManager, DOMAINES, TPA_TYPES
from core.preprocessing import check_source_folder
from core.mail_manager import MailConfigManager, send_mail
from core.log_manager import default_log_cb as _default_log_cb

DOMAIN_LABELS = {"Adhesion": "Adhésion", "Sinistre": "Sinistre", "FIC": "FIC", "Reclamation": "Réclamation"}

# Categorie SMTP utilisee pour les alertes automatiques de pretraitement
# (notifications techniques, cf. ecran Mails > Configuration SMTP > DSI)
ALERT_MAIL_CATEGORY = "DSI"

COL_CHECK, COL_DOMAINE, COL_PAYS, COL_TYPE, COL_DOSSIER, COL_STATUT = range(6)
SOURCE_HEADERS = ["", "Domaine", "Pays", "Type", "Dossier source", "Statut prétraitement"]

TPA_COL_TYPE, TPA_COL_COLONNES = range(2)
TPA_HEADERS = ["Type / TPA", "Colonnes attendues (separees par des virgules)"]

RESULT_COL_SOURCE, RESULT_COL_FICHIER, RESULT_COL_STATUT, RESULT_COL_DETAILS = range(4)
RESULT_HEADERS = ["Source", "Fichier", "Statut", "Détails"]

STATUS_STYLES = {
    "Non controle": ("⏸ Non controle", QColor("#F1F3F4"), QColor("#5F6368")),
    "OK":            ("✅ OK", QColor("#E6F4EA"), QColor("#0D652D")),
    "Avertissement": ("⚠️ Avertissement", QColor("#FEF7E0"), QColor("#7A4E00")),
    "Erreur":        ("❌ Erreur", QColor("#F9DEDC"), QColor("#410E0B")),
}


class PreprocessingTab(QWidget):
    """
    Onglet de pretraitement : controle generique (memes regles pour les 3
    domaines) de la forme/structure des fichiers sources avant qu'ils ne
    soient proposes au chargement — nommage, encodage, colonnes attendues.
    """

    def __init__(self, config: ConfigManager, log_cb=None, on_sources_changed=None, parent=None):
        super().__init__(parent)
        self.config = config
        self.rules = PreprocessingRulesManager()
        self.log_cb = log_cb or _default_log_cb
        self.on_sources_changed = on_sources_changed or (lambda: None)
        self.row_by_source_id: dict[str, int] = {}
        # V150 : boutons qui ECRIVENT une configuration partagee ou lancent
        # un traitement (par opposition a la simple consultation) — grises
        # pour un utilisateur dont le role (authentification centralisee)
        # n'est pas Administrateur, via set_read_only().
        self._write_buttons: list[QPushButton] = []

        layout = QVBoxLayout(self)

        layout.addWidget(self._build_rules_group(), stretch=1)

        # V107 : le bloc de configuration OK/KO, sur demande explicite de
        # l'utilisateur, devient un petit ecran d'administration separe
        # (comme Connexions et Mails) plutot qu'un bloc integre a l'ecran
        # principal — desencombre au passage cet ecran qui accumulait
        # Regles + OK/KO + Sources + Resultats.
        admin_row = QHBoxLayout()
        admin_btn = QPushButton("⚙️  Administration — Repertoires OK / KO")
        admin_btn.setObjectName("ghostBtn")
        admin_btn.clicked.connect(self._open_ok_ko_admin)
        self._write_buttons.append(admin_btn)
        admin_row.addWidget(admin_btn)
        admin_row.addStretch()
        layout.addLayout(admin_row)

        layout.addWidget(self._build_sources_group(), stretch=2)
        layout.addWidget(self._build_results_group(), stretch=2)

        self._refresh_sources_table()

    # ------------------------------------------------------------------

    def _build_rules_group(self) -> QGroupBox:
        group = QGroupBox("⚙️  Regles de controle — colonnes attendues par TPA")
        layout = QVBoxLayout(group)

        self.tpa_table = QTableWidget(0, len(TPA_HEADERS))
        self.tpa_table.setHorizontalHeaderLabels(TPA_HEADERS)
        self.tpa_table.horizontalHeader().setSectionResizeMode(TPA_COL_COLONNES, QHeaderView.ResizeMode.Stretch)
        self.tpa_table.verticalHeader().setVisible(False)
        self.tpa_table.verticalHeader().setDefaultSectionSize(36)
        # V102 : hauteur calculee pour que les 6 TPA (SPB, Evy, Estaly,
        # NEAT, LAPI, GP) tiennent tous sans defilement (6 x 36px + entete),
        # suite a un signalement utilisateur (seuls 3 TPA visibles).
        self.tpa_table.setMinimumHeight(260)
        self.tpa_table.setMaximumHeight(280)
        self.tpa_table.itemChanged.connect(self._on_tpa_item_changed)
        layout.addWidget(self.tpa_table)

        self._populate_tpa_table()

        btn_row = QHBoxLayout()
        add_tpa_btn = QPushButton("➕ Ajouter un type")
        add_tpa_btn.setObjectName("ghostBtn")
        add_tpa_btn.clicked.connect(self._add_tpa_row)
        self._write_buttons.append(add_tpa_btn)
        btn_row.addWidget(add_tpa_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Motif de nommage attendu (commun a tous les TPA) :"))
        self.filename_pattern_edit = QLineEdit(self.rules.filename_pattern)
        self.filename_pattern_edit.setPlaceholderText(r"ex: SPB.*France (regex, laisser vide pour ne pas controler)")
        self.filename_pattern_edit.editingFinished.connect(self._save_rules)
        row2.addWidget(self.filename_pattern_edit)
        layout.addLayout(row2)

        info = QLabel("L'encodage de chaque fichier est toujours verifie automatiquement (aucun reglage necessaire). "
                       "Colle les colonnes telles qu'elles apparaissent dans le fichier source (virgule, point-virgule, "
                       "tabulation ou une par ligne, tout format est accepte). Un TPA sans colonnes renseignees n'est pas controle sur ce point.")
        info.setStyleSheet("color:#5F6368; font-style:italic;")
        layout.addWidget(info)

        # V102 : hauteur minimale du GROUPE ENTIER (pas seulement du
        # tableau interne) — sans cela, le tableau respectait bien sa
        # propre hauteur minimale mais le bouton "Ajouter un type" et le
        # texte d'aide en dessous se retrouvaient visuellement ecrases/
        # superposes si le groupe complet manquait globalement de place.
        group.setMinimumHeight(440)
        return group

    def _open_ok_ko_admin(self):
        from ui.ok_ko_dialog import OkKoConfigDialog
        dialog = OkKoConfigDialog(self.rules, self.config.sources, self.log_cb, parent=self)
        dialog.exec()

    def _populate_tpa_table(self):
        self._loading_tpa_table = True
        self.tpa_table.setRowCount(0)
        tpa_list = list(TPA_TYPES)
        for tpa in self.rules.expected_columns_by_tpa:
            if tpa not in tpa_list:
                tpa_list.append(tpa)
        for tpa in tpa_list:
            self._append_tpa_row(tpa, self.rules.expected_columns_by_tpa.get(tpa, ""))
        self._loading_tpa_table = False

    def _append_tpa_row(self, tpa: str, colonnes: str):
        row = self.tpa_table.rowCount()
        self.tpa_table.insertRow(row)
        type_item = QTableWidgetItem(tpa)
        cols_item = QTableWidgetItem(colonnes)
        self.tpa_table.setItem(row, TPA_COL_TYPE, type_item)
        self.tpa_table.setItem(row, TPA_COL_COLONNES, cols_item)

    def _add_tpa_row(self):
        self._loading_tpa_table = True
        self._append_tpa_row("", "")
        self._loading_tpa_table = False
        self.tpa_table.setCurrentCell(self.tpa_table.rowCount() - 1, TPA_COL_TYPE)

    def _on_tpa_item_changed(self, _item):
        if getattr(self, "_loading_tpa_table", False):
            return
        self._save_rules()

    def _collect_tpa_rules(self) -> dict[str, str]:
        rules = {}
        for row in range(self.tpa_table.rowCount()):
            type_item = self.tpa_table.item(row, TPA_COL_TYPE)
            cols_item = self.tpa_table.item(row, TPA_COL_COLONNES)
            tpa = type_item.text().strip() if type_item else ""
            colonnes = cols_item.text().strip() if cols_item else ""
            if tpa:
                rules[tpa] = colonnes
        return rules

    def _build_sources_group(self) -> QGroupBox:
        group = QGroupBox("📂  Sources a controler")
        layout = QVBoxLayout(group)

        self.sources_table = QTableWidget(0, len(SOURCE_HEADERS))
        self.sources_table.setHorizontalHeaderLabels(SOURCE_HEADERS)
        self.sources_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.sources_table.setAlternatingRowColors(True)
        self.sources_table.horizontalHeader().setSectionResizeMode(COL_DOSSIER, QHeaderView.ResizeMode.Stretch)
        self.sources_table.verticalHeader().setVisible(False)
        self.sources_table.verticalHeader().setDefaultSectionSize(36)
        # V110 : meme correctif que les tableaux precedents (V101/V102) —
        # hauteur minimale explicite, calculee pour les 9 vraies sources
        # d'un domaine (9 x 36px + entete) plus une petite marge, pour ne
        # jamais etre ecrase quand la fenetre manque de place.
        self.sources_table.setMinimumHeight(380)
        layout.addWidget(self.sources_table)

        btn_row = QHBoxLayout()
        select_all_btn = QPushButton("☑ Tout cocher")
        select_all_btn.setObjectName("ghostBtn")
        select_all_btn.clicked.connect(lambda: self._set_all_checked(True))
        select_none_btn = QPushButton("☐ Tout decocher")
        select_none_btn.setObjectName("ghostBtn")
        select_none_btn.clicked.connect(lambda: self._set_all_checked(False))
        run_btn = QPushButton("🔍 Lancer le controle")
        run_btn.setObjectName("primaryBtn")
        run_btn.clicked.connect(self._run_check)
        self._write_buttons.append(run_btn)

        btn_row.addWidget(select_all_btn)
        btn_row.addWidget(select_none_btn)
        btn_row.addStretch()
        btn_row.addWidget(run_btn)
        layout.addLayout(btn_row)

        # V110 : hauteur minimale du GROUPE ENTIER (titre + tableau +
        # boutons), pas seulement du tableau interne — meme lecon tiree du
        # correctif V102 sur le bloc Regles de controle : sans cela, le
        # tableau respecte sa propre hauteur minimale mais les boutons en
        # dessous peuvent se retrouver visuellement ecrases si le groupe
        # complet manque globalement de place dans la page.
        group.setMinimumHeight(460)
        return group

    def _build_results_group(self) -> QGroupBox:
        group = QGroupBox("📋  Resultats du dernier controle")
        layout = QVBoxLayout(group)

        self.results_table = QTableWidget(0, len(RESULT_HEADERS))
        self.results_table.setHorizontalHeaderLabels(RESULT_HEADERS)
        self.results_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.results_table.setAlternatingRowColors(True)
        self.results_table.horizontalHeader().setSectionResizeMode(RESULT_COL_DETAILS, QHeaderView.ResizeMode.Stretch)
        self.results_table.verticalHeader().setVisible(False)
        layout.addWidget(self.results_table)

        return group

    # ------------------------------------------------------------------
    # Tableau des sources
    # ------------------------------------------------------------------

    def _refresh_sources_table(self):
        self.sources_table.setRowCount(0)
        self.row_by_source_id.clear()
        for source in self.config.sources:
            self._append_source_row(source)

    def _append_source_row(self, source: SourceConfig):
        table = self.sources_table
        row = table.rowCount()
        table.insertRow(row)
        self.row_by_source_id[source.id] = row

        check = QCheckBox()
        check_widget = QWidget()
        check_layout = QHBoxLayout(check_widget)
        check_layout.addWidget(check)
        check_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        check_layout.setContentsMargins(0, 0, 0, 0)
        table.setCellWidget(row, COL_CHECK, check_widget)

        table.setItem(row, COL_DOMAINE, QTableWidgetItem(DOMAIN_LABELS.get(source.domaine, source.domaine)))
        table.setItem(row, COL_PAYS, QTableWidgetItem(source.pays))
        table.setItem(row, COL_TYPE, QTableWidgetItem(source.type))
        table.setItem(row, COL_DOSSIER, QTableWidgetItem(source.dossier_source))
        self._set_status_item(row, source.pretraitement_statut)

        for col in (COL_DOMAINE, COL_PAYS, COL_TYPE, COL_DOSSIER):
            item = table.item(row, col)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            item.setData(Qt.ItemDataRole.UserRole, source.id)

    def _set_status_item(self, row: int, statut: str):
        label, bg, fg = STATUS_STYLES.get(statut, STATUS_STYLES["Non controle"])
        item = QTableWidgetItem(label)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        item.setBackground(bg)
        item.setForeground(fg)
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.sources_table.setItem(row, COL_STATUT, item)

    def _set_all_checked(self, checked: bool):
        for row in range(self.sources_table.rowCount()):
            widget = self.sources_table.cellWidget(row, COL_CHECK)
            checkbox = widget.findChild(QCheckBox) if widget else None
            if checkbox:
                checkbox.setChecked(checked)

    def _checked_sources(self) -> list[SourceConfig]:
        result = []
        for source in self.config.sources:
            row = self.row_by_source_id.get(source.id)
            if row is None:
                continue
            widget = self.sources_table.cellWidget(row, COL_CHECK)
            checkbox = widget.findChild(QCheckBox) if widget else None
            if checkbox and checkbox.isChecked():
                result.append(source)
        return result

    # ------------------------------------------------------------------
    # Regles
    # ------------------------------------------------------------------

    def _save_rules(self):
        self.rules.save(self._collect_tpa_rules(), self.filename_pattern_edit.text().strip())
        self.log_cb("info", "Regles de pretraitement enregistrees.")

    # ------------------------------------------------------------------
    # Controle
    # ------------------------------------------------------------------

    def _run_check(self):
        sources = self._checked_sources()
        if not sources:
            QMessageBox.information(self, "Aucune source", "Coche au moins une source a controler.")
            return

        self._save_rules()
        filename_pattern = self.filename_pattern_edit.text().strip() or None

        self.results_table.setRowCount(0)
        self.log_cb("info", f"=== Lancement du pretraitement pour {len(sources)} source(s) ===")

        problematic: list[tuple[SourceConfig, object]] = []
        fichiers_ko_total: list[tuple[SourceConfig, str, str]] = []

        for source in sources:
            expected_columns = self.rules.get_expected_columns(source.type)
            result = check_source_folder(
                source_id=source.id,
                folder=source.dossier_source,
                expected_columns=expected_columns or None,
                filename_pattern=filename_pattern,
                header_mode=source.header_mode,
            )

            self.config.update_source(source.id, pretraitement_statut=result.status)
            row = self.row_by_source_id.get(source.id)
            if row is not None:
                self._set_status_item(row, result.status)

            label = f"{source.pays} / {source.type}"
            for f in result.files:
                self._append_result_row(label, f)

            self.log_cb(
                "success" if result.status == "OK" else ("warning" if result.status == "Avertissement" else "error"),
                f"Pretraitement {label} : {result.status} ({len(result.files)} fichier(s) controle(s))",
            )

            if result.status in ("Erreur", "Avertissement"):
                problematic.append((source, result))

            if self.rules.deplacement_actif:
                deplaces_ko = self._move_files_after_check(source, result)
                fichiers_ko_total.extend(deplaces_ko)

        self.log_cb("info", "=== Pretraitement termine ===")
        self.on_sources_changed()

        if problematic:
            self._send_alert_mail(problematic)
        if fichiers_ko_total and self.rules.mail_ko_actif:
            self._send_ko_move_mail(fichiers_ko_total)

    def _move_files_after_check(self, source: SourceConfig, result) -> list[tuple[SourceConfig, str, str]]:
        """
        Deplace chaque fichier controle vers son dossier OK ou KO configure
        pour ce TPA (V92, inspire du fonctionnement d'Orchestrator) : un
        fichier en erreur part en KO, tout le reste (OK ou simple
        avertissement non bloquant) part en OK. Ne deplace rien si le
        dossier correspondant n'est pas configure pour ce TPA (vide = pas
        de deplacement sur ce statut). Retourne la liste des fichiers
        deplaces en KO (pour la notification mail), sous forme de tuples
        (source, nom_fichier, raison)."""
        ok_folder = self.rules.get_ok_folder(source.type, source.pays)
        ko_folder = self.rules.get_ko_folder(source.type, source.pays)
        if not ok_folder and not ko_folder:
            return []

        deplaces_ko: list[tuple[SourceConfig, str, str]] = []
        for f in result.files:
            if f.filename == "-":
                continue  # entree synthetique (dossier introuvable / vide), rien a deplacer
            source_path = Path(source.dossier_source) / f.filename
            if not source_path.is_file():
                continue

            destination_folder = ko_folder if f.status == "Erreur" else ok_folder
            if not destination_folder:
                continue  # dossier non configure pour ce statut : on laisse le fichier sur place

            try:
                Path(destination_folder).mkdir(parents=True, exist_ok=True)
                destination_path = Path(destination_folder) / f.filename
                shutil.move(str(source_path), str(destination_path))
                self.log_cb("info", f"  Deplace [{f.status}] {f.filename} -> {destination_folder}")
                if f.status == "Erreur":
                    raison = "; ".join(f.errors) or "Erreur de controle"
                    deplaces_ko.append((source, f.filename, raison))
            except Exception as e:
                self.log_cb("error", f"  Echec du deplacement de {f.filename} vers {destination_folder} : {e}")

        return deplaces_ko

    def _send_ko_move_mail(self, fichiers_ko: list[tuple[SourceConfig, str, str]]):
        """Alerte mail dediee (categorie DSI) listant les fichiers
        effectivement deplaces vers un dossier KO lors de ce controle —
        distincte de _send_alert_mail (qui couvre toute source en erreur ou
        avertissement, deplacement actif ou non)."""
        mail_config = MailConfigManager()
        account = mail_config.get_account(ALERT_MAIL_CATEGORY)
        if not account or not account.smtp_server or not account.expediteur or not account.destinataires:
            self.log_cb(
                "warning",
                f"Mail de deplacement KO non envoye : le compte SMTP \u00ab{ALERT_MAIL_CATEGORY}\u00bb n'est pas "
                f"completement configure (ecran Mails > Configuration SMTP).",
            )
            return

        lines = [f"{len(fichiers_ko)} fichier(s) deplace(s) vers un dossier KO lors du dernier pretraitement :", ""]
        for source, filename, raison in fichiers_ko:
            domaine_label = DOMAIN_LABELS.get(source.domaine, source.domaine)
            lines.append(f"- [{domaine_label}] {source.pays} / {source.type} : {filename}")
            lines.append(f"    * {raison}")
        body = "\n".join(lines)
        subject = f"[Data Integrator] {len(fichiers_ko)} fichier(s) deplace(s) en KO — pretraitement"

        ok, msg = send_mail(account, subject, body)
        if ok:
            self.log_cb("warning", f"Mail de deplacement KO envoye ({ALERT_MAIL_CATEGORY}, {len(account.destinataires)} destinataire(s)).")
        else:
            self.log_cb("error", f"Echec de l'envoi du mail de deplacement KO : {msg}")

    def _send_alert_mail(self, problematic: list):
        """
        Envoie une alerte par mail (compte SMTP de la categorie DSI, prevu
        pour les notifications techniques) listant les sources en erreur ou
        avertissement suite au pretraitement. N'interrompt jamais le
        controle si l'envoi echoue ou si le compte n'est pas configure —
        se contente de le journaliser.
        """
        mail_config = MailConfigManager()
        account = mail_config.get_account(ALERT_MAIL_CATEGORY)
        if not account or not account.smtp_server or not account.expediteur or not account.destinataires:
            self.log_cb(
                "warning",
                f"Alerte mail non envoyee : le compte SMTP \u00ab{ALERT_MAIL_CATEGORY}\u00bb n'est pas "
                f"completement configure (ecran Mails > Configuration SMTP).",
            )
            return

        lines = [f"Le pretraitement a detecte un probleme sur {len(problematic)} source(s) :", ""]
        for source, result in problematic:
            domaine_label = DOMAIN_LABELS.get(source.domaine, source.domaine)
            lines.append(f"- [{domaine_label}] {source.pays} / {source.type} : {result.status}")
            for f in result.files:
                if f.status != "OK":
                    detail = "; ".join(f.errors + f.warnings)
                    lines.append(f"    * {f.filename} [{f.status}] : {detail}")
            lines.append("")
        body = "\n".join(lines)
        subject = f"[Data Integrator] Alerte pretraitement — {len(problematic)} source(s) en probleme"

        ok, msg = send_mail(account, subject, body)
        if ok:
            self.log_cb("warning", f"Alerte mail envoyee ({ALERT_MAIL_CATEGORY}, {len(account.destinataires)} destinataire(s)) pour {len(problematic)} source(s) en probleme.")
        else:
            self.log_cb("error", f"Echec de l'envoi de l'alerte mail de pretraitement : {msg}")

    def _append_result_row(self, source_label: str, file_result):
        row = self.results_table.rowCount()
        self.results_table.insertRow(row)
        self.results_table.setItem(row, RESULT_COL_SOURCE, QTableWidgetItem(source_label))
        filename_display = f"📌 {file_result.filename} (reference)" if file_result.is_reference else file_result.filename
        self.results_table.setItem(row, RESULT_COL_FICHIER, QTableWidgetItem(filename_display))

        label, bg, fg = STATUS_STYLES.get(file_result.status, STATUS_STYLES["Non controle"])
        status_item = QTableWidgetItem(label)
        status_item.setBackground(bg)
        status_item.setForeground(fg)
        status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.results_table.setItem(row, RESULT_COL_STATUT, status_item)

        detail_parts = list(file_result.errors) + list(file_result.warnings)
        if file_result.is_reference:
            detail_parts.insert(0, "Sert de reference structurelle pour les autres fichiers de ce dossier")
        if file_result.colonnes_detectees:
            detail_parts.append(f"Colonnes : {', '.join(file_result.colonnes_detectees)}")
        else:
            detail_parts.append("Colonnes : (aucune detectee)")
        details = "  |  ".join(detail_parts)
        self.results_table.setItem(row, RESULT_COL_DETAILS, QTableWidgetItem(details))

        for col in (RESULT_COL_SOURCE, RESULT_COL_FICHIER, RESULT_COL_DETAILS):
            item = self.results_table.item(row, col)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)

    def refresh_after_external_change(self):
        """A appeler si des sources ont ete ajoutees/modifiees/supprimees
        depuis un autre onglet, pour que la liste reste synchronisee."""
        self._refresh_sources_table()

    def set_read_only(self, read_only: bool) -> None:
        """V150 : grise les actions qui ECRIVENT une configuration partagee
        ou lancent un traitement (Administration OK/KO, ajout d'un type de
        TPA, Lancer le controle — qui enregistre le statut dans
        sources.json), pour un utilisateur dont le role n'est pas
        Administrateur. La simple consultation (tableaux, cases a cocher)
        reste toujours possible."""
        for btn in self._write_buttons:
            btn.setEnabled(not read_only)
            btn.setToolTip("Action reservee au role Administrateur." if read_only else "")

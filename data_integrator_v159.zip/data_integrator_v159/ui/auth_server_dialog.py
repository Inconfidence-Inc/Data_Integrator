from __future__ import annotations

from dataclasses import replace

from PySide6.QtWidgets import (
    QDialog, QFormLayout, QLineEdit, QComboBox, QVBoxLayout, QHBoxLayout,
    QLabel, QMessageBox, QPushButton, QCheckBox, QSpinBox, QWidget
)

from core.auth_config import AuthConfig, AuthConfigManager
from core.auth_db import test_auth_connection
from core.config_manager import ConfigManager
from core.log_manager import get_logger

DRIVERS = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "SQL Server",
]

AUTH_MODES = [
    ("sql", "Connexion SQL (utilisateur / mot de passe)"),
]


class AuthServerDialog(QDialog):
    """
    Ecran de parametrage de l'authentification centralisee (V148) : connexion
    a la base OUTILS (serveur Azure partage entre applications internes,
    dont Reco Compta) qui porte les comptes (USERS_PYTHON) et l'historique
    de connexion (USERS_PYTHON_HISTO). Reconstruit a partir d'une capture
    d'ecran de l'ecran equivalent de Reco Compta, sur demande explicite de
    l'utilisateur.
    """

    def __init__(self, auth_config_manager: AuthConfigManager, business_config: ConfigManager | None = None, parent=None):
        super().__init__(parent)
        self.auth_config_manager = auth_config_manager
        self.business_config = business_config
        self.setWindowTitle("Serveur d'authentification")
        self.setMinimumWidth(620)

        title = QLabel("🔐  Serveur d'authentification")
        title_font = title.font()
        title_font.setPointSize(title_font.pointSize() + 2)
        title_font.setBold(True)
        title.setFont(title_font)

        info = QLabel(
            "Base centrale qui porte les comptes (USERS_PYTHON et USERS_PYTHON_HISTO). "
            "Ce n'est PAS la base metier (ICI_BI / TECH_BI)."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#B3261E; font-weight:bold;")

        self.server_edit = QLineEdit()
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1, 65535)
        self.port_spin.setValue(1433)
        self.database_edit = QLineEdit()

        self.auth_mode_combo = QComboBox()
        for value, label in AUTH_MODES:
            self.auth_mode_combo.addItem(label, value)

        self.username_edit = QLineEdit()

        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        # Place-holder ajuste dynamiquement dans _load_from_config() : seul un
        # mot de passe DEJA enregistre justifie "(inchange)" — sur une
        # premiere configuration (rien d'enregistre), un champ vide laisse
        # tel quel enverrait un mot de passe VIDE au serveur (erreur SQL
        # 18456 trompeuse, comme si l'identifiant etait faux) sans que rien
        # ne le signale a l'utilisateur. Valeur par defaut ici, remplacee
        # juste apres par _load_from_config().
        self.password_edit.setPlaceholderText("mot de passe requis")
        self._toggle_pwd_btn = QPushButton("👁")
        self._toggle_pwd_btn.setFixedWidth(32)
        self._toggle_pwd_btn.setCheckable(True)
        self._toggle_pwd_btn.toggled.connect(self._on_toggle_password_visibility)
        pwd_row = QHBoxLayout()
        pwd_row.setContentsMargins(0, 0, 0, 0)
        pwd_row.addWidget(self.password_edit)
        pwd_row.addWidget(self._toggle_pwd_btn)
        pwd_wrap = QWidget()
        pwd_wrap.setLayout(pwd_row)

        pwd_help = QLabel("Laissez vide pour conserver le mot de passe enregistre.")
        pwd_help.setStyleSheet("color:#5c6577; font-style:italic;")

        self.driver_combo = QComboBox()
        self.driver_combo.addItems(DRIVERS)

        self.encrypt_check = QCheckBox("Encrypt (chiffrer la connexion)")
        self.trust_check = QCheckBox("TrustServerCertificate")
        chiffrement_row = QHBoxLayout()
        chiffrement_row.setContentsMargins(0, 0, 0, 0)
        chiffrement_row.addWidget(self.encrypt_check)
        chiffrement_row.addWidget(self.trust_check)
        chiffrement_row.addStretch()
        chiffrement_wrap = QWidget()
        chiffrement_wrap.setLayout(chiffrement_row)

        self.table_users_edit = QLineEdit()
        self.table_histo_edit = QLineEdit()
        tables_row = QHBoxLayout()
        tables_row.setContentsMargins(0, 0, 0, 0)
        tables_row.addWidget(self.table_users_edit)
        tables_row.addWidget(self.table_histo_edit)
        tables_wrap = QWidget()
        tables_wrap.setLayout(tables_row)

        self.code_app_edit = QLineEdit()

        form = QFormLayout()
        form.addRow("Serveur :", self.server_edit)
        form.addRow("Port :", self.port_spin)
        form.addRow("Base :", self.database_edit)
        form.addRow("Authentification :", self.auth_mode_combo)
        form.addRow("Utilisateur :", self.username_edit)
        form.addRow("Mot de passe :", pwd_wrap)
        form.addRow("", pwd_help)
        form.addRow("Pilote ODBC :", self.driver_combo)
        form.addRow("Chiffrement :", chiffrement_wrap)
        form.addRow("Tables :", tables_wrap)
        form.addRow("Code application :", self.code_app_edit)

        self.status_label = QLabel("")

        reuse_btn = QPushButton("Reprendre les parametres metier")
        reuse_btn.setObjectName("ghostBtn")
        reuse_btn.setToolTip(
            "Reprend le pilote ODBC du profil de connexion metier actif (serveur, base et "
            "identifiants restent propres a OUTILS, qui est une base distincte)."
        )
        reuse_btn.clicked.connect(self._on_reuse_business_params)

        test_btn = QPushButton("Tester")
        test_btn.setObjectName("ghostBtn")
        test_btn.clicked.connect(self._on_test)

        save_btn = QPushButton("Enregistrer et activer l'authentification centralisee")
        save_btn.setObjectName("primaryBtn")
        save_btn.clicked.connect(self._on_save_and_activate)

        cancel_btn = QPushButton("Annuler")
        cancel_btn.clicked.connect(self.reject)

        btn_row1 = QHBoxLayout()
        btn_row1.addWidget(reuse_btn)
        btn_row1.addWidget(test_btn)
        btn_row1.addStretch()

        btn_row2 = QHBoxLayout()
        btn_row2.addWidget(save_btn)
        btn_row2.addStretch()
        btn_row2.addWidget(cancel_btn)

        layout = QVBoxLayout()
        layout.addWidget(title)
        layout.addWidget(info)
        layout.addLayout(form)
        layout.addWidget(self.status_label)
        layout.addLayout(btn_row1)
        layout.addLayout(btn_row2)
        self.setLayout(layout)

        self._load_from_config()

    # ------------------------------------------------------------------

    def _on_toggle_password_visibility(self, checked: bool):
        self.password_edit.setEchoMode(
            QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password
        )

    def _load_from_config(self):
        cfg = self.auth_config_manager.config
        self.server_edit.setText(cfg.server)
        self.port_spin.setValue(cfg.port or 1433)
        self.database_edit.setText(cfg.database)
        idx = self.auth_mode_combo.findData(cfg.auth_mode)
        self.auth_mode_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.username_edit.setText(cfg.username)
        # Mot de passe jamais pre-rempli (meme s'il est deja enregistre) :
        # le champ reste vide, et seule une nouvelle saisie remplace la
        # valeur stockee (cf. capture d'ecran). Le placeholder affiche
        # depend de l'etat reel : "(inchange)" seulement si un mot de passe
        # est VRAIMENT deja enregistre (sinon ce texte laisserait croire a
        # tort qu'il suffit de ne rien saisir).
        self.password_edit.clear()
        self._password_already_saved = bool(cfg.password)
        self.password_edit.setPlaceholderText(
            "(inchange)" if self._password_already_saved else "mot de passe requis"
        )
        idx = self.driver_combo.findText(cfg.driver)
        self.driver_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.encrypt_check.setChecked(cfg.encrypt)
        self.trust_check.setChecked(cfg.trust_server_certificate)
        self.table_users_edit.setText(cfg.table_users)
        self.table_histo_edit.setText(cfg.table_histo)
        self.code_app_edit.setText(cfg.code_application)

    def _build_config_from_form(self, keep_existing_password_if_blank: bool = True) -> AuthConfig:
        existing = self.auth_config_manager.config
        password = self.password_edit.text()
        if not password and keep_existing_password_if_blank:
            password = existing.password
        return AuthConfig(
            server=self.server_edit.text().strip(),
            port=self.port_spin.value(),
            database=self.database_edit.text().strip() or "OUTILS",
            auth_mode=self.auth_mode_combo.currentData() or "sql",
            username=self.username_edit.text().strip(),
            password=password,
            driver=self.driver_combo.currentText(),
            encrypt=self.encrypt_check.isChecked(),
            trust_server_certificate=self.trust_check.isChecked(),
            table_users=self.table_users_edit.text().strip() or "USERS_PYTHON",
            table_histo=self.table_histo_edit.text().strip() or "USERS_PYTHON_HISTO",
            code_application=self.code_app_edit.text().strip() or "DATA_INTEGRATOR",
            active=existing.active,
        )

    def _on_reuse_business_params(self):
        if self.business_config is None:
            QMessageBox.information(self, "Indisponible", "Aucune configuration metier disponible.")
            return
        profile = self.business_config.get_active_connection()
        idx = self.driver_combo.findText(profile.driver)
        if idx >= 0:
            self.driver_combo.setCurrentIndex(idx)
        self.encrypt_check.setChecked(True)
        self.trust_check.setChecked(True)
        QMessageBox.information(
            self, "Parametres repris",
            "Pilote ODBC et chiffrement repris du profil de connexion metier actif.\n\n"
            "Serveur, base et identifiants restent a saisir : OUTILS est une base distincte "
            "de la base metier (serveur different)."
        )

    def _on_test(self):
        cfg = self._build_config_from_form()
        if not cfg.server:
            QMessageBox.warning(self, "Champs requis", "Le serveur est requis pour tester la connexion.")
            return
        if cfg.auth_mode == "sql" and not cfg.password:
            QMessageBox.warning(
                self, "Mot de passe requis",
                "Aucun mot de passe n'est enregistre pour l'instant : saisissez-le avant de "
                "tester (le champ vide n'est a laisser que pour CONSERVER un mot de passe deja "
                "enregistre, pas pour une premiere configuration)."
            )
            return
        self.status_label.setText("Test en cours...")
        ok, msg = test_auth_connection(cfg)
        if ok:
            self.status_label.setText("✅ " + msg)
            get_logger().info("Test de connexion au serveur d'authentification reussi (%s / %s).", cfg.server, cfg.database)
        else:
            self.status_label.setText("❌ Echec")
            get_logger().error("Echec du test de connexion au serveur d'authentification (%s / %s) : %s", cfg.server, cfg.database, msg)
            QMessageBox.warning(self, "Echec de connexion", msg)

    def _on_save_and_activate(self):
        cfg = self._build_config_from_form()
        if not cfg.server or not cfg.username:
            QMessageBox.warning(self, "Champs requis", "Serveur et utilisateur sont requis.")
            return
        if not cfg.table_users or not cfg.table_histo or not cfg.code_application:
            QMessageBox.warning(self, "Champs requis", "Les noms de tables et le code application sont requis.")
            return
        if cfg.auth_mode == "sql" and not cfg.password:
            QMessageBox.warning(
                self, "Mot de passe requis",
                "Aucun mot de passe n'est enregistre pour l'instant : saisissez-le avant "
                "d'activer l'authentification centralisee."
            )
            return

        confirm = QMessageBox.question(
            self, "Activer l'authentification centralisee",
            "Une fois enregistree, une connexion (identifiant / mot de passe) sera exigee a "
            "chaque prochain lancement de Data Integrator.\n\n"
            "Cette activation ne s'applique qu'au PROCHAIN lancement (la session en cours n'est "
            "pas interrompue). Confirmer l'enregistrement et l'activation ?",
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        cfg = replace(cfg, active=True)
        self.auth_config_manager.save(cfg)
        get_logger().info("Authentification centralisee activee (serveur=%s, base=%s, code_application=%s).", cfg.server, cfg.database, cfg.code_application)
        QMessageBox.information(self, "Authentification activee", "Configuration enregistree et authentification centralisee activee.")
        self.accept()

from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QComboBox, QPushButton,
    QLabel, QMessageBox, QTableWidget, QTableWidgetItem, QAbstractItemView,
    QHeaderView
)

from core.config_manager import TPA_TYPES, ConnectionProfile, SourceConfig

COL_PAYS, COL_TYPE, COL_TABLE = range(3)


class TablePickerDialog(QDialog):
    """Dialogue pour ajouter une nouvelle colonne (table) au pivot de mapping
    de la Fusion. Affiche en priorite les sources deja configurees dans le
    Chargement pour ce domaine (clic direct pour pre-remplir), avec un choix
    manuel TPA + table en repli/complement."""

    def __init__(
        self, connection: ConnectionProfile | None, parent=None,
        domaine: str | None = None, chargement_sources: list[SourceConfig] | None = None,
    ):
        super().__init__(parent)
        self.setWindowTitle("Ajouter une table au mapping")
        self.setMinimumWidth(560)
        self._connection = connection
        self._columns: list[str] = []
        chargement_sources = chargement_sources or []

        layout = QVBoxLayout()

        if chargement_sources:
            sources_label = QLabel(f"📂 Sources deja configurees dans le Chargement pour ce domaine (clic pour selectionner) :")
            sources_label.setWordWrap(True)
            sources_label.setStyleSheet("font-weight:600;")
            layout.addWidget(sources_label)

            self.sources_table = QTableWidget(len(chargement_sources), 3)
            self.sources_table.setHorizontalHeaderLabels(["Pays", "Type", "Table cible"])
            self.sources_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            self.sources_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            self.sources_table.verticalHeader().setVisible(False)
            self.sources_table.horizontalHeader().setSectionResizeMode(COL_TABLE, QHeaderView.ResizeMode.Stretch)
            self.sources_table.setMaximumHeight(160)
            for row, src in enumerate(chargement_sources):
                self.sources_table.setItem(row, COL_PAYS, QTableWidgetItem(src.pays))
                self.sources_table.setItem(row, COL_TYPE, QTableWidgetItem(src.type))
                self.sources_table.setItem(row, COL_TABLE, QTableWidgetItem(src.table))
            self.sources_table.cellClicked.connect(self._on_source_row_clicked)
            layout.addWidget(self.sources_table)

            sep = QLabel("— ou choix manuel —")
            sep.setStyleSheet("color:#5c6577; font-style:italic;")
            layout.addWidget(sep)
        else:
            self.sources_table = None

        self.type_combo = QComboBox()
        self.type_combo.setEditable(True)
        self.type_combo.addItems(TPA_TYPES)

        self.table_combo = QComboBox()
        self.table_combo.setEditable(True)
        refresh_btn = QPushButton("🔄")
        refresh_btn.setObjectName("ghostBtn")
        refresh_btn.setFixedWidth(36)
        refresh_btn.clicked.connect(self._refresh_tables)
        table_row = QHBoxLayout()
        table_row.addWidget(self.table_combo, stretch=1)
        table_row.addWidget(refresh_btn)

        form = QFormLayout()
        form.addRow("Type / TPA :", self.type_combo)
        form.addRow("Table source :", table_row)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color:#5c6577; font-style:italic;")

        load_btn = QPushButton("📥 Charger les colonnes")
        load_btn.setObjectName("primaryBtn")
        load_btn.clicked.connect(self._load_columns)

        btn_row = QHBoxLayout()
        cancel_btn = QPushButton("Annuler")
        cancel_btn.clicked.connect(self.reject)
        ok_btn = QPushButton("✅ Ajouter au mapping")
        ok_btn.setObjectName("primaryBtn")
        ok_btn.clicked.connect(self._on_ok)
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(ok_btn)

        layout.addLayout(form)
        layout.addWidget(load_btn)
        layout.addWidget(self.status_label)
        layout.addLayout(btn_row)
        self.setLayout(layout)

        if connection:
            self._refresh_tables()

    def _on_source_row_clicked(self, row: int, _col: int):
        pays = self.sources_table.item(row, COL_PAYS).text()
        type_tpa = self.sources_table.item(row, COL_TYPE).text()
        table = self.sources_table.item(row, COL_TABLE).text()
        self.type_combo.setCurrentText(type_tpa)
        self.table_combo.setEditText(table)
        self._load_columns()

    def _refresh_tables(self):
        if not self._connection:
            self.status_label.setText("⚠ Aucune connexion active.")
            return
        from core.db import list_tables
        current = self.table_combo.currentText()
        try:
            tables = list_tables(self._connection)
        except Exception as e:
            self.status_label.setText(f"⚠ Impossible de charger les tables : {e}")
            return
        self.table_combo.clear()
        self.table_combo.addItems(tables)
        self.table_combo.setEditText(current)
        self.status_label.setText(f"✅ {len(tables)} table(s) disponible(s)")

    def _load_columns(self):
        table = self.table_combo.currentText().strip()
        if not table or not self._connection:
            self.status_label.setText("⚠ Renseigne une table et verifie la connexion active.")
            return
        from core.db import list_columns
        try:
            self._columns = list_columns(self._connection, table)
        except Exception as e:
            self.status_label.setText(f"⚠ Impossible de charger les colonnes : {e}")
            return
        if not self._columns:
            self.status_label.setText(f"⚠ Aucune colonne trouvee pour {table}")
            return
        self.status_label.setText(f"✅ {len(self._columns)} colonne(s) chargee(s) depuis {table}")

    def _on_ok(self):
        if not self.type_combo.currentText().strip() or not self.table_combo.currentText().strip():
            QMessageBox.information(self, "Champs manquants", "Renseigne le TPA et la table source.")
            return
        if not self._columns:
            self._load_columns()
        if not self._columns:
            QMessageBox.information(self, "Colonnes manquantes", "Charge les colonnes de la table avant de continuer.")
            return
        self.accept()

    def result(self) -> tuple[str, str, list[str]]:
        return self.type_combo.currentText().strip(), self.table_combo.currentText().strip(), self._columns

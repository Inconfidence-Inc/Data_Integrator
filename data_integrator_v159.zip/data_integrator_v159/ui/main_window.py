from __future__ import annotations

import time

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QAction
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget,
    QTableWidgetItem, QPushButton, QProgressBar,
    QLabel, QMessageBox, QAbstractItemView, QHeaderView, QToolBar,
    QCheckBox, QGroupBox, QTabWidget, QComboBox, QLineEdit, QDialog,
    QSplitter
)

from core.config_manager import ConfigManager, SourceConfig, DOMAINES, EXPECTED_DATABASE
from core.loader_engine import LoaderSettings, SourceLoadResult
from core.auth_config import AuthConfigManager
from core.auth_db import AuthenticatedUser, log_event
from workers.load_worker import LoadWorker
from workers.row_count_worker import RowCountWorker
from ui.connection_dialog import ConnectionManagerDialog
from ui.auth_server_dialog import AuthServerDialog
from ui.source_editor_dialog import SourceEditorDialog, DOMAIN_LABELS
from ui.console_widget import ConsoleWidget
from ui.mail_window import MailWindow
from ui.log_window import LogWindow
from ui.fusion_tab import FusionTab
from ui.preprocessing_tab import PreprocessingTab
from ui.statistics_tab import StatisticsTab
from ui.material_colors import STATUS_COLORS
from ui.elevation import apply_card_elevation


COL_CHECK, COL_TPA, COL_DOSSIER, COL_LIGNES_EST, COL_TABLE, COL_HIST, COL_PRETRAIT, COL_STATUT, COL_LIGNES = range(9)

# Duree au-dela de laquelle un calcul de lignes encore "en cours" est
# considere comme bloque (lecteur reseau stalle, sans timeout possible sur
# une lecture de fichier) plutot que juste lent — permet de le relancer au
# lieu de le laisser bloque indefiniment.
STUCK_WORKER_THRESHOLD_S = 10 * 60

# Delai de grace (secondes) apres un clic sur "Annuler" avant de forcer
# l'arret du thread de chargement s'il ne repond toujours pas (V84) :
# nettement superieur a LoaderSettings.sql_timeout_seconds (120s) pour
# laisser au mecanisme normal (timeout SQL -> exception -> stop_flag) le
# temps de fonctionner en priorite ; l'arret force n'est qu'un filet de
# securite pour les cas ou meme ce timeout ne suffit pas (connexion
# reellement figee au niveau du systeme).
CANCEL_FORCE_TERMINATE_AFTER_S = 180
HEADERS = ["", "TPA", "Dossier source", "Nombre de lignes", "Table cible", "Historique", "Prétraitement", "Statut", "Lignes chargees"]

STATUS_ICONS = {
    "En attente": "⏸ En attente",
    "En cours":   "⏳ En cours",
    "OK":         "✅ OK",
    "Erreur":     "❌ Erreur",
    "Annule":     "🚫 Annule",
}
STATUS_STYLES = {
    status: (label, QColor(STATUS_COLORS[status][0]), QColor(STATUS_COLORS[status][1]))
    for status, label in STATUS_ICONS.items()
}

DOMAIN_TAB_ICONS = {"Adhesion": "📝", "Sinistre": "🚑", "FIC": "📄"}

PRETRAIT_STYLES = {
    "Non controle":  ("⏸ Non controle", QColor("#F1F3F4"), QColor("#5F6368")),
    "OK":            ("✅ OK", QColor("#E6F4EA"), QColor("#0D652D")),
    "Avertissement": ("⚠️ Avert.", QColor("#FEF7E0"), QColor("#7A4E00")),
    "Erreur":        ("❌ Erreur", QColor("#F9DEDC"), QColor("#410E0B")),
}


class MainWindow(QMainWindow):
    def __init__(self, current_user: AuthenticatedUser | None = None):
        super().__init__()
        self.current_user = current_user
        self.auth_config_manager = AuthConfigManager()
        title = "Data Integrator — ICI Assurance"
        if current_user is not None:
            title += f" — Connecte : {current_user.prenom} {current_user.nom} ({current_user.role})"
        self.setWindowTitle(title)
        self.resize(1360, 900)

        self.config = ConfigManager()
        self.worker: LoadWorker | None = None
        self.log_window = LogWindow(parent=None)

        # Cache de la liste des tables par profil de connexion (id -> liste),
        # pour eviter de refaire une requete reseau a chaque ouverture d'un
        # formulaire de source. Le bouton "Recharger" du formulaire force
        # toujours une actualisation reelle et met a jour ce cache.
        self._table_list_cache: dict[str, list[str]] = {}
        self._row_count_workers: dict[str, RowCountWorker] = {}
        self._row_count_worker_started_at: dict[str, float] = {}
        self._row_count_folder_at_start: dict[str, str] = {}
        self._open_source_dialogs: list = []
        self._loading_tables = False

        self.domain_tables: dict[str, QTableWidget] = {}
        self.domain_rows: dict[str, dict[str, int]] = {d: {} for d in DOMAINES}

        # V150 : actions/boutons qui ECRIVENT une configuration partagee
        # (profils de connexion, sources) ou lancent le chargement reel en
        # base — grises pour un utilisateur dont le role (authentification
        # centralisee) n'est pas Administrateur, via _apply_role_restrictions().
        self._write_widgets: list = []

        self._build_ui()
        self._refresh_all_tables()
        self._refresh_connection_label()
        self._apply_role_restrictions()
        self._log("info", "Application demarree.")

    # ------------------------------------------------------------------
    # Construction UI
    # ------------------------------------------------------------------

    def _build_ui(self):
        toolbar = QToolBar("Actions")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        conn_action = QAction("⚙  Connexions", self)
        conn_action.triggered.connect(self._open_connection_dialog)
        self._write_widgets.append(conn_action)
        toolbar.addAction(conn_action)

        mail_action = QAction("📧  Mails", self)
        mail_action.triggered.connect(self._open_mail_window)
        toolbar.addAction(mail_action)

        logs_action = QAction("🪵  Logs", self)
        logs_action.triggered.connect(self._open_log_window)
        toolbar.addAction(logs_action)

        # Ecran de parametrage de l'authentification centralisee (V148) :
        # toujours visible tant qu'elle n'est pas encore activee (il faut
        # bien pouvoir la configurer la premiere fois, avant qu'aucun
        # utilisateur ne soit authentifie), puis reserve au role
        # "Administrateur" une fois activee, pour eviter qu'un utilisateur
        # courant ne modifie le serveur de comptes partage.
        if not self.auth_config_manager.config.active or (
            self.current_user is not None and self.current_user.role == "Administrateur"
        ):
            auth_action = QAction("🔐  Authentification", self)
            auth_action.triggered.connect(self._open_auth_server_dialog)
            toolbar.addAction(auth_action)

        central = QWidget()
        self.setCentralWidget(central)
        outer_layout = QVBoxLayout(central)
        outer_layout.setContentsMargins(0, 0, 0, 0)

        self.app_tabs = QTabWidget()
        outer_layout.addWidget(self.app_tabs)

        self.preprocessing_tab = PreprocessingTab(self.config, log_cb=self._log, on_sources_changed=self._refresh_all_tables)
        self.app_tabs.addTab(self.preprocessing_tab, "🔍  Pretraitement")
        self.app_tabs.addTab(self._build_loading_page(), "📥  Chargement")
        self.fusion_tab = FusionTab(self.config, log_cb=self._log)
        self.app_tabs.addTab(self.fusion_tab, "🔀  Fusion")
        self.statistics_tab = StatisticsTab(self.config, log_cb=self._log)
        self.app_tabs.addTab(self.statistics_tab, "📊  Statistiques")

    def _build_loading_page(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setSpacing(18)
        outer.setContentsMargins(18, 18, 18, 18)

        conn_group = self._build_connection_group()
        sources_group = self._build_sources_group()
        exec_group = self._build_execution_group()
        console_group = self._build_console_group()

        for group in (conn_group, sources_group, exec_group, console_group):
            apply_card_elevation(group)

        # V103 : la connexion reste fixe en haut (une seule ligne, pas
        # besoin de redimensionner), mais Sources / Execution / Console
        # sont places dans un vrai separateur ajustable (QSplitter) — sur
        # demande explicite de l'utilisateur, pour pouvoir tirer et donner
        # plus de place au tableau des sources (ou a la console) selon ses
        # besoins, plutot qu'une repartition figee dans le code.
        outer.addWidget(conn_group)

        self.loading_splitter = QSplitter(Qt.Orientation.Vertical)
        self.loading_splitter.setHandleWidth(10)
        self.loading_splitter.setChildrenCollapsible(False)
        self.loading_splitter.addWidget(sources_group)
        self.loading_splitter.addWidget(exec_group)
        self.loading_splitter.addWidget(console_group)
        # Tailles initiales raisonnables (l'utilisateur peut ensuite les
        # ajuster librement en tirant les poignees entre les blocs).
        self.loading_splitter.setSizes([500, 160, 200])
        self.loading_splitter.setStretchFactor(0, 4)
        self.loading_splitter.setStretchFactor(1, 0)
        self.loading_splitter.setStretchFactor(2, 1)
        outer.addWidget(self.loading_splitter, stretch=1)

        return page

    def _build_connection_group(self) -> QGroupBox:
        group = QGroupBox("🔌  Connexion SQL Server active")
        row = QHBoxLayout(group)

        row.addWidget(QLabel("Environnement :"))
        self.conn_combo = QComboBox()
        self.conn_combo.currentIndexChanged.connect(self._on_connection_combo_changed)
        row.addWidget(self.conn_combo)

        self.default_conn_btn = QPushButton("☆ Definir par defaut")
        self.default_conn_btn.setObjectName("ghostBtn")
        self.default_conn_btn.setToolTip("Utiliser automatiquement cet environnement a chaque lancement de l'application")
        self.default_conn_btn.clicked.connect(self._on_set_default_connection)
        self._write_widgets.append(self.default_conn_btn)
        row.addWidget(self.default_conn_btn)

        row.addWidget(QLabel("Serveur :"))
        self.conn_server_edit = QLineEdit()
        self.conn_server_edit.setMinimumWidth(160)
        self._write_widgets.append(self.conn_server_edit)
        row.addWidget(self.conn_server_edit)

        row.addWidget(QLabel("Base :"))
        self.conn_database_edit = QLineEdit()
        self.conn_database_edit.setMinimumWidth(90)
        self._write_widgets.append(self.conn_database_edit)
        row.addWidget(self.conn_database_edit)

        row.addWidget(QLabel("Utilisateur :"))
        self.conn_username_edit = QLineEdit()
        self.conn_username_edit.setPlaceholderText("optionnel — vide = auth Windows")
        self.conn_username_edit.setMinimumWidth(110)
        self._write_widgets.append(self.conn_username_edit)
        row.addWidget(self.conn_username_edit)

        row.addWidget(QLabel("Mot de passe :"))
        self.conn_password_edit = QLineEdit()
        self.conn_password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.conn_password_edit.setPlaceholderText("optionnel")
        self.conn_password_edit.setMinimumWidth(110)
        self._write_widgets.append(self.conn_password_edit)
        row.addWidget(self.conn_password_edit)

        self.conn_status_label = QLabel("")
        row.addWidget(self.conn_status_label)
        row.addStretch()

        save_btn = QPushButton("💾 Enregistrer")
        save_btn.setObjectName("ghostBtn")
        save_btn.setToolTip("Enregistrer le serveur et la base saisis pour ce profil de connexion")
        save_btn.clicked.connect(self._save_connection_fields)
        self._write_widgets.append(save_btn)
        test_btn = QPushButton("⚡ Tester")
        test_btn.setObjectName("ghostBtn")
        test_btn.clicked.connect(self._test_connection_quick)
        modify_btn = QPushButton("✏️ Modifier")
        modify_btn.setObjectName("ghostBtn")
        modify_btn.clicked.connect(self._open_connection_dialog)
        self._write_widgets.append(modify_btn)

        row.addWidget(save_btn)
        row.addWidget(test_btn)
        row.addWidget(modify_btn)
        return group

    def _on_set_default_connection(self):
        active = self.config.get_active_connection()
        if self.config.default_connection_id == active.id:
            # Deja par defaut : un second clic retire ce choix (retour au
            # comportement "dernier profil utilise").
            self.config.set_default_connection("")
            self._log("info", f"'{active.nom}' n'est plus la connexion par defaut au demarrage.")
        else:
            self.config.set_default_connection(active.id)
            self._log("success", f"'{active.nom}' sera utilise automatiquement a chaque lancement de l'application.")
        self._update_default_conn_btn()

    def _update_default_conn_btn(self):
        active = self.config.get_active_connection()
        if self.config.default_connection_id == active.id:
            self.default_conn_btn.setText(f"★ Par defaut ({active.nom})")
        else:
            self.default_conn_btn.setText("☆ Definir par defaut")

    def _build_sources_group(self) -> QGroupBox:
        group = QGroupBox("📂  Sources a charger")
        layout = QVBoxLayout(group)

        self.tab_widget = QTabWidget()
        for domaine in DOMAINES:
            table = self._build_domain_table()
            table.itemChanged.connect(lambda item, d=domaine: self._on_source_table_item_changed(d, item))
            self.domain_tables[domaine] = table
            icon = DOMAIN_TAB_ICONS.get(domaine, "")
            label = DOMAIN_LABELS.get(domaine, domaine)
            self.tab_widget.addTab(table, f"{icon}  {label}")
        layout.addWidget(self.tab_widget, stretch=1)

        btn_row = QHBoxLayout()
        add_btn = QPushButton("➕ Ajouter")
        add_btn.clicked.connect(self._add_source)
        self._write_widgets.append(add_btn)
        edit_btn = QPushButton("✏️ Modifier")
        edit_btn.clicked.connect(self._edit_selected_source)
        self._write_widgets.append(edit_btn)
        del_btn = QPushButton("🗑️ Supprimer")
        del_btn.setObjectName("dangerBtn")
        del_btn.clicked.connect(self._delete_selected_source)
        self._write_widgets.append(del_btn)
        select_all_btn = QPushButton("☑ Tout cocher (onglet)")
        select_all_btn.setObjectName("ghostBtn")
        select_all_btn.clicked.connect(lambda: self._set_current_tab_checked(True))
        select_none_btn = QPushButton("☐ Tout decocher (onglet)")
        select_none_btn.setObjectName("ghostBtn")
        select_none_btn.clicked.connect(lambda: self._set_current_tab_checked(False))
        calc_all_btn = QPushButton("🔄 Tout calculer (onglet)")
        calc_all_btn.setObjectName("ghostBtn")
        calc_all_btn.setToolTip("Calculer le nombre de lignes des TPA pas encore calcules de ce domaine, en parallele")
        calc_all_btn.clicked.connect(self._calculate_all_visible_rows)
        recalc_all_btn = QPushButton("🔁 Tout RECALCULER (onglet)")
        recalc_all_btn.setObjectName("ghostBtn")
        recalc_all_btn.setToolTip("Force le recalcul de TOUS les TPA de ce domaine, meme ceux deja calcules, en parallele")
        recalc_all_btn.clicked.connect(self._recalculate_all_visible_rows)
        recalc_selection_btn = QPushButton("🔁 Recalculer la selection")
        recalc_selection_btn.setObjectName("ghostBtn")
        recalc_selection_btn.setToolTip("Force le recalcul uniquement des TPA coches (cases a cocher), meme deja calcules, en parallele")
        recalc_selection_btn.clicked.connect(self._recalculate_checked_sources)

        btn_row.addWidget(add_btn)
        btn_row.addWidget(edit_btn)
        btn_row.addWidget(del_btn)
        btn_row.addStretch()
        btn_row.addWidget(recalc_selection_btn)
        btn_row.addWidget(recalc_all_btn)
        btn_row.addWidget(calc_all_btn)
        btn_row.addWidget(select_all_btn)
        btn_row.addWidget(select_none_btn)
        layout.addLayout(btn_row)
        return group

    def _build_domain_table(self) -> QTableWidget:
        table = QTableWidget(0, len(HEADERS))
        table.setHorizontalHeaderLabels(HEADERS)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setAlternatingRowColors(True)
        table.horizontalHeader().setSectionResizeMode(COL_DOSSIER, QHeaderView.ResizeMode.Stretch)
        table.horizontalHeader().setSectionResizeMode(COL_TABLE, QHeaderView.ResizeMode.Stretch)
        table.verticalHeader().setVisible(False)
        table.verticalHeader().setDefaultSectionSize(40)
        table.horizontalHeader().setMinimumHeight(40)
        table.setColumnWidth(COL_CHECK, 36)
        table.setColumnWidth(COL_TPA, 140)  # V133 : suffisant pour "SPB (Pologne)", le plus long libellé
        table.setColumnWidth(COL_LIGNES_EST, 140)  # assez large pour le bouton "🔄 Calculer" (V58)
        table.setMinimumHeight(320)
        font = table.font()
        font.setPointSize(font.pointSize() + 1)
        table.setFont(font)
        return table

    def _build_execution_group(self) -> QGroupBox:
        group = QGroupBox("▶️  Execution")
        layout = QVBoxLayout(group)

        run_row = QHBoxLayout()
        self.load_btn = QPushButton("▶  Charger la selection (tous domaines)")
        self.load_btn.setObjectName("primaryBtn")
        self.load_btn.clicked.connect(self._start_loading)
        self._write_widgets.append(self.load_btn)
        self.cancel_btn = QPushButton("■  Annuler")
        self.cancel_btn.setObjectName("dangerBtn")
        self.cancel_btn.clicked.connect(self._cancel_loading)
        self.cancel_btn.setEnabled(False)

        self.global_progress = QProgressBar()
        self.global_progress.setFormat("%v / %m sources")

        run_row.addWidget(self.load_btn)
        run_row.addWidget(self.cancel_btn)
        run_row.addWidget(self.global_progress, stretch=1)
        layout.addLayout(run_row)

        from core.notification_settings import NotificationSettingsManager
        self.notification_settings = NotificationSettingsManager()
        self.mail_dsi_checkbox = QCheckBox("📧 Envoyer un mail a la DSI a l'issue de chaque TPA charge (avec detail du traitement)")
        self.mail_dsi_checkbox.setChecked(self.notification_settings.settings.mail_dsi_apres_chargement)
        self.mail_dsi_checkbox.toggled.connect(self._on_mail_dsi_toggled)
        layout.addWidget(self.mail_dsi_checkbox)

        self.file_progress_label = QLabel("")
        self.file_progress = QProgressBar()
        layout.addWidget(self.file_progress_label)
        layout.addWidget(self.file_progress)
        return group

    def _on_mail_dsi_toggled(self, checked: bool):
        self.notification_settings.set_mail_dsi_apres_chargement(checked)
        self._log("info", f"Mail DSI automatique apres chaque TPA charge : {'active' if checked else 'desactive'}.")

    def _build_console_group(self) -> QGroupBox:
        group = QGroupBox("🖥️  Console")
        layout = QVBoxLayout(group)
        self.console = ConsoleWidget()
        layout.addWidget(self.console)

        clear_row = QHBoxLayout()
        clear_row.addStretch()
        open_logs_btn = QPushButton("Ouvrir le journal complet")
        open_logs_btn.setObjectName("ghostBtn")
        open_logs_btn.clicked.connect(self._open_log_window)
        clear_btn = QPushButton("Effacer la console")
        clear_btn.setObjectName("ghostBtn")
        clear_btn.clicked.connect(self.console.clear_console)
        clear_row.addWidget(open_logs_btn)
        clear_row.addWidget(clear_btn)
        layout.addLayout(clear_row)
        return group

    # ------------------------------------------------------------------
    # Tableaux des sources (par domaine)
    # ------------------------------------------------------------------

    def _current_domain(self) -> str:
        return DOMAINES[self.tab_widget.currentIndex()]

    def _refresh_all_tables(self):
        self._loading_tables = True
        try:
            for domaine in DOMAINES:
                self._refresh_domain_table(domaine)
        finally:
            self._loading_tables = False

    def _refresh_domain_table(self, domaine: str):
        table = self.domain_tables[domaine]
        table.setRowCount(0)
        self.domain_rows[domaine].clear()
        for source in self.config.sources:
            if source.domaine == domaine:
                self._append_source_row(source)

    def _append_source_row(self, source: SourceConfig):
        table = self.domain_tables[source.domaine]
        row = table.rowCount()
        table.insertRow(row)
        self.domain_rows[source.domaine][source.id] = row

        check = QCheckBox()
        check_widget = QWidget()
        check_layout = QHBoxLayout(check_widget)
        check_layout.addWidget(check)
        check_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        check_layout.setContentsMargins(0, 0, 0, 0)
        table.setCellWidget(row, COL_CHECK, check_widget)
        check.setProperty("source_id", source.id)

        from core.config_manager import types_avec_plusieurs_pays, label_tpa
        types_multi_pays = types_avec_plusieurs_pays(self.config.sources, source.domaine)
        table.setItem(row, COL_TPA, QTableWidgetItem(label_tpa(source.type, source.pays, types_multi_pays)))
        table.setItem(row, COL_DOSSIER, QTableWidgetItem(source.dossier_source))
        table.setItem(row, COL_LIGNES_EST, QTableWidgetItem(""))  # remplace par _refresh_lignes_est_cell
        self._refresh_lignes_est_cell(source)
        table.setItem(row, COL_TABLE, QTableWidgetItem(source.table))
        hist_item = QTableWidgetItem("🗑 Vide" if source.vider_avant_integration else "📚 Conserve")
        hist_item.setFlags(hist_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        hist_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        table.setItem(row, COL_HIST, hist_item)
        pretrait_label, pretrait_bg, pretrait_fg = PRETRAIT_STYLES.get(source.pretraitement_statut, PRETRAIT_STYLES["Non controle"])
        pretrait_item = QTableWidgetItem(pretrait_label)
        pretrait_item.setFlags(pretrait_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        pretrait_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        pretrait_item.setBackground(pretrait_bg)
        pretrait_item.setForeground(pretrait_fg)
        table.setItem(row, COL_PRETRAIT, pretrait_item)
        self._set_row_status(source.domaine, row, "En attente")
        table.setItem(row, COL_LIGNES, QTableWidgetItem("-"))

        for col in (COL_TPA, COL_LIGNES_EST, COL_TABLE, COL_LIGNES):
            item = table.item(row, col)
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            item.setData(Qt.ItemDataRole.UserRole, source.id)
        # COL_DOSSIER reste editable directement dans le tableau (double-clic) :
        # l'enregistrement se fait automatiquement via _on_source_table_item_changed.
        dossier_item = table.item(row, COL_DOSSIER)
        dossier_item.setFlags(dossier_item.flags() | Qt.ItemFlag.ItemIsEditable)
        dossier_item.setData(Qt.ItemDataRole.UserRole, source.id)
        dossier_item.setToolTip("Double-clique pour modifier directement ce dossier (enregistrement automatique)")

    def _set_row_status(self, domaine: str, row: int, status: str):
        table = self.domain_tables[domaine]
        label, bg_color, fg_color = STATUS_STYLES.get(status, (status, QColor("#eef1f6"), QColor("#1f2933")))
        item = QTableWidgetItem(label)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        item.setBackground(bg_color)
        item.setForeground(fg_color)
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        table.setItem(row, COL_STATUT, item)

    def _row_for_source(self, source: SourceConfig) -> int | None:
        return self.domain_rows.get(source.domaine, {}).get(source.id)

    def _checked_sources(self) -> list[SourceConfig]:
        result = []
        for source in self.config.sources:
            row = self._row_for_source(source)
            if row is None:
                continue
            table = self.domain_tables[source.domaine]
            check_widget = table.cellWidget(row, COL_CHECK)
            checkbox = check_widget.findChild(QCheckBox) if check_widget else None
            if checkbox and checkbox.isChecked():
                result.append(source)
        return result

    def _selected_source(self) -> SourceConfig | None:
        domaine = self._current_domain()
        table = self.domain_tables[domaine]
        row = table.currentRow()
        if row < 0:
            return None
        item = table.item(row, COL_TPA)
        source_id = item.data(Qt.ItemDataRole.UserRole)
        return self.config.get_source(source_id)

    def _refresh_lignes_est_cell(self, source: SourceConfig, force_button: bool = False):
        """
        Met a jour la cellule "Nombre de lignes" de la source selon son etat :
          - deja calcule -> texte simple (nombre)
          - calcul en cours -> texte "Calcul en cours..."
          - rien encore -> petit bouton "Calculer" cliquable, qui declenche le
            calcul UNIQUEMENT sur ce clic explicite (jamais automatiquement a
            la simple selection/clic sur la ligne).

        force_button=True force l'affichage du bouton sans se fier a l'etat
        de self._row_count_workers : necessaire car le signal finished_count
        (qui declenche la mise a jour finale de cette cellule) peut arriver
        AVANT le signal finished qui retire l'entree de ce dict (ordre non
        garanti entre deux signaux distincts emis l'un juste apres l'autre
        depuis le meme thread) — sans ce parametre, un dossier vide restait
        bloque indefiniment sur "Calcul en cours..." au lieu de revenir au
        bouton "Calculer".
        """
        row = self.domain_rows.get(source.domaine, {}).get(source.id)
        if row is None:
            return
        table = self.domain_tables[source.domaine]

        if not force_button and source.nb_lignes_estimees:
            table.removeCellWidget(row, COL_LIGNES_EST)
            text = f"{source.nb_lignes_estimees:,}".replace(",", " ")
            table.item(row, COL_LIGNES_EST).setText(text)
            return

        if not force_button and source.id in self._row_count_workers:
            table.removeCellWidget(row, COL_LIGNES_EST)
            table.item(row, COL_LIGNES_EST).setText("⏳ Calcul en cours...")
            return

        table.item(row, COL_LIGNES_EST).setText("")
        calc_btn = QPushButton("🔄 Calculer")
        calc_btn.setObjectName("ghostBtn")
        calc_btn.setToolTip("Calculer le nombre exact de lignes pour cette source")
        calc_btn.clicked.connect(lambda checked=False, sid=source.id: self._start_row_count_for_source_id(sid))
        table.setCellWidget(row, COL_LIGNES_EST, calc_btn)

    def _on_source_table_item_changed(self, domaine: str, item):
        """
        Reagit a une modification directe dans le tableau. Seule la colonne
        Dossier source est editable en ligne : toute modification y est
        enregistree IMMEDIATEMENT (plus besoin de rouvrir "Modifier" juste
        pour changer un chemin), et comme le contenu du dossier peut avoir
        change, le nombre de lignes precedemment calcule est reinitialise
        (la cellule repasse au bouton "Calculer", prete a etre relancee).
        """
        if self._loading_tables:
            return
        if item.column() != COL_DOSSIER:
            return
        source_id = item.data(Qt.ItemDataRole.UserRole)
        if not source_id:
            return
        source = self.config.get_source(source_id)
        if not source:
            return
        new_folder = item.text().strip()
        if new_folder == source.dossier_source:
            return  # rien de reellement modifie

        self.config.update_source(
            source_id, dossier_source=new_folder,
            nb_fichiers_estimes=0, nb_lignes_estimees=0,
        )
        updated = self.config.get_source(source_id)
        self._refresh_lignes_est_cell(updated)
        self.preprocessing_tab.refresh_after_external_change()
        self.statistics_tab.refresh_after_external_change()
        self._log("success", f"Dossier source enregistre pour {source.pays} / {source.type} : {new_folder}")

    def _start_row_count_for_source_id(self, source_id: str):
        source = self.config.get_source(source_id)
        if source:
            self._ensure_row_count_computed(source)

    def _calculate_all_visible_rows(self):
        """
        Bouton "Tout calculer (onglet)" : declenche le calcul du nombre de
        lignes pour les sources du domaine actuellement affiche qui n'ont pas
        encore ete calculees, en parallele (un thread independant par
        source, cf. V44 — aucun risque de plantage ni de ralentissement de
        l'IHM meme pour de nombreux TPA a la fois)."""
        domaine = self._current_domain()
        sources = [s for s in self.config.sources if s.domaine == domaine]
        if not sources:
            return
        nb_lances = 0
        for source in sources:
            if not source.nb_lignes_estimees and source.id not in self._row_count_workers:
                nb_lances += 1
            self._ensure_row_count_computed(source)
        self._log("info", f"Calcul du nombre de lignes lance pour {nb_lances} source(s) du domaine {DOMAIN_LABELS.get(domaine, domaine)} (en parallele).")

    def _recalculate_all_visible_rows(self):
        """
        Bouton "Tout RECALCULER (onglet)" : force le recalcul de TOUTES les
        sources du domaine affiche, MEME celles deja calculees (contrairement
        a "Tout calculer" qui ne remplit que les cases encore vides)."""
        domaine = self._current_domain()
        sources = [s for s in self.config.sources if s.domaine == domaine]
        self._force_recalculate_sources(
            sources,
            titre="Tout recalculer",
            message=f"Recalculer le nombre de lignes pour les {len(sources)} source(s) de ce domaine, y compris celles deja calculees ?",
            libelle_log=f"toutes les sources du domaine {DOMAIN_LABELS.get(domaine, domaine)}",
        )

    def _recalculate_checked_sources(self):
        """
        Bouton "Recalculer la selection" : force le recalcul UNIQUEMENT des
        sources actuellement cochees (memes cases que pour "Charger la
        selection"), meme si elles sont deja calculees — pratique pour ne
        relancer que quelques TPA precis plutot que tout un domaine."""
        sources = self._checked_sources()
        if not sources:
            QMessageBox.information(self, "Aucune selection", "Coche au moins une source a recalculer.")
            return
        self._force_recalculate_sources(
            sources,
            titre="Recalculer la selection",
            message=f"Recalculer le nombre de lignes pour les {len(sources)} source(s) cochee(s), y compris celles deja calculees ?",
            libelle_log=f"{len(sources)} source(s) cochee(s)",
        )

    def _force_recalculate_sources(self, sources: list[SourceConfig], titre: str, message: str, libelle_log: str):
        """
        Logique commune a "Tout RECALCULER" et "Recalculer la selection" :
        remet a zero le comptage memorise puis relance un calcul pour chaque
        source fournie, en parallele (un thread independant par TPA, cf.
        V44/V39 — aucun risque de plantage ni de ralentissement de l'IHM),
        en s'appuyant sur la methode de comptage ultra rapide (V47)."""
        if not sources:
            return

        confirm = QMessageBox.question(
            self, titre, message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        nb_lances = 0
        for source in sources:
            if self._is_row_count_worker_stuck(source.id):
                worker = self._row_count_workers[source.id]
                self._log("warning", f"Calcul bloque depuis plus de {STUCK_WORKER_THRESHOLD_S // 60} min pour {source.pays} / {source.type} — arret force et nouvelle tentative.")
                worker.terminate()
                worker.wait(2000)
                self._row_count_workers.pop(source.id, None)
                self._row_count_worker_started_at.pop(source.id, None)
            elif source.id in self._row_count_workers:
                continue  # deja en cours (normalement), pas de doublon
            self.config.update_source(source.id, nb_fichiers_estimes=0, nb_lignes_estimees=0)
            refreshed = self.config.get_source(source.id)
            self._refresh_lignes_est_cell(refreshed)
            self._ensure_row_count_computed(refreshed)
            nb_lances += 1
        self._log("info", f"Recalcul force lance pour {nb_lances} source(s) sur {libelle_log} (en parallele, methode ultra rapide V47).")

    def _is_row_count_worker_stuck(self, source_id: str) -> bool:
        """Un calcul \"en cours\" depuis plus de STUCK_WORKER_THRESHOLD_S est
        tres probablement bloque (lecteur reseau stalle, aucun timeout
        possible sur une lecture de fichier) plutot que juste lent. Sans
        cette detection, une source pouvait rester bloquee indefiniment,
        impossible a recalculer meme via \"Tout RECALCULER\"."""
        if source_id not in self._row_count_workers:
            return False
        started_at = self._row_count_worker_started_at.get(source_id)
        return bool(started_at and (time.monotonic() - started_at) > STUCK_WORKER_THRESHOLD_S)

    def _ensure_row_count_computed(self, source: SourceConfig):
        if source.nb_fichiers_estimes or source.nb_lignes_estimees:
            return  # deja calcule precedemment
        if not source.dossier_source:
            # Auparavant un no-op silencieux : rien ne se passait et rien
            # n'expliquait pourquoi, donnant l'impression a tort que la
            # source \"ne se recalcule pas\". Desormais explicite.
            row = self.domain_rows.get(source.domaine, {}).get(source.id)
            if row is not None:
                table = self.domain_tables[source.domaine]
                table.removeCellWidget(row, COL_LIGNES_EST)
                item = table.item(row, COL_LIGNES_EST)
                if item:
                    item.setText("⚠ Aucun dossier renseigne")
            return
        if source.id in self._row_count_workers:
            if self._is_row_count_worker_stuck(source.id):
                # Calcul en cours depuis anormalement longtemps : tres
                # probablement bloque (lecteur reseau stalle, sans timeout
                # possible sur une lecture de fichier). Sans ce filet, la
                # source restait bloquee indefiniment, impossible a
                # recalculer meme via "Tout RECALCULER", jusqu'a redemarrer
                # l'application. On force l'arret et on relance proprement.
                worker = self._row_count_workers[source.id]
                self._log("warning", f"Calcul bloque depuis plus de {STUCK_WORKER_THRESHOLD_S // 60} min pour {source.pays} / {source.type} — arret force et nouvelle tentative.")
                worker.terminate()
                worker.wait(2000)
                self._row_count_workers.pop(source.id, None)
                self._row_count_worker_started_at.pop(source.id, None)
            else:
                return  # un calcul est deja en cours pour cette source, pas de doublon

        self._refresh_lignes_est_cell(source)  # bascule la cellule en "Calcul en cours..."

        self._log("info", f"Calcul du nombre exact de lignes pour {source.pays} / {source.type} (en arriere-plan)...")
        # Volontairement AUCUN parent Qt : voir la note detaillee dans
        # source_editor_dialog.py._update_row_count() — meme risque ici si
        # la fenetre principale se fermait pendant que ce calcul tourne
        # encore. La reference dans self._row_count_workers (+ le registre
        # global core.thread_registry) suffit a maintenir ce thread en vie
        # cote Python sans dependre de l'arbre d'objets Qt.
        worker = RowCountWorker(source.id, source.dossier_source, source.header_mode)
        # Memorise le dossier utilise pour CE calcul : si l'utilisateur modifie
        # le dossier source pendant que ce calcul tourne encore, le resultat
        # (calcule sur l'ANCIEN dossier) doit etre ignore a son retour plutot
        # que d'etre attribue par erreur au nouveau dossier affiche.
        self._row_count_folder_at_start[source.id] = source.dossier_source
        worker.finished_count.connect(self._on_row_count_finished)
        worker.failed.connect(self._on_row_count_failed)
        worker.progress.connect(self._on_row_count_progress)
        worker.finished.connect(lambda sid=source.id: self._row_count_workers.pop(sid, None))
        worker.finished.connect(lambda sid=source.id: self._row_count_worker_started_at.pop(sid, None))
        self._row_count_workers[source.id] = worker
        self._row_count_worker_started_at[source.id] = time.monotonic()
        worker.start()

    def _on_row_count_progress(self, source_id: str, traites: int, total: int, nom_fichier: str):
        """Met a jour la cellule et journalise regulierement (pas a chaque
        fichier, pour ne pas noyer les logs) pendant un calcul de lignes
        potentiellement long — pour ne jamais donner l'impression qu'un
        calcul est bloque quand il travaille encore sur un gros volume
        (reseau, nombreux fichiers)."""
        source = self.config.get_source(source_id)
        if not source:
            return
        row = self.domain_rows.get(source.domaine, {}).get(source_id)
        if row is not None:
            table = self.domain_tables[source.domaine]
            table.removeCellWidget(row, COL_LIGNES_EST)
            item = table.item(row, COL_LIGNES_EST)
            if item:
                item.setText(f"⏳ {traites}/{total}...")
        intervalle = max(1, total // 10)
        if traites == 1 or traites == total or traites % intervalle == 0:
            self._log("info", f"  [{source.pays}/{source.type}] comptage {traites}/{total} fichier(s)...")

    def _on_row_count_finished(self, source_id: str, nb_fichiers: int, nb_lignes: int):
        source = self.config.get_source(source_id)
        if not source:
            return
        folder_at_start = self._row_count_folder_at_start.pop(source_id, None)
        if folder_at_start is not None and folder_at_start != source.dossier_source:
            # Le dossier a change pendant le calcul : ce resultat concerne
            # l'ancien dossier, on l'ignore plutot que de l'attribuer au
            # nouveau. La cellule reste au bouton "Calculer" pour permettre
            # de relancer un calcul sur le dossier desormais affiche.
            self._log("warning", f"Resultat de calcul ignore pour {source.pays} / {source.type} : le dossier source a change pendant le calcul.")
            self._refresh_lignes_est_cell(source, force_button=True)
            return
        if nb_fichiers == 0:
            self._refresh_lignes_est_cell(source, force_button=True)  # revient au bouton "Calculer" (rien trouve, on pourra reessayer)
            return

        self.config.update_source(source_id, nb_fichiers_estimes=nb_fichiers, nb_lignes_estimees=nb_lignes)
        updated_source = self.config.get_source(source_id)
        self._refresh_lignes_est_cell(updated_source)
        self._log("success", f"Nombre de lignes calcule pour {source.pays} / {source.type} : {nb_lignes} lignes sur {nb_fichiers} fichier(s).")

    def _on_row_count_failed(self, source_id: str, message: str):
        self._row_count_folder_at_start.pop(source_id, None)
        source = self.config.get_source(source_id)
        if source:
            row = self.domain_rows.get(source.domaine, {}).get(source_id)
            if row is not None:
                table = self.domain_tables[source.domaine]
                table.removeCellWidget(row, COL_LIGNES_EST)
                table.item(row, COL_LIGNES_EST).setText("⚠ Erreur")
            self._log("error", f"Echec du calcul du nombre de lignes pour {source.pays} / {source.type} : {message}")

    def _set_current_tab_checked(self, checked: bool):
        domaine = self._current_domain()
        table = self.domain_tables[domaine]
        for row in range(table.rowCount()):
            check_widget = table.cellWidget(row, COL_CHECK)
            checkbox = check_widget.findChild(QCheckBox) if check_widget else None
            if checkbox:
                checkbox.setChecked(checked)

    # ------------------------------------------------------------------
    # CRUD sources
    # ------------------------------------------------------------------

    def _add_source(self):
        active_conn = self.config.get_active_connection()
        dialog = SourceEditorDialog(
            default_domaine=self._current_domain(),
            connection=active_conn,
            cached_tables=self._table_list_cache.get(active_conn.id),
            on_tables_loaded=lambda tables: self._table_list_cache.__setitem__(active_conn.id, tables),
            parent=self,
        )
        self._open_source_dialog_non_modal(dialog, is_new=True)

    def _edit_selected_source(self):
        source = self._selected_source()
        if not source:
            QMessageBox.information(self, "Aucune selection", "Selectionne une source a modifier.")
            return
        active_conn = self.config.get_active_connection()
        dialog = SourceEditorDialog(
            source=source, connection=active_conn,
            cached_tables=self._table_list_cache.get(active_conn.id),
            on_tables_loaded=lambda tables: self._table_list_cache.__setitem__(active_conn.id, tables),
            shared_row_count_worker=self._row_count_workers.get(source.id),
            parent=self,
        )
        self._open_source_dialog_non_modal(dialog, is_new=False, source_id=source.id)

    def _open_source_dialog_non_modal(self, dialog: "SourceEditorDialog", is_new: bool, source_id: str | None = None):
        """
        Ouvre le formulaire Ajouter/Modifier en mode NON MODAL : plusieurs
        formulaires peuvent rester ouverts en meme temps (un par TPA par
        exemple), chacun calculant son propre nombre de lignes en arriere-
        plan independamment des autres, sans jamais bloquer la fenetre
        principale ni les autres formulaires ouverts.
        """
        dialog.setModal(False)
        self._open_source_dialogs.append(dialog)

        def on_finished(result, d=dialog, is_new=is_new, source_id=source_id):
            if d in self._open_source_dialogs:
                self._open_source_dialogs.remove(d)
            if result != QDialog.DialogCode.Accepted:
                d.deleteLater()
                return
            self._handle_source_dialog_accepted(d, is_new, source_id)
            d.deleteLater()

        dialog.finished.connect(on_finished)
        dialog.show()
        dialog.raise_()
        dialog.activateWindow()

    def _handle_source_dialog_accepted(self, dialog: "SourceEditorDialog", is_new: bool, source_id: str | None):
        if is_new:
            source = dialog.result_source()
            if not source.pays or not source.dossier_source or not source.table:
                QMessageBox.warning(self, "Champs manquants", "Pays, dossier source et table sont obligatoires.")
                return
            self.config.add_source(source)
            self._loading_tables = True
            try:
                self._append_source_row(source)
            finally:
                self._loading_tables = False
            self.preprocessing_tab.refresh_after_external_change()
            self.statistics_tab.refresh_after_external_change()
            self._log("success", f"Source ajoutee : [{DOMAIN_LABELS.get(source.domaine, source.domaine)}] {source.pays} / {source.type}")
        else:
            updated = dialog.result_source()
            self.config.update_source(
                source_id,
                pays=updated.pays, type=updated.type,
                dossier_source=updated.dossier_source, table=updated.table,
                domaine=updated.domaine, header_mode=updated.header_mode,
                vider_avant_integration=updated.vider_avant_integration,
                nb_fichiers_estimes=updated.nb_fichiers_estimes,
                nb_lignes_estimees=updated.nb_lignes_estimees,
            )
            self._refresh_all_tables()
            self.preprocessing_tab.refresh_after_external_change()
            self.statistics_tab.refresh_after_external_change()
            self._log("info", f"Source modifiee : {updated.pays} / {updated.type}")

    def _delete_selected_source(self):
        source = self._selected_source()
        if not source:
            QMessageBox.information(self, "Aucune selection", "Selectionne une source a supprimer.")
            return
        confirm = QMessageBox.question(self, "Confirmer", f"Supprimer la source {source.pays} / {source.type} ?")
        if confirm == QMessageBox.StandardButton.Yes:
            self.config.remove_source(source.id)
            self._refresh_all_tables()
            self.preprocessing_tab.refresh_after_external_change()
            self.statistics_tab.refresh_after_external_change()
            self._log("warning", f"Source supprimee : {source.pays} / {source.type}")

    # ------------------------------------------------------------------
    # Connexion
    # ------------------------------------------------------------------

    def _update_conn_label(self, c) -> None:
        self.conn_server_edit.blockSignals(True)
        self.conn_database_edit.blockSignals(True)
        self.conn_username_edit.blockSignals(True)
        self.conn_password_edit.blockSignals(True)
        self.conn_server_edit.setText(c.server)
        self.conn_database_edit.setText(c.database)
        self.conn_username_edit.setText(c.username)
        self.conn_password_edit.setText(c.password)
        self.conn_server_edit.blockSignals(False)
        self.conn_database_edit.blockSignals(False)
        self.conn_username_edit.blockSignals(False)
        self.conn_password_edit.blockSignals(False)

        if c.database.strip().upper() != EXPECTED_DATABASE.upper():
            self.conn_database_edit.setStyleSheet("color:#B3261E; font-weight:700; border-color:#B3261E;")
            self.conn_status_label.setText(f"⚠ attendu : {EXPECTED_DATABASE}")
            self.conn_status_label.setStyleSheet("color:#B3261E; font-weight:600;")
        else:
            self.conn_database_edit.setStyleSheet("")
            if c.derniere_connexion_ok:
                # Statut memorise (persiste avec le profil) : reste affiche
                # "connecte" tant que les parametres n'ont pas change, sans
                # avoir besoin de re-tester a chaque changement d'onglet ou
                # redemarrage de l'application.
                self.conn_status_label.setText("✅ connecte")
                self.conn_status_label.setStyleSheet("color:#1a8f4c; font-weight:600;")
            else:
                self.conn_status_label.setText("non teste")
                self.conn_status_label.setStyleSheet("color:#8b95a3; font-weight:600;")

    def _refresh_connection_label(self):
        self.conn_combo.blockSignals(True)
        self.conn_combo.clear()
        for profile in self.config.connections:
            self.conn_combo.addItem(profile.nom, profile.id)
        idx = self.conn_combo.findData(self.config.active_connection_id)
        if idx >= 0:
            self.conn_combo.setCurrentIndex(idx)
        self.conn_combo.blockSignals(False)

        self._update_conn_label(self.config.get_active_connection())
        self._update_default_conn_btn()

    def _on_connection_combo_changed(self, index: int):
        if index < 0:
            return
        profile_id = self.conn_combo.itemData(index)
        if profile_id and profile_id != self.config.active_connection_id:
            self.config.set_active_connection(profile_id)
            c = self.config.get_active_connection()
            self._update_conn_label(c)
            self._update_default_conn_btn()
            self._log("info", f"Environnement actif : {c.nom} ({c.server} › {c.database})")

    def _save_connection_fields(self):
        """Enregistre le serveur, la base et les identifiants SQL (optionnels,
        utiles pour les connexions a des serveurs Azure VM en auth SQL) saisis
        directement dans la barre de connexion, sans passer par le gestionnaire
        complet de profils."""
        active = self.config.get_active_connection()
        new_server = self.conn_server_edit.text().strip()
        new_database = self.conn_database_edit.text().strip()
        new_username = self.conn_username_edit.text().strip()
        new_password = self.conn_password_edit.text()
        if not new_server or not new_database:
            QMessageBox.warning(self, "Champs manquants", "Le serveur et la base ne peuvent pas etre vides.")
            return

        # Le statut "connecte" memorise n'est plus valable si l'un des
        # parametres reellement determinant pour la connexion a change ; s'ils
        # sont identiques (simple clic sur Enregistrer sans rien modifier), on
        # le conserve tel quel.
        params_changed = (
            new_server != active.server or new_database != active.database
            or new_username != active.username or new_password != active.password
        )
        update_kwargs = dict(server=new_server, database=new_database, username=new_username, password=new_password)
        if params_changed:
            update_kwargs["derniere_connexion_ok"] = False
        self.config.update_connection(active.id, **update_kwargs)
        self._update_conn_label(self.config.get_active_connection())
        auth_info = f", utilisateur '{new_username}'" if new_username else " (auth Windows)"
        self._log("success", f"Parametres enregistres pour '{active.nom}' : {new_server} › {new_database}{auth_info}")

    def _open_connection_dialog(self):
        dialog = ConnectionManagerDialog(self.config, parent=self)
        dialog.exec()
        self._refresh_connection_label()
        self._log("info", "Profils de connexion mis a jour.")

    def _open_auth_server_dialog(self):
        dialog = AuthServerDialog(self.auth_config_manager, business_config=self.config, parent=self)
        dialog.exec()

    def _apply_role_restrictions(self):
        """
        V150, evolution demandee explicitement sur l'authentification
        centralisee : fait reellement usage du role recupere depuis
        USERS_PYTHON.applications (jusqu'ici utilise uniquement pour
        reserver l'ecran Authentification), en grisant toute action qui
        ECRIT une configuration partagee (profils de connexion, sources,
        mapping Fusion, structure cible, dictionnaire EN/FR) ou lance un
        traitement reel (Lancer le controle, Charger la selection, Lancer
        la fusion) pour un utilisateur dont le role n'est pas
        "Administrateur". La simple consultation (tableaux, statistiques,
        prechargement, export) reste toujours accessible a tous.

        Hypothese assumee en l'absence d'autre role observe que
        "Administrateur" et "Lecteur" dans l'exemple fourni : SEUL le role
        exact "Administrateur" donne acces en ecriture — tout autre role
        (Lecteur, ou toute valeur non reconnue) est traite en lecture
        seule par defaut (principe de precaution). Tant que l'authentification
        n'est pas activee (current_user est None), l'application reste
        inchangee (acces complet), pour ne rien casser en usage actuel.
        """
        if self.current_user is None or self.current_user.role == "Administrateur":
            return

        for widget in self._write_widgets:
            widget.setEnabled(False)
            widget.setToolTip("Action reservee au role Administrateur.")

        if getattr(self, "preprocessing_tab", None) is not None:
            self.preprocessing_tab.set_read_only(True)
        if getattr(self, "fusion_tab", None) is not None:
            self.fusion_tab.set_read_only(True)

        self._log("info", f"Mode lecture seule applique (role '{self.current_user.role}').")

    def _confirm_target_database(self) -> bool:
        """
        Verification systematique avant tout chargement ou toute fusion :
        les tables cibles doivent toujours se trouver dans la base TECH_BI,
        quel que soit l'environnement (Local/Recette/Production). Si la base
        active differe, on demande confirmation explicite avant de continuer.
        """
        c = self.config.get_active_connection()
        if c.database.strip().upper() == EXPECTED_DATABASE.upper():
            return True

        confirm = QMessageBox.warning(
            self, "Verification de la base cible",
            f"La base de donnees active pour l'environnement \u00ab{c.nom}\u00bb est "
            f"\u00ab{c.database}\u00bb, alors que les tables cibles doivent normalement "
            f"se trouver dans \u00ab{EXPECTED_DATABASE}\u00bb.\n\n"
            "Veux-tu vraiment continuer et inserer dans cette base ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if confirm != QMessageBox.StandardButton.Yes:
            self._log("warning", f"Operation annulee : base active \u00ab{c.database}\u00bb differente de \u00ab{EXPECTED_DATABASE}\u00bb attendue.")
            return False
        self._log("warning", f"Confirmation utilisateur : poursuite malgre une base differente de {EXPECTED_DATABASE} ({c.database}).")
        return True

    def _confirm_pretraitement(self, sources: list[SourceConfig]) -> bool:
        """
        Verification avant chargement : les sources doivent normalement avoir
        ete controlees (onglet Pretraitement) avec un statut OK. Si certaines
        ne l'ont pas ete, ou presentent des avertissements/erreurs, on demande
        confirmation avant de continuer plutot que de bloquer completement.
        """
        problematiques = [s for s in sources if s.pretraitement_statut != "OK"]
        if not problematiques:
            return True

        details = "\n".join(f"  - {s.pays} / {s.type} : {s.pretraitement_statut}" for s in problematiques)
        confirm = QMessageBox.warning(
            self, "Verification du pretraitement",
            f"{len(problematiques)} source(s) selectionnee(s) n'ont pas un statut de "
            f"pretraitement \u00abOK\u00bb :\n\n{details}\n\n"
            "Veux-tu quand meme lancer le chargement ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if confirm != QMessageBox.StandardButton.Yes:
            self._log("warning", "Chargement annule : certaines sources n'ont pas passe le pretraitement.")
            return False
        self._log("warning", "Confirmation utilisateur : chargement lance malgre un pretraitement incomplet/en erreur sur certaines sources.")
        return True

    def _test_connection_quick(self):
        from core.db import test_connection
        from core.config_manager import ConnectionProfile
        active = self.config.get_active_connection()
        # Teste les valeurs actuellement saisies dans la barre (meme si pas
        # encore enregistrees), pour que "Tester" corresponde toujours a ce
        # que l'utilisateur voit a l'ecran.
        conn = ConnectionProfile(
            id=active.id, nom=active.nom,
            server=self.conn_server_edit.text().strip(),
            database=self.conn_database_edit.text().strip(),
            username=self.conn_username_edit.text().strip(),
            password=self.conn_password_edit.text(),
            driver=active.driver,
        )
        ok, msg = test_connection(conn)
        if ok:
            self.conn_status_label.setText("✅ connecte")
            self.conn_status_label.setStyleSheet("color:#1a8f4c; font-weight:600;")
            # Enregistre aussi les valeurs testees (deja saisies a l'ecran) et
            # memorise le succes : reste affiche "connecte" indefiniment,
            # meme apres redemarrage de l'application, tant que ces
            # parametres ne changent pas (voir _save_connection_fields).
            self.config.update_connection(
                active.id, server=conn.server, database=conn.database,
                username=conn.username, password=conn.password,
                derniere_connexion_ok=True,
            )
            self._log("success", f"Connexion SQL Server OK ({conn.nom}).")
        else:
            self.conn_status_label.setText("❌ echec")
            self.conn_status_label.setStyleSheet("color:#c93b40; font-weight:600;")
            self.config.update_connection(active.id, derniere_connexion_ok=False)
            self._log("error", f"Echec de connexion ({conn.nom}) : {msg}")

    # ------------------------------------------------------------------
    # Mail / Logs
    # ------------------------------------------------------------------

    def _open_mail_window(self):
        window = MailWindow(parent=self)
        window.exec()

    def _open_log_window(self):
        self.log_window.show()
        self.log_window.raise_()
        self.log_window.activateWindow()

    # ------------------------------------------------------------------
    # Chargement
    # ------------------------------------------------------------------

    def _start_loading(self):
        sources = self._checked_sources()
        if not sources:
            QMessageBox.information(self, "Aucune source", "Coche au moins une source (dans un ou plusieurs onglets) a charger.")
            return

        if not self._confirm_target_database():
            return

        if not self._confirm_pretraitement(sources):
            return

        self.load_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.global_progress.setMaximum(len(sources))
        self.global_progress.setValue(0)
        self.file_progress.setValue(0)
        self.file_progress_label.setText("")

        for source in sources:
            row = self._row_for_source(source)
            if row is not None:
                self._set_row_status(source.domaine, row, "En attente")

        par_domaine = {}
        for s in sources:
            par_domaine.setdefault(s.domaine, 0)
            par_domaine[s.domaine] += 1
        resume = ", ".join(f"{DOMAIN_LABELS.get(d, d)} : {n}" for d, n in par_domaine.items())
        self._log("info", f"=== Lancement du chargement pour {len(sources)} source(s) — {resume} ===")

        settings = LoaderSettings()
        connection = self.config.get_active_connection()
        self.worker = LoadWorker(connection, sources, settings)
        self.worker.log.connect(self._log)
        self.worker.source_started.connect(self._on_source_started)
        self.worker.source_progress.connect(self._on_source_progress)
        self.worker.source_finished.connect(self._on_source_finished)
        self.worker.all_finished.connect(self._on_all_finished)
        self.worker.cancelled.connect(self._on_cancelled)
        self.worker.start()

    def _cancel_loading(self):
        if self.worker:
            self.worker.request_stop()
            self.cancel_btn.setEnabled(False)
            self._log("warning", "Demande d'annulation envoyee, en attente de l'arret effectif du chargement...")
            # Surveillance de l'arret effectif (V84) : la demande
            # d'annulation seule ne suffisait pas toujours a arreter
            # reellement le chargement si le thread etait bloque en plein
            # appel reseau (stop_flag n'est verifie qu'ENTRE deux requetes,
            # jamais PENDANT). Cette surveillance force l'arret du thread
            # si, malgre la demande, il ne s'est toujours pas arrete au
            # bout d'un delai de grace raisonnable.
            self._cancel_requested_at = time.monotonic()
            if not hasattr(self, "_cancel_watchdog_timer"):
                self._cancel_watchdog_timer = QTimer(self)
                self._cancel_watchdog_timer.timeout.connect(self._check_cancel_watchdog)
            self._cancel_watchdog_timer.start(5_000)

    def _check_cancel_watchdog(self):
        if self.worker is None or not self.worker.isRunning():
            self._cancel_watchdog_timer.stop()
            return
        elapsed = time.monotonic() - self._cancel_requested_at
        if elapsed < CANCEL_FORCE_TERMINATE_AFTER_S:
            return
        self._cancel_watchdog_timer.stop()
        self._log(
            "error",
            f"Le chargement ne repond toujours pas {int(elapsed)}s apres la demande d'annulation "
            "(connexion probablement totalement figee) — arret force du thread.",
        )
        self.worker.terminate()
        self.worker.wait(3_000)
        self._on_cancelled()

    def _source_by_id(self, source_id: str) -> SourceConfig | None:
        return self.config.get_source(source_id)

    def _on_source_started(self, source_id: str):
        source = self._source_by_id(source_id)
        if not source:
            return
        row = self._row_for_source(source)
        if row is not None:
            self._set_row_status(source.domaine, row, "En cours")

    def _on_source_progress(self, source_id: str, current: int, total: int, label: str):
        self.file_progress.setMaximum(max(total, 1))
        self.file_progress.setValue(current)
        self.file_progress_label.setText(f"{source_id} : {label} ({current}/{total})")

    def _on_source_finished(self, source_id: str, result: SourceLoadResult):
        source = self._source_by_id(source_id)
        done = self.global_progress.value() + 1
        self.global_progress.setValue(done)
        if source:
            row = self._row_for_source(source)
            if row is not None:
                self._set_row_status(source.domaine, row, "OK" if result.success else "Erreur")
                self.domain_tables[source.domaine].item(row, COL_LIGNES).setText(str(result.total_rows))
        if not result.success:
            details = "\n".join(f"- {f} : {e}" for f, e in result.errors)
            self._log("error", f"Erreurs pour {result.table} :\n{details}")

    def _on_all_finished(self):
        self._log("success", "=== Chargement termine pour toutes les sources selectionnees ===")
        self._reset_run_controls()

    def _on_cancelled(self):
        self._log("warning", "Chargement annule par l'utilisateur.")
        for source in self._checked_sources():
            row = self._row_for_source(source)
            if row is None:
                continue
            table = self.domain_tables[source.domaine]
            if table.item(row, COL_STATUT).text().endswith("En cours"):
                self._set_row_status(source.domaine, row, "Annule")
        self._reset_run_controls()

    def _reset_run_controls(self):
        self.load_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.worker = None

    # ------------------------------------------------------------------
    # Logs
    # ------------------------------------------------------------------

    def _log(self, level: str, message: str):
        self.console.append_log(level, message)
        from core.log_manager import default_log_cb
        default_log_cb(level, message)

    # ------------------------------------------------------------------
    # Fermeture propre de l'application
    # ------------------------------------------------------------------

    def closeEvent(self, event):
        """
        Empeche la fermeture brutale pendant qu'un chargement tourne en
        arriere-plan (evite le crash/avertissement Qt "QThread: Destroyed
        while thread is still running"). Demande confirmation, puis attend
        proprement la fin du thread avant de laisser l'application se fermer.
        Verifie aussi les modifications non enregistrees du mapping Fusion.
        """
        if self.current_user is not None and self.auth_config_manager.config.active:
            try:
                log_event(self.auth_config_manager.config, self.current_user.login, "DECONNEXION")
            except Exception:
                pass

        if getattr(self, "fusion_tab", None) is not None and self.fusion_tab._dirty:
            confirm = QMessageBox.question(
                self, "Mapping Fusion non enregistre",
                "Le mapping de l'onglet Fusion a des modifications non enregistrees.\n\n"
                "Enregistrer avant de quitter ?",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Save,
            )
            if confirm == QMessageBox.StandardButton.Cancel:
                event.ignore()
                return
            elif confirm == QMessageBox.StandardButton.Save:
                self.fusion_tab._save_mapping()

        if self.worker is not None and self.worker.isRunning():
            confirm = QMessageBox.question(
                self, "Chargement en cours",
                "Un chargement est actuellement en cours.\n"
                "Voulez-vous l'annuler et quitter l'application ?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if confirm != QMessageBox.StandardButton.Yes:
                event.ignore()
                return

            self._log("warning", "Fermeture demandee : arret du chargement en cours...")
            self.worker.request_stop()
            if not self.worker.wait(10_000):  # attend jusqu'a 10s que le thread se termine reellement
                self._log("error", "Le chargement n'a pas pu etre arrete a temps, fermeture forcee.")

        # Les calculs de nombre de lignes en arriere-plan sont des lectures
        # seules, rapides a interrompre : on attend un court instant puis on
        # force l'arret si necessaire, sans bloquer la fermeture de l'appli.
        for worker in list(self._row_count_workers.values()):
            if worker.isRunning():
                if not worker.wait(2_000):
                    worker.terminate()
                    worker.wait(1_000)

        # Ferme proprement tous les formulaires Ajouter/Modifier encore
        # ouverts (plusieurs peuvent l'etre en meme temps, un par TPA par
        # exemple) : chacun se detache de son propre calcul en arriere-plan
        # sans jamais risquer de plantage (V44 — plus de parentage Qt force).
        for dialog in list(self._open_source_dialogs):
            dialog.close()
        self._open_source_dialogs.clear()

        if self.log_window is not None:
            self.log_window.close()

        event.accept()

"""
elevation.py
------------
QSS seul ne sait pas dessiner d'ombre portee (pas de box-shadow). Ce module
applique une vraie ombre portee Material ("elevation") via
QGraphicsDropShadowEffect sur les widgets qui doivent apparaitre comme des
cartes surelevees (QGroupBox principalement).
"""

from __future__ import annotations

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QGraphicsDropShadowEffect, QWidget


def apply_card_elevation(widget: QWidget, blur: int = 24, y_offset: int = 3, alpha: int = 35) -> None:
    """Ajoute une ombre portee douce (elevation Material) sous le widget."""
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(blur)
    effect.setXOffset(0)
    effect.setYOffset(y_offset)
    effect.setColor(QColor(0, 0, 0, alpha))
    widget.setGraphicsEffect(effect)


def apply_elevation_to_children(parent: QWidget, widget_type) -> None:
    """Applique l'elevation a tous les enfants directs/indirects d'un certain type."""
    for child in parent.findChildren(widget_type):
        apply_card_elevation(child)

"""
material_colors.py
-------------------
Palette Material Design 3 (schema clair, teinte "seed" bleue) utilisee par le
theme QSS global et par le code Python qui a besoin des memes couleurs
(statuts colores dans les tableaux, badges, etc.) pour rester coherent.
"""

# Couleurs de role Material 3
PRIMARY = "#1A73E8"          # bleu Google, coherent avec l'identite deja utilisee
ON_PRIMARY = "#FFFFFF"
PRIMARY_CONTAINER = "#D3E3FD"
ON_PRIMARY_CONTAINER = "#001B3D"

SECONDARY = "#565F71"
SECONDARY_CONTAINER = "#DAE2F9"

ERROR = "#B3261E"
ON_ERROR = "#FFFFFF"
ERROR_CONTAINER = "#F9DEDC"
ON_ERROR_CONTAINER = "#410E0B"

SUCCESS = "#1E8E3E"
SUCCESS_CONTAINER = "#E6F4EA"
ON_SUCCESS_CONTAINER = "#0D652D"

WARNING = "#B06000"
WARNING_CONTAINER = "#FEF7E0"
ON_WARNING_CONTAINER = "#7A4E00"

NEUTRAL_CONTAINER = "#F1F3F4"
ON_NEUTRAL_CONTAINER = "#5F6368"

SURFACE = "#FFFFFF"
SURFACE_VARIANT = "#F1F3F4"
BACKGROUND = "#F8F9FA"
OUTLINE = "#DADCE0"
OUTLINE_VARIANT = "#E8EAED"

ON_SURFACE = "#1F1F1F"
ON_SURFACE_VARIANT = "#444746"

# Console / surfaces sombres (fenetre de logs, console live)
SURFACE_DARK = "#1B1F23"
SURFACE_DARK_BORDER = "#2C3136"
ON_SURFACE_DARK = "#E3E5E8"

# Statuts (fond container clair + texte contraste) reutilises par les tableaux
STATUS_COLORS = {
    "En attente": (NEUTRAL_CONTAINER, ON_NEUTRAL_CONTAINER),
    "En cours":   (WARNING_CONTAINER, ON_WARNING_CONTAINER),
    "OK":         (SUCCESS_CONTAINER, ON_SUCCESS_CONTAINER),
    "Erreur":     (ERROR_CONTAINER, ON_ERROR_CONTAINER),
    "Annule":     (NEUTRAL_CONTAINER, ON_NEUTRAL_CONTAINER),
}

from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QFormLayout, QLineEdit, QComboBox, QDialogButtonBox,
    QVBoxLayout, QHBoxLayout, QPushButton, QFileDialog, QLabel, QCheckBox
)

from core.config_manager import SourceConfig, DOMAINES, TPA_TYPES, ConnectionProfile

HEADER_MODES = ["auto", "always", "never", "skip_1", "skip_2", "row_0", "row_1"]
DOMAIN_LABELS = {"Adhesion": "Adhésion", "Sinistre": "Sinistre", "FIC": "FIC", "Reclamation": "Réclamation"}


class SourceEditorDialog(QDialog):
    def __init__(self, source: SourceConfig | None = None, default_domaine: str = "Adhesion",
                 connection: ConnectionProfile | None = None, cached_tables: list[str] | None = None,
                 on_tables_loaded=None, shared_row_count_worker=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Modifier la source" if source else "Ajouter une source")
        self.setMinimumWidth(500)
        self._editing_id = source.id if source else None
        self._connection = connection
        self._cached_tables = cached_tables
        self._on_tables_loaded = on_tables_loaded
        # Si un calcul du nombre de lignes tourne deja pour cette source
        # depuis le tableau principal, on s'y branche au lieu d'en demarrer
        # un second en double (evite la lenteur d'un calcul redondant, et
        # reduit le nombre de threads actifs simultanement).
        self._shared_worker = shared_row_count_worker if (shared_row_count_worker and shared_row_count_worker.isRunning()) else None

        self.pays_edit = QLineEdit(source.pays if source else "")

        self.type_combo = QComboBox()
        self.type_combo.setEditable(True)
        self.type_combo.addItems(TPA_TYPES)
        if source:
            self.type_combo.setCurrentText(source.type)

        self.dossier_edit = QLineEdit(source.dossier_source if source else "")
        self.row_count_label = QLabel("")
        self.row_count_label.setStyleSheet("color:#5c6577; font-style:italic;")
        self._last_nb_fichiers = source.nb_fichiers_estimes if source else 0
        self._last_nb_lignes = source.nb_lignes_estimees if source else 0
        recalc_btn = QPushButton("🔄 Recalculer")
        recalc_btn.setObjectName("ghostBtn")
        recalc_btn.setToolTip("Relire les fichiers pour recalculer le nombre exact de lignes")
        recalc_btn.clicked.connect(self._update_row_count)
        self.recalc_btn = recalc_btn
        self._row_count_worker = None
        row_count_row = QHBoxLayout()
        row_count_row.addWidget(self.row_count_label, stretch=1)
        row_count_row.addWidget(recalc_btn)

        self.table_combo = QComboBox()
        self.table_combo.setEditable(True)
        self.table_status_label = QLabel("")
        self.table_status_label.setStyleSheet("color:#5c6577; font-style:italic;")
        if source:
            self.table_combo.addItem(source.table)
            self.table_combo.setCurrentText(source.table)
        else:
            self.table_combo.addItem("dbo.")

        self.domaine_combo = QComboBox()
        for key in DOMAINES:
            self.domaine_combo.addItem(DOMAIN_LABELS.get(key, key), key)
        initial_domaine = source.domaine if source else default_domaine
        idx = self.domaine_combo.findData(initial_domaine)
        if idx >= 0:
            self.domaine_combo.setCurrentIndex(idx)

        self.header_combo = QComboBox()
        self.header_combo.addItems(HEADER_MODES)
        if source and source.header_mode in HEADER_MODES:
            self.header_combo.setCurrentText(source.header_mode)

        self.vider_checkbox = QCheckBox("Vider la table avant intégration (sinon l'historique est conservé)")
        self.vider_checkbox.setChecked(source.vider_avant_integration if source else True)

        browse_btn = QPushButton("Parcourir...")
        browse_btn.clicked.connect(self._browse_folder)
        dossier_row = QHBoxLayout()
        dossier_row.addWidget(self.dossier_edit)
        dossier_row.addWidget(browse_btn)

        refresh_tables_btn = QPushButton("🔄 Recharger")
        refresh_tables_btn.setToolTip("Recharger la liste des tables depuis la base active")
        refresh_tables_btn.setObjectName("ghostBtn")
        refresh_tables_btn.clicked.connect(self._refresh_tables)
        suggest_btn = QPushButton("Suggerer")
        suggest_btn.setObjectName("ghostBtn")
        suggest_btn.clicked.connect(self._suggest_table_name)
        table_row = QHBoxLayout()
        table_row.addWidget(self.table_combo, stretch=1)
        table_row.addWidget(refresh_tables_btn)
        table_row.addWidget(suggest_btn)

        form = QFormLayout()
        form.addRow("Domaine :", self.domaine_combo)
        form.addRow("Pays :", self.pays_edit)
        form.addRow("Type / TPA :", self.type_combo)
        form.addRow("Dossier source :", dossier_row)
        form.addRow("", row_count_row)
        form.addRow("Table cible (schema.table) :", table_row)
        form.addRow("", self.table_status_label)
        form.addRow("Mode en-tete :", self.header_combo)
        form.addRow("", self.vider_checkbox)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addWidget(buttons)
        self.setLayout(layout)

        self.dossier_edit.editingFinished.connect(self._update_row_count)
        if source and source.dossier_source:
            if source.nb_fichiers_estimes or source.nb_lignes_estimees:
                # Valeur deja calculee (mise en cache) : on l'affiche directement
                # sans relire les fichiers, pour que l'ouverture du formulaire
                # reste instantanee. Le bouton "Recalculer" permet de forcer un
                # nouveau calcul si les fichiers ont change entre-temps.
                self._display_cached_row_count()
            elif self._shared_worker is not None:
                # Un calcul tourne deja pour cette source depuis le tableau
                # principal : on s'y branche au lieu d'en lancer un second en
                # double (source de lenteur inutile et de threads en trop).
                self.row_count_label.setText("⏳ Calcul du nombre de lignes en cours (partage avec le tableau principal)...")
                self.recalc_btn.setEnabled(False)
                self._shared_worker.finished_count.connect(self._on_shared_worker_finished)
                self._shared_worker.failed.connect(self._on_shared_worker_failed)
                self._shared_worker.progress.connect(self._on_row_count_progress)
            else:
                self._update_row_count()
        if connection:
            if self._cached_tables:
                self.table_combo.clear()
                self.table_combo.addItems(self._cached_tables)
                self.table_combo.setEditText(self.table_combo.currentText() or (source.table if source else "dbo."))
                self.table_status_label.setText(f"{len(self._cached_tables)} table(s) (liste memorisee — \u00abRecharger\u00bb pour actualiser)")
            else:
                self._refresh_tables()

    # ------------------------------------------------------------------

    def _display_cached_row_count(self):
        nb_fichiers = self._last_nb_fichiers
        nb_lignes = self._last_nb_lignes
        if not nb_fichiers:
            self.row_count_label.setText("")
            return
        text = f"{nb_lignes:,} ligne(s) au total sur {nb_fichiers} fichier(s)".replace(",", " ")
        self.row_count_label.setText(f"{text}  (valeur memorisee)")

    def _browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Choisir le dossier source", self.dossier_edit.text())
        if folder:
            self.dossier_edit.setText(folder)
            self._update_row_count()

    def _update_row_count(self):
        folder = self.dossier_edit.text().strip()
        if not folder:
            self.row_count_label.setText("")
            return
        if self._row_count_worker is not None and self._row_count_worker.isRunning():
            return  # un calcul est deja en cours, on ne relance pas en double
        self._disconnect_from_shared_worker()  # l'utilisateur force un calcul propre au dialogue

        from workers.row_count_worker import RowCountWorker

        self.row_count_label.setText("⏳ Calcul du nombre de lignes en cours (en arriere-plan)...")
        self.recalc_btn.setEnabled(False)

        worker = RowCountWorker("dialog", folder, self.header_combo.currentText())
        # Volontairement AUCUN parent Qt (pas de parent=self) : si ce dialogue
        # se ferme avant la fin du calcul, Qt ne doit jamais forcer la
        # destruction de ce thread encore actif (ce qui provoquerait un arret
        # fatal au niveau C++, impossible a intercepter cote Python). Le
        # thread continue de vivre independamment, tenu en vie par
        # core.thread_registry (qui l'attendra proprement a la fermeture
        # reelle de l'application si besoin) et par la reference locale
        # ci-dessous tant que ce dialogue existe.
        worker.finished_count.connect(self._on_row_count_finished)
        worker.failed.connect(self._on_row_count_failed)
        worker.progress.connect(self._on_row_count_progress)
        worker.finished.connect(self._on_row_count_worker_done)
        self._row_count_worker = worker
        worker.start()

    def _on_row_count_progress(self, _source_id: str, traites: int, total: int, nom_fichier: str):
        """Evite qu'un calcul sur un gros dossier (reseau, nombreux fichiers)
        ne donne l'impression d'etre bloque en l'absence de tout signe
        d'avancement pendant potentiellement plusieurs minutes."""
        self.row_count_label.setText(f"⏳ Calcul en cours... {traites}/{total} fichier(s)")

    def _on_row_count_finished(self, _source_id: str, nb_fichiers: int, nb_lignes: int):
        self._last_nb_fichiers = nb_fichiers
        self._last_nb_lignes = nb_lignes
        if nb_fichiers == 0:
            self.row_count_label.setText("⚠ Aucun fichier compatible trouve dans ce dossier")
        else:
            self.row_count_label.setText(f"{nb_lignes:,} ligne(s) au total sur {nb_fichiers} fichier(s)".replace(",", " "))

    def _on_row_count_failed(self, _source_id: str, message: str):
        self.row_count_label.setText(f"⚠ Erreur lors du calcul : {message}")
        from core.log_manager import get_logger
        get_logger().error("Echec du calcul du nombre de lignes pour %s : %s", self.dossier_edit.text().strip(), message)

    def _on_row_count_worker_done(self):
        self.recalc_btn.setEnabled(True)
        self._row_count_worker = None

    def _on_shared_worker_finished(self, _source_id: str, nb_fichiers: int, nb_lignes: int):
        self._on_row_count_finished(_source_id, nb_fichiers, nb_lignes)
        self.recalc_btn.setEnabled(True)
        self._shared_worker = None

    def _on_shared_worker_failed(self, _source_id: str, message: str):
        self._on_row_count_failed(_source_id, message)
        self.recalc_btn.setEnabled(True)
        self._shared_worker = None

    def _disconnect_from_shared_worker(self):
        """Le worker partage appartient a la fenetre principale : on ne
        l'arrete jamais depuis ce dialogue (ce n'est pas sa responsabilite),
        on se contente de se detacher de ses signaux pour ne plus recevoir
        de mise a jour une fois ce dialogue ferme."""
        if self._shared_worker is None:
            return
        try:
            self._shared_worker.finished_count.disconnect(self._on_shared_worker_finished)
        except (RuntimeError, TypeError):
            pass
        try:
            self._shared_worker.failed.disconnect(self._on_shared_worker_failed)
        except (RuntimeError, TypeError):
            pass
        try:
            self._shared_worker.progress.disconnect(self._on_row_count_progress)
        except (RuntimeError, TypeError):
            pass
        self._shared_worker = None

    def _stop_row_count_worker_if_running(self):
        """A appeler avant TOUTE fermeture de ce dialogue (OK, Cancel, Echap,
        bouton X). Le worker n'a plus de parent Qt (voir _update_row_count),
        donc fermer ce dialogue ne peut plus jamais le detruire de force —
        on lui laisse simplement une chance courte de finir (3s), et s'il
        tourne encore au-dela, on se detache juste de ses signaux : il
        continue de vivre independamment (tenu par core.thread_registry qui
        l'attendra proprement a la fermeture reelle de l'application), sans
        plus jamais essayer d'appeler une methode sur ce dialogue ferme."""
        self._disconnect_from_shared_worker()
        worker = self._row_count_worker
        if worker is None:
            return
        if worker.isRunning():
            if worker.wait(3000):
                return  # termine a temps, rien de plus a faire
            import warnings
            for signal, slot in (
                (worker.finished_count, self._on_row_count_finished),
                (worker.failed, self._on_row_count_failed),
                (worker.progress, self._on_row_count_progress),
                (worker.finished, self._on_row_count_worker_done),
            ):
                try:
                    with warnings.catch_warnings():
                        # Si le signal est deja deconnecte (cas normal selon
                        # le timing), PySide6 emet un RuntimeWarning cosmetique
                        # via le module warnings (pas une exception, donc pas
                        # attrapable par le try/except ci-dessous) — sans
                        # consequence : le but (ne plus jamais appeler une
                        # methode sur ce dialogue ferme) est deja atteint dans
                        # les deux cas.
                        warnings.simplefilter("ignore", RuntimeWarning)
                        signal.disconnect(slot)
                except (RuntimeError, TypeError):
                    pass

    def done(self, result):
        self._stop_row_count_worker_if_running()
        super().done(result)

    def closeEvent(self, event):
        self._stop_row_count_worker_if_running()
        super().closeEvent(event)

    def _refresh_tables(self):
        from core.log_manager import get_logger
        if not self._connection:
            self.table_status_label.setText("⚠ Aucune connexion active : impossible de charger les tables.")
            get_logger().warning("Formulaire source : tentative de chargement des tables sans connexion active.")
            return
        from core.db import list_tables
        current = self.table_combo.currentText()
        self.table_status_label.setText("Chargement des tables en cours...")
        self.table_status_label.repaint()
        try:
            tables = list_tables(self._connection)
        except Exception as e:
            self.table_status_label.setText(f"⚠ Impossible de charger les tables depuis {self._connection.database} : {e}")
            get_logger().error("Echec du chargement des tables depuis %s (%s) : %s", self._connection.database, self._connection.nom, e)
            return
        self.table_combo.clear()
        self.table_combo.addItems(tables)
        self.table_combo.setEditText(current)
        self.table_status_label.setText(f"✅ {len(tables)} table(s) chargee(s) depuis {self._connection.database} ({self._connection.nom})")
        self._cached_tables = tables
        if self._on_tables_loaded:
            try:
                self._on_tables_loaded(tables)
            except Exception as e:
                # La mise en cache cote fenetre principale ne doit jamais faire
                # echouer le dialogue, mais on trace quand meme le probleme.
                from core.log_manager import get_logger
                get_logger().warning("Echec de la mise en cache de la liste des tables : %s", e)

    def _suggest_table_name(self):
        import re
        domaine = self.domaine_combo.currentData()
        type_clean = re.sub(r"\s+", "", self.type_combo.currentText().strip())
        pays_clean = re.sub(r"\s+", "", self.pays_edit.text().strip())
        parts = [p for p in (type_clean, pays_clean) if p]
        suffix = "_".join(parts)
        suggestion = f"dbo.SRC_{domaine}_Avant_Transformer_{suffix}" if suffix else f"dbo.SRC_{domaine}_Avant_Transformer_"
        self.table_combo.setEditText(suggestion)

    def result_source(self) -> SourceConfig:
        domaine = self.domaine_combo.currentData()
        common = dict(
            pays=self.pays_edit.text().strip(),
            type=self.type_combo.currentText().strip(),
            dossier_source=self.dossier_edit.text().strip(),
            table=self.table_combo.currentText().strip(),
            domaine=domaine,
            header_mode=self.header_combo.currentText(),
            vider_avant_integration=self.vider_checkbox.isChecked(),
            nb_fichiers_estimes=self._last_nb_fichiers,
            nb_lignes_estimees=self._last_nb_lignes,
        )
        if self._editing_id:
            return SourceConfig(id=self._editing_id, **common)
        return SourceConfig.new(
            pays=common["pays"], type_=common["type"], dossier_source=common["dossier_source"],
            table=common["table"], domaine=common["domaine"], header_mode=common["header_mode"],
            vider_avant_integration=common["vider_avant_integration"],
            nb_fichiers_estimes=common["nb_fichiers_estimes"], nb_lignes_estimees=common["nb_lignes_estimees"],
        )

"""
value_alias_dialog.py
-----------------------
Dialogue de gestion du referentiel de normalisation de VALEURS (V151),
ex: harmoniser "Fr"/"FR"/"France" -> "France" dans la colonne Pays_Client.

Meme principe que AliasManagerDialog (ui/fusion_tab.py) pour le dictionnaire
de colonnes, mais ici une correspondance est toujours rattachee a UNE
colonne cible precise (le mot "France" n'a pas le meme sens dans toutes
les colonnes) et peut etre alimentee automatiquement par une detection en
base (bouton "Detecter de nouvelles valeurs"), en plus de l'ajout manuel.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, QComboBox, QPushButton,
    QTableWidget, QTableWidgetItem, QLabel, QMessageBox, QHeaderView,
    QLineEdit, QAbstractItemView,
)


class ValueAliasManagerDialog(QDialog):
    def __init__(self, value_alias_manager, colonnes_cibles_possibles: list[str],
                 colonne_defaut: str = "", detect_callback=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Referentiel de normalisation de valeurs (pays, etc.)")
        self.setMinimumSize(640, 480)
        self.manager = value_alias_manager
        self.colonnes_cibles_possibles = colonnes_cibles_possibles
        self.detect_callback = detect_callback

        layout = QVBoxLayout()
        info = QLabel(
            "Harmonise des saisies libres incoherentes pour UNE colonne cible donnee "
            "(ex : «Fr», «FR», «France» -> «France» dans Pays_Client), "
            "appliquee automatiquement cote serveur a chaque fusion. Une variante non reconnue "
            "n'est jamais modifiee ni videe."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#5c6577; font-style:italic;")
        layout.addWidget(info)

        col_row = QHBoxLayout()
        col_row.addWidget(QLabel("Colonne cible :"))
        self.colonne_combo = QComboBox()
        self.colonne_combo.setEditable(True)
        self.colonne_combo.addItems(self.colonnes_cibles_possibles)
        if colonne_defaut:
            self.colonne_combo.setCurrentText(colonne_defaut)
        self.colonne_combo.currentTextChanged.connect(self._refresh_all)
        col_row.addWidget(self.colonne_combo, stretch=1)
        self.detect_btn = QPushButton("🔎 Detecter de nouvelles valeurs en base")
        self.detect_btn.setToolTip(
            "Lit les valeurs distinctes reellement presentes dans les tables source mappees vers "
            "cette colonne, et propose ci-dessous celles qui ne sont pas encore reconnues."
        )
        self.detect_btn.clicked.connect(self._on_detect)
        self.detect_btn.setEnabled(self.detect_callback is not None)
        col_row.addWidget(self.detect_btn)
        layout.addLayout(col_row)

        self.propositions_group = QGroupBox("💡 Valeurs rencontrees non reconnues (jamais appliquees tant que non acceptees)")
        prop_layout = QVBoxLayout(self.propositions_group)
        prop_info = QLabel(
            "Renseigne la valeur canonique a utiliser pour chaque variante avant de l'accepter."
        )
        prop_info.setWordWrap(True)
        prop_info.setStyleSheet("color:#8a6d00; font-style:italic;")
        prop_layout.addWidget(prop_info)

        self.propositions_table = QTableWidget(0, 2)
        self.propositions_table.setHorizontalHeaderLabels(["Variante rencontree", "Valeur canonique (a completer)"])
        self.propositions_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.propositions_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.propositions_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.propositions_table.setMaximumHeight(160)
        prop_layout.addWidget(self.propositions_table)

        prop_btn_row = QHBoxLayout()
        accept_btn = QPushButton("✅ Accepter la selection")
        accept_btn.clicked.connect(self._on_accept_proposition)
        reject_btn = QPushButton("❌ Rejeter la selection")
        reject_btn.clicked.connect(self._on_reject_proposition)
        prop_btn_row.addWidget(accept_btn)
        prop_btn_row.addWidget(reject_btn)
        prop_btn_row.addStretch()
        prop_layout.addLayout(prop_btn_row)
        layout.addWidget(self.propositions_group)

        confirmed_label = QLabel("✅ Correspondances confirmees (appliquees automatiquement a la fusion) :")
        confirmed_label.setStyleSheet("font-weight:600;")
        layout.addWidget(confirmed_label)

        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Variante", "Valeur canonique"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        layout.addWidget(self.table)

        add_row = QHBoxLayout()
        self.variante_edit = QLineEdit()
        self.variante_edit.setPlaceholderText("Variante, ex: Fr")
        self.canonique_edit = QLineEdit()
        self.canonique_edit.setPlaceholderText("Valeur canonique, ex: France")
        add_btn = QPushButton("➕ Ajouter")
        add_btn.clicked.connect(self._on_add)
        add_row.addWidget(self.variante_edit, stretch=1)
        add_row.addWidget(QLabel("→"))
        add_row.addWidget(self.canonique_edit, stretch=1)
        add_row.addWidget(add_btn)
        layout.addLayout(add_row)

        btn_row = QHBoxLayout()
        remove_btn = QPushButton("🗑️ Supprimer la ligne selectionnee")
        remove_btn.clicked.connect(self._on_remove)
        close_btn = QPushButton("Fermer")
        close_btn.setObjectName("primaryBtn")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(remove_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

        self.setLayout(layout)
        self._refresh_all()

    def _colonne_courante(self) -> str:
        return self.colonne_combo.currentText().strip()

    def _refresh_all(self):
        self._refresh_table()
        self._refresh_propositions_table()

    def _refresh_table(self):
        colonne = self._colonne_courante()
        regles = self.manager.for_column(colonne) if colonne else []
        self.table.setRowCount(len(regles))
        for row, v in enumerate(regles):
            self.table.setItem(row, 0, QTableWidgetItem(v.variante))
            self.table.setItem(row, 1, QTableWidgetItem(v.valeur_canonique))

    def _refresh_propositions_table(self):
        colonne = self._colonne_courante()
        props = self.manager.propositions_for_column(colonne) if colonne else []
        self.propositions_table.setRowCount(len(props))
        for row, p in enumerate(props):
            variante_item = QTableWidgetItem(p.variante)
            variante_item.setFlags(variante_item.flags() & ~Qt_ItemIsEditable())
            self.propositions_table.setItem(row, 0, variante_item)
            self.propositions_table.setItem(row, 1, QTableWidgetItem(p.valeur_canonique))
        self.propositions_group.setVisible(bool(props))

    def _on_detect(self):
        colonne = self._colonne_courante()
        if not colonne:
            QMessageBox.information(self, "Colonne requise", "Choisis une colonne cible avant de lancer la detection.")
            return
        if not self.detect_callback:
            return
        try:
            nb = self.detect_callback(colonne)
        except Exception as e:
            QMessageBox.warning(self, "Erreur de detection", f"Impossible de detecter les nouvelles valeurs : {e}")
            return
        self._refresh_propositions_table()
        if nb:
            QMessageBox.information(self, "Detection terminee", f"{nb} nouvelle(s) valeur(s) proposee(s) pour '{colonne}'.")
        else:
            QMessageBox.information(self, "Detection terminee", f"Aucune nouvelle valeur non reconnue pour '{colonne}'.")

    def _on_accept_proposition(self):
        row = self.propositions_table.currentRow()
        if row < 0:
            return
        colonne = self._colonne_courante()
        variante = self.propositions_table.item(row, 0).text()
        canonique = self.propositions_table.item(row, 1).text().strip()
        if not canonique:
            QMessageBox.information(self, "Valeur canonique requise", "Renseigne la valeur canonique a utiliser avant d'accepter.")
            return
        self.manager.accept_proposition(colonne, variante, canonique)
        self._refresh_all()

    def _on_reject_proposition(self):
        row = self.propositions_table.currentRow()
        if row < 0:
            return
        colonne = self._colonne_courante()
        variante = self.propositions_table.item(row, 0).text()
        self.manager.reject_proposition(colonne, variante)
        self._refresh_propositions_table()

    def _on_add(self):
        colonne = self._colonne_courante()
        variante = self.variante_edit.text().strip()
        canonique = self.canonique_edit.text().strip()
        if not colonne or not variante or not canonique:
            QMessageBox.information(self, "Champs requis", "Renseigne la colonne cible, la variante et la valeur canonique.")
            return
        self.manager.add(colonne, variante, canonique)
        self.variante_edit.clear()
        self.canonique_edit.clear()
        self._refresh_table()

    def _on_remove(self):
        row = self.table.currentRow()
        if row < 0:
            return
        colonne = self._colonne_courante()
        variante = self.table.item(row, 0).text()
        self.manager.remove(colonne, variante)
        self._refresh_table()


def Qt_ItemIsEditable():
    """Petit indirection pour recuperer Qt.ItemFlag.ItemIsEditable sans
    alourdir les imports du haut de fichier (evite un import Qt.* juste
    pour ce seul usage ponctuel)."""
    from PySide6.QtCore import Qt
    return Qt.ItemFlag.ItemIsEditable

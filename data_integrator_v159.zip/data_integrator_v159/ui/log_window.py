from __future__ import annotations

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QLabel,
    QPushButton, QLineEdit
)

from core.log_manager import attach_callback_handler, LOG_FILE
from ui.console_widget import ConsoleWidget

LEVELS = ["Tous", "info", "warning", "error", "debug"]


class _LogSignalBridge(QObject):
    """Pont thread-safe : le handler de logging (thread quelconque) emet ici,
    Qt garantit la livraison du signal dans le thread de l'IHM."""
    log_received = Signal(str, str)


class LogWindow(QMainWindow):
    """Ecran de logs complet et detaille, en direct, actif des le lancement
    de l'application (voir setup_logging() appele dans main.py)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Journal de l'application — Console live")
        self.resize(1000, 640)

        self._bridge = _LogSignalBridge()
        self._bridge.log_received.connect(self._on_log)
        self._entries: list[tuple[str, str]] = []

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        top_row = QHBoxLayout()
        top_row.addWidget(QLabel("Niveau :"))
        self.level_filter = QComboBox()
        self.level_filter.addItems(LEVELS)
        self.level_filter.currentTextChanged.connect(self._apply_filter)
        top_row.addWidget(self.level_filter)

        top_row.addWidget(QLabel("Recherche :"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Filtrer le texte...")
        self.search_edit.textChanged.connect(self._apply_filter)
        top_row.addWidget(self.search_edit, stretch=1)

        clear_btn = QPushButton("Effacer l'affichage")
        clear_btn.setObjectName("ghostBtn")
        clear_btn.clicked.connect(self._clear_display)
        top_row.addWidget(clear_btn)
        layout.addLayout(top_row)

        self.console = ConsoleWidget()
        layout.addWidget(self.console, stretch=1)

        layout.addWidget(QLabel(f"Fichier de log complet : {LOG_FILE}"))

        # Se branche sur le logger applicatif : tout ce qui est journalise
        # depuis le lancement de main.py remonte ici en direct.
        attach_callback_handler(self._thread_safe_emit)

    def _thread_safe_emit(self, level: str, message: str):
        self._bridge.log_received.emit(level, message)

    def _on_log(self, level: str, message: str):
        self._entries.append((level, message))
        if self._passes_filter(level, message):
            self.console.append_log(level, message)

    def _passes_filter(self, level: str, message: str) -> bool:
        level_ok = self.level_filter.currentText() == "Tous" or self.level_filter.currentText() == level
        search = self.search_edit.text().strip().lower()
        search_ok = not search or search in message.lower()
        return level_ok and search_ok

    def _apply_filter(self, *_args):
        self.console.clear_console()
        for level, message in self._entries:
            if self._passes_filter(level, message):
                self.console.append_log(level, message)

    def _clear_display(self):
        self._entries.clear()
        self.console.clear_console()

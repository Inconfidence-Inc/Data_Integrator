from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QComboBox, QCheckBox, QPushButton, QTextEdit, QLabel,
    QMessageBox, QSpinBox, QInputDialog
)

from core.mail_manager import MailConfigManager, MailAccountConfig, test_smtp, send_mail
from core.log_manager import get_logger


class MailWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Paramétrage des mails")
        self.resize(620, 560)
        self.mail_config = MailConfigManager()

        outer = QVBoxLayout(self)
        self.tabs = QTabWidget()
        outer.addWidget(self.tabs)

        self.tabs.addTab(self._build_new_message_tab(), "✉️  Nouveau message")
        self.tabs.addTab(self._build_smtp_config_tab(), "⚙️  Configuration SMTP")

    # ------------------------------------------------------------------
    # Onglet Nouveau message
    # ------------------------------------------------------------------

    def _build_new_message_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)

        self.msg_category_combo = QComboBox()
        self.msg_category_combo.addItems([a.categorie for a in self.mail_config.accounts])
        self.msg_category_combo.currentTextChanged.connect(self._on_message_category_changed)

        self.msg_dest_edit = QLineEdit()
        self.msg_cc_edit = QLineEdit()
        self.msg_subject_edit = QLineEdit()
        self.msg_body_edit = QTextEdit()

        form = QFormLayout()
        form.addRow("Categorie / compte :", self.msg_category_combo)
        form.addRow("Destinataire(s) principal(aux) :", self.msg_dest_edit)
        form.addRow("CC (optionnel) :", self.msg_cc_edit)
        form.addRow("Objet :", self.msg_subject_edit)
        layout.addLayout(form)
        layout.addWidget(QLabel("Message :"))
        layout.addWidget(self.msg_body_edit, stretch=1)

        self.msg_status_label = QLabel("")
        send_btn = QPushButton("📤 Envoyer")
        send_btn.setObjectName("primaryBtn")
        send_btn.clicked.connect(self._on_send_message)
        send_row = QHBoxLayout()
        send_row.addWidget(send_btn)
        send_row.addWidget(self.msg_status_label)
        send_row.addStretch()
        layout.addLayout(send_row)

        if self.mail_config.accounts:
            self._on_message_category_changed(self.mail_config.accounts[0].categorie)

        return w

    def _on_message_category_changed(self, categorie: str):
        account = self.mail_config.get_account(categorie)
        if account:
            self.msg_dest_edit.setText("; ".join(account.destinataires))
            self.msg_cc_edit.setText("; ".join(account.cc))

    def _on_send_message(self):
        categorie = self.msg_category_combo.currentText()
        account = self.mail_config.get_account(categorie)
        if not account:
            get_logger().warning("Envoi de mail annule : categorie '%s' introuvable dans la configuration.", categorie)
            QMessageBox.warning(self, "Compte introuvable", "Selectionne une categorie valide.")
            return
        if not account.smtp_server or not account.expediteur:
            get_logger().warning("Envoi de mail annule : compte SMTP '%s' non configure.", categorie)
            QMessageBox.warning(self, "Configuration incomplete",
                                 f"Le compte SMTP '{categorie}' n'est pas configure (onglet Configuration SMTP).")
            return

        self.msg_status_label.setText("Envoi en cours...")
        ok, msg = send_mail(
            account,
            subject=self.msg_subject_edit.text().strip(),
            body=self.msg_body_edit.toPlainText(),
            destinataires_override=self.msg_dest_edit.text().strip(),
            cc_override=self.msg_cc_edit.text().strip(),
        )
        if ok:
            self.msg_status_label.setText("✅ Envoye")
            get_logger().info("Mail envoye via le compte '%s' (sujet : %s)", categorie, self.msg_subject_edit.text().strip())
        else:
            self.msg_status_label.setText("❌ Echec")
            get_logger().error("Echec de l'envoi du mail via le compte '%s' : %s", categorie, msg)
            QMessageBox.warning(self, "Echec de l'envoi", msg)

    # ------------------------------------------------------------------
    # Onglet Configuration SMTP (sous-onglets par categorie)
    # ------------------------------------------------------------------

    def _build_smtp_config_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)

        self.smtp_subtabs = QTabWidget()
        layout.addWidget(self.smtp_subtabs)
        self._account_widgets: dict[str, dict] = {}
        for account in self.mail_config.accounts:
            self.smtp_subtabs.addTab(self._build_account_form(account), account.categorie)

        add_cat_btn = QPushButton("➕ Ajouter une categorie")
        add_cat_btn.setObjectName("ghostBtn")
        add_cat_btn.clicked.connect(self._add_category)
        btn_row = QHBoxLayout()
        btn_row.addWidget(add_cat_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)
        return w

    def _build_account_form(self, account: MailAccountConfig) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.addWidget(QLabel(f"Configuration SMTP — {account.categorie}"))

        server_edit = QLineEdit(account.smtp_server)
        port_spin = QSpinBox()
        port_spin.setRange(1, 65535)
        port_spin.setValue(account.port)
        identifiant_edit = QLineEdit(account.identifiant)
        password_edit = QLineEdit(account.mot_de_passe)
        password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        expediteur_edit = QLineEdit(account.expediteur)
        tls_check = QCheckBox("Chiffrement TLS/STARTTLS")
        tls_check.setChecked(account.tls)

        form = QFormLayout()
        form.addRow("Serveur SMTP :", server_edit)
        form.addRow("Port :", port_spin)
        form.addRow("Identifiant :", identifiant_edit)
        form.addRow("Mot de passe :", password_edit)
        form.addRow("Expediteur :", expediteur_edit)
        form.addRow("", tls_check)
        layout.addLayout(form)

        status_label = QLabel("")
        test_btn = QPushButton(f"⚡ Tester le compte {account.categorie}")
        test_row = QHBoxLayout()
        test_row.addWidget(test_btn)
        test_row.addWidget(status_label)
        test_row.addStretch()
        layout.addLayout(test_row)

        layout.addWidget(QLabel("Destinataires"))
        layout.addWidget(QLabel("Separez plusieurs adresses par ; ou ,"))
        dest_edit = QLineEdit("; ".join(account.destinataires))
        cc_edit = QLineEdit("; ".join(account.cc))
        form2 = QFormLayout()
        form2.addRow("Destinataire(s) principal(aux) :", dest_edit)
        form2.addRow("CC (optionnel) :", cc_edit)
        layout.addLayout(form2)

        save_btn = QPushButton("💾 Enregistrer")
        save_btn.setObjectName("primaryBtn")
        layout.addWidget(save_btn)
        layout.addStretch()

        widgets = dict(
            server=server_edit, port=port_spin, identifiant=identifiant_edit,
            password=password_edit, expediteur=expediteur_edit, tls=tls_check,
            dest=dest_edit, cc=cc_edit, status=status_label,
        )
        self._account_widgets[account.id] = widgets

        def do_save():
            import re
            self.mail_config.update_account(
                account.id,
                smtp_server=server_edit.text().strip(),
                port=port_spin.value(),
                identifiant=identifiant_edit.text().strip(),
                mot_de_passe=password_edit.text(),
                expediteur=expediteur_edit.text().strip(),
                tls=tls_check.isChecked(),
                destinataires=[a.strip() for a in re.split(r"[;,]", dest_edit.text()) if a.strip()],
                cc=[a.strip() for a in re.split(r"[;,]", cc_edit.text()) if a.strip()],
            )
            status_label.setText("💾 Enregistre")

        def do_test():
            do_save()
            status_label.setText("Test en cours...")
            fresh = self.mail_config.get_account(account.categorie)
            ok, msg = test_smtp(fresh)
            if ok:
                status_label.setText("✅ OK")
                get_logger().info("Test SMTP reussi pour le compte '%s' (%s)", account.categorie, fresh.smtp_server)
            else:
                status_label.setText("❌ Echec")
                get_logger().error("Echec du test SMTP pour le compte '%s' (%s) : %s", account.categorie, fresh.smtp_server, msg)
                QMessageBox.warning(self, "Echec du test SMTP", msg)

        save_btn.clicked.connect(do_save)
        test_btn.clicked.connect(do_test)

        return w

    def _add_category(self):
        nom, ok = QInputDialog.getText(self, "Nouvelle categorie", "Nom de la categorie (ex: Direction) :")
        if not ok or not nom.strip():
            return
        account = self.mail_config.add_category(nom.strip())
        self.smtp_subtabs.addTab(self._build_account_form(account), account.categorie)
        self.msg_category_combo.addItem(account.categorie)

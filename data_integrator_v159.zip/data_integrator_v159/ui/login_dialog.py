from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QFormLayout, QLineEdit, QVBoxLayout, QHBoxLayout,
    QLabel, QMessageBox, QPushButton
)

from core.auth_config import AuthConfig
from core.auth_db import authenticate, change_password, AuthenticatedUser


class ChangePasswordDialog(QDialog):
    """Affiche apres une connexion reussie quand doit_changer_mdp = 1 en
    base : l'utilisateur doit definir un nouveau mot de passe avant de
    pouvoir continuer (verrou applique cote USERS_PYTHON, pas seulement
    cote ecran)."""

    def __init__(self, auth_config: AuthConfig, user: AuthenticatedUser, parent=None):
        super().__init__(parent)
        self.auth_config = auth_config
        self.user = user
        self.setWindowTitle("Changement de mot de passe requis")
        self.setMinimumWidth(380)
        self.setModal(True)

        info = QLabel("Votre mot de passe doit etre change avant de continuer.")
        info.setWordWrap(True)

        self.new_pwd_edit = QLineEdit()
        self.new_pwd_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_pwd_edit = QLineEdit()
        self.confirm_pwd_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_pwd_edit.returnPressed.connect(self._on_confirm)

        form = QFormLayout()
        form.addRow("Nouveau mot de passe :", self.new_pwd_edit)
        form.addRow("Confirmation :", self.confirm_pwd_edit)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color:#B3261E;")
        self.status_label.setWordWrap(True)

        ok_btn = QPushButton("Valider")
        ok_btn.setObjectName("primaryBtn")
        ok_btn.clicked.connect(self._on_confirm)

        layout = QVBoxLayout()
        layout.addWidget(info)
        layout.addLayout(form)
        layout.addWidget(self.status_label)
        layout.addWidget(ok_btn)
        self.setLayout(layout)

    def _on_confirm(self):
        pwd1 = self.new_pwd_edit.text()
        pwd2 = self.confirm_pwd_edit.text()
        if len(pwd1) < 8:
            self.status_label.setText("Le mot de passe doit contenir au moins 8 caracteres.")
            return
        if pwd1 != pwd2:
            self.status_label.setText("Les deux mots de passe ne correspondent pas.")
            return
        ok, msg = change_password(self.auth_config, self.user.id, pwd1)
        if not ok:
            self.status_label.setText(f"Echec de l'enregistrement : {msg}")
            return
        self.user.must_change_password = False
        self.accept()


class LoginDialog(QDialog):
    """Ecran de connexion obligatoire au demarrage (V148), affiche uniquement
    quand l'authentification centralisee est activee (AuthConfig.active).
    Verifie les identifiants aupres de la base OUTILS partagee (USERS_PYTHON)
    et consigne chaque tentative dans USERS_PYTHON_HISTO."""

    def __init__(self, auth_config: AuthConfig, parent=None):
        super().__init__(parent)
        self.auth_config = auth_config
        self.authenticated_user: AuthenticatedUser | None = None
        self.setWindowTitle("Data Integrator — Connexion")
        self.setMinimumWidth(380)
        self.setModal(True)
        self.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)

        title = QLabel("🔐  Connexion requise")
        title_font = title.font()
        title_font.setPointSize(title_font.pointSize() + 2)
        title_font.setBold(True)
        title.setFont(title_font)

        self.login_edit = QLineEdit()
        self.login_edit.returnPressed.connect(self._on_login_clicked)
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_edit.returnPressed.connect(self._on_login_clicked)

        form = QFormLayout()
        form.addRow("Utilisateur :", self.login_edit)
        form.addRow("Mot de passe :", self.password_edit)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color:#B3261E;")
        self.status_label.setWordWrap(True)

        self.login_btn = QPushButton("Se connecter")
        self.login_btn.setObjectName("primaryBtn")
        self.login_btn.clicked.connect(self._on_login_clicked)
        cancel_btn = QPushButton("Annuler")
        cancel_btn.clicked.connect(self.reject)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(cancel_btn)
        btn_row.addWidget(self.login_btn)

        layout = QVBoxLayout()
        layout.addWidget(title)
        layout.addLayout(form)
        layout.addWidget(self.status_label)
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _on_login_clicked(self):
        login = self.login_edit.text().strip()
        password = self.password_edit.text()
        if not login or not password:
            self.status_label.setText("Identifiant et mot de passe requis.")
            return

        self.login_btn.setEnabled(False)
        self.status_label.setText("Connexion en cours...")
        try:
            result = authenticate(self.auth_config, login, password)
        finally:
            self.login_btn.setEnabled(True)

        if not result.success:
            self.status_label.setText(result.message)
            self.password_edit.clear()
            self.password_edit.setFocus()
            return

        user = result.user
        if user.must_change_password:
            dlg = ChangePasswordDialog(self.auth_config, user, parent=self)
            if dlg.exec() != QDialog.DialogCode.Accepted:
                # L'utilisateur a renonce au changement de mot de passe
                # obligatoire : on ne le laisse pas entrer dans l'application.
                self.status_label.setText("Changement de mot de passe requis pour continuer.")
                return

        self.authenticated_user = user
        self.accept()

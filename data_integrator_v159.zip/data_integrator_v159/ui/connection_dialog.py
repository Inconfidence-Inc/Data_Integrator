from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QFormLayout, QLineEdit, QComboBox, QDialogButtonBox,
    QVBoxLayout, QHBoxLayout, QLabel, QMessageBox, QPushButton,
    QListWidget, QListWidgetItem, QInputDialog
)
from PySide6.QtCore import Qt

from core.config_manager import ConfigManager, ConnectionProfile
from core.db import test_connection
from core.log_manager import get_logger


DRIVERS = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "SQL Server",
]


class ConnectionManagerDialog(QDialog):
    """Gere plusieurs profils de connexion (ex: Recette, Production) : ajout,
    suppression, edition, selection du profil actif, test de connexion."""

    def __init__(self, config: ConfigManager, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("Profils de connexion SQL Server")
        self.setMinimumWidth(560)
        self._current_id: str | None = config.active_connection_id

        self.profile_list = QListWidget()
        self.profile_list.currentItemChanged.connect(self._on_profile_selected)

        add_btn = QPushButton("➕")
        add_btn.setToolTip("Ajouter un profil")
        add_btn.setFixedWidth(36)
        add_btn.clicked.connect(self._add_profile)
        del_btn = QPushButton("🗑️")
        del_btn.setToolTip("Supprimer le profil")
        del_btn.setFixedWidth(36)
        del_btn.clicked.connect(self._delete_profile)
        activate_btn = QPushButton("✅ Definir actif")
        activate_btn.clicked.connect(self._activate_profile)

        list_btn_row = QHBoxLayout()
        list_btn_row.addWidget(add_btn)
        list_btn_row.addWidget(del_btn)
        list_btn_row.addStretch()

        list_col = QVBoxLayout()
        list_col.addWidget(QLabel("Profils :"))
        list_col.addWidget(self.profile_list)
        list_col.addLayout(list_btn_row)
        list_col.addWidget(activate_btn)

        self.nom_edit = QLineEdit()
        self.server_edit = QLineEdit()
        self.database_edit = QLineEdit()
        self.username_edit = QLineEdit()
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.driver_combo = QComboBox()
        self.driver_combo.addItems(DRIVERS)

        for w in (self.nom_edit, self.server_edit, self.database_edit, self.username_edit, self.password_edit):
            w.textChanged.connect(self._save_current_fields)
        self.driver_combo.currentTextChanged.connect(self._save_current_fields)

        form = QFormLayout()
        form.addRow("Nom du profil :", self.nom_edit)
        form.addRow("Serveur :", self.server_edit)
        form.addRow("Base de donnees :", self.database_edit)
        form.addRow("Utilisateur (vide = auth Windows) :", self.username_edit)
        form.addRow("Mot de passe :", self.password_edit)
        form.addRow("Pilote ODBC :", self.driver_combo)

        self.status_label = QLabel("")
        test_btn = QPushButton("Tester la connexion")
        test_btn.clicked.connect(self._on_test)
        test_row = QHBoxLayout()
        test_row.addWidget(test_btn)
        test_row.addWidget(self.status_label)
        test_row.addStretch()

        form_col = QVBoxLayout()
        form_col.addLayout(form)
        form_col.addLayout(test_row)

        content_row = QHBoxLayout()
        content_row.addLayout(list_col, stretch=1)
        content_row.addLayout(form_col, stretch=2)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.accept)
        buttons.accepted.connect(self.accept)

        layout = QVBoxLayout()
        layout.addLayout(content_row)
        layout.addWidget(buttons)
        self.setLayout(layout)

        self._refresh_list()

    # ------------------------------------------------------------------

    def _refresh_list(self):
        self.profile_list.blockSignals(True)
        self.profile_list.clear()
        selected_item = None
        for profile in self.config.connections:
            label = profile.nom
            if profile.id == self.config.active_connection_id:
                label += "  (actif)"
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, profile.id)
            self.profile_list.addItem(item)
            if profile.id == self._current_id:
                selected_item = item
        if selected_item is None and self.profile_list.count() > 0:
            selected_item = self.profile_list.item(0)
        if selected_item is not None:
            self.profile_list.setCurrentItem(selected_item)
        self.profile_list.blockSignals(False)
        # Les signaux etaient bloques pendant la construction : peupler le
        # formulaire manuellement pour la selection restauree/par defaut.
        self._on_profile_selected(selected_item, None)

    def _on_profile_selected(self, current: QListWidgetItem, previous: QListWidgetItem):
        if current is None:
            return
        profile_id = current.data(Qt.ItemDataRole.UserRole)
        profile = self.config.get_connection(profile_id)
        if not profile:
            return
        self._current_id = profile_id
        self._loading = True
        self.nom_edit.setText(profile.nom)
        self.server_edit.setText(profile.server)
        self.database_edit.setText(profile.database)
        self.username_edit.setText(profile.username)
        self.password_edit.setText(profile.password)
        idx = self.driver_combo.findText(profile.driver)
        self.driver_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self._loading = False
        self.status_label.setText("")

    def _save_current_fields(self, *_args):
        if getattr(self, "_loading", False) or not self._current_id:
            return
        self.config.update_connection(
            self._current_id,
            nom=self.nom_edit.text().strip() or "Sans nom",
            server=self.server_edit.text().strip(),
            database=self.database_edit.text().strip(),
            username=self.username_edit.text().strip(),
            password=self.password_edit.text(),
            driver=self.driver_combo.currentText(),
        )
        self._refresh_list()

    def _add_profile(self):
        nom, ok = QInputDialog.getText(self, "Nouveau profil", "Nom du profil (ex: Recette, Production) :")
        if not ok or not nom.strip():
            return
        profile = ConnectionProfile.new(nom=nom.strip())
        self.config.add_connection(profile)
        self._current_id = profile.id
        self._refresh_list()

    def _delete_profile(self):
        if not self._current_id:
            return
        if len(self.config.connections) <= 1:
            QMessageBox.information(self, "Impossible", "Il doit rester au moins un profil de connexion.")
            return
        confirm = QMessageBox.question(self, "Confirmer", "Supprimer ce profil de connexion ?")
        if confirm == QMessageBox.StandardButton.Yes:
            self.config.remove_connection(self._current_id)
            self._current_id = None
            self._refresh_list()

    def _activate_profile(self):
        if not self._current_id:
            return
        self.config.set_active_connection(self._current_id)
        self._refresh_list()

    def _on_test(self):
        if not self._current_id:
            return
        profile = self.config.get_connection(self._current_id)
        self.status_label.setText("Test en cours...")
        ok, msg = test_connection(profile)
        if ok:
            self.status_label.setText("✅ OK")
            get_logger().info("Test de connexion reussi pour le profil '%s' (%s / %s)", profile.nom, profile.server, profile.database)
        else:
            self.status_label.setText("❌ Echec")
            get_logger().error("Echec du test de connexion pour le profil '%s' (%s / %s) : %s", profile.nom, profile.server, profile.database, msg)
            QMessageBox.warning(self, "Echec de connexion", msg)

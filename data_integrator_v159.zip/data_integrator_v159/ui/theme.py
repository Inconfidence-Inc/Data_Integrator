"""
theme.py
--------
Feuille de style QSS globale, inspiree de Material Design 3 : palette de
role (primary/surface/error/...), cartes surelevees (QGroupBox + elevation.py
pour l'ombre portee), champs "outlined", boutons pill, onglets a indicateur
de soulignement, barre d'outils en App Bar coloree.

Appliquee une seule fois sur QApplication (voir main.py).
Les couleurs sont centralisees dans material_colors.py pour rester
coherentes avec le code Python (statuts, badges...).
"""

from ui.material_colors import (
    PRIMARY, ON_PRIMARY, PRIMARY_CONTAINER, ON_PRIMARY_CONTAINER,
    SECONDARY_CONTAINER,
    ERROR, ON_ERROR, ERROR_CONTAINER,
    SUCCESS_CONTAINER, ON_SUCCESS_CONTAINER,
    SURFACE, SURFACE_VARIANT, BACKGROUND, OUTLINE, OUTLINE_VARIANT,
    ON_SURFACE, ON_SURFACE_VARIANT,
)

THEME_QSS = f"""
* {{
    font-family: 'Segoe UI', Roboto, Arial, sans-serif;
    font-size: 10pt;
}}

QMainWindow, QWidget {{
    background-color: {BACKGROUND};
    color: {ON_SURFACE};
}}

/* ---------------------------------------------------------------------
   Cartes (QGroupBox) : surface Material surelevee, coins tres arrondis.
   L'ombre portee elle-meme est appliquee en Python via elevation.py
   (QSS ne sait pas dessiner de box-shadow).
--------------------------------------------------------------------- */
QGroupBox {{
    background-color: {SURFACE};
    border: none;
    border-radius: 16px;
    margin-top: 20px;
    padding: 16px;
    font-weight: 600;
    font-size: 10.5pt;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 16px;
    top: 2px;
    padding: 3px 10px;
    background-color: {PRIMARY_CONTAINER};
    color: {ON_PRIMARY_CONTAINER};
    border-radius: 10px;
}}

/* ---------------------------------------------------------------------
   Tableaux
--------------------------------------------------------------------- */
QTableWidget {{
    background-color: {SURFACE};
    gridline-color: {OUTLINE};
    border: 1.5px solid {OUTLINE};
    border-radius: 12px;
    selection-background-color: {PRIMARY_CONTAINER};
    selection-color: {ON_PRIMARY_CONTAINER};
    alternate-background-color: {SURFACE_VARIANT};
}}
QTableWidget::item {{
    padding: 8px 6px;
    border-bottom: 1px solid {OUTLINE_VARIANT};
}}
QTableWidget::item:hover {{
    background-color: {PRIMARY_CONTAINER};
}}
QHeaderView::section {{
    background-color: {SURFACE_VARIANT};
    padding: 11px 6px;
    border: none;
    border-bottom: 2px solid {OUTLINE};
    font-weight: 700;
    color: {ON_SURFACE};
}}

/* ---------------------------------------------------------------------
   Boutons Material : "filled" (primaire), "filled error" (danger),
   "outlined" (ghost/secondaire), "tonal" (par defaut). Forme pill.
--------------------------------------------------------------------- */
QPushButton {{
    background-color: {SECONDARY_CONTAINER};
    border: none;
    border-radius: 18px;
    padding: 8px 18px;
    color: {ON_SURFACE};
    font-weight: 500;
}}
QPushButton:hover {{
    background-color: {OUTLINE_VARIANT};
}}
QPushButton:pressed {{
    background-color: {OUTLINE};
}}
QPushButton:disabled {{
    color: #9AA0A6;
    background-color: {SURFACE_VARIANT};
}}

QPushButton#primaryBtn {{
    background-color: {PRIMARY};
    color: {ON_PRIMARY};
    font-weight: 600;
    border: none;
    padding: 9px 22px;
}}
QPushButton#primaryBtn:hover {{ background-color: #1662C4; }}
QPushButton#primaryBtn:pressed {{ background-color: #0F52A0; }}
QPushButton#primaryBtn:disabled {{ background-color: #A8C7FA; color: #EEF2FB; }}

QPushButton#dangerBtn {{
    background-color: {ERROR};
    color: {ON_ERROR};
    font-weight: 600;
    border: none;
}}
QPushButton#dangerBtn:hover {{ background-color: #962018; }}
QPushButton#dangerBtn:disabled {{ background-color: #ECACA6; color: #FDEEED; }}

QPushButton#ghostBtn {{
    background-color: transparent;
    border: 1.5px solid {OUTLINE};
    color: {PRIMARY};
    font-weight: 500;
}}
QPushButton#ghostBtn:hover {{ background-color: {PRIMARY_CONTAINER}; border-color: {PRIMARY}; }}
QPushButton#ghostBtn:pressed {{ background-color: {SECONDARY_CONTAINER}; }}

/* ---------------------------------------------------------------------
   Barre de progression : indicateur lineaire Material, fin et arrondi
--------------------------------------------------------------------- */
QProgressBar {{
    border: none;
    border-radius: 5px;
    text-align: center;
    background-color: {SURFACE_VARIANT};
    height: 10px;
    font-weight: 600;
    font-size: 8pt;
    color: {ON_SURFACE_VARIANT};
}}
QProgressBar::chunk {{
    background-color: {PRIMARY};
    border-radius: 5px;
}}

/* ---------------------------------------------------------------------
   Barre d'outils = App Bar Material (couleur primaire, texte clair)
--------------------------------------------------------------------- */
QToolBar {{
    background-color: {PRIMARY};
    spacing: 8px;
    padding: 10px;
    border: none;
}}
QToolBar QToolButton {{
    background-color: transparent;
    border: none;
    color: {ON_PRIMARY};
    padding: 8px 14px;
    border-radius: 18px;
    font-weight: 600;
}}
QToolBar QToolButton:hover {{
    background-color: rgba(255, 255, 255, 0.16);
}}
QToolBar QToolButton:pressed {{
    background-color: rgba(255, 255, 255, 0.24);
}}

/* ---------------------------------------------------------------------
   Champs de saisie "outlined" Material
--------------------------------------------------------------------- */
QLineEdit, QComboBox, QSpinBox, QTextEdit {{
    background-color: {SURFACE};
    border: 1.5px solid {OUTLINE};
    border-radius: 8px;
    padding: 7px 10px;
    selection-background-color: {PRIMARY_CONTAINER};
    selection-color: {ON_PRIMARY_CONTAINER};
}}
QLineEdit:hover, QComboBox:hover, QSpinBox:hover, QTextEdit:hover {{
    border-color: {ON_SURFACE_VARIANT};
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QTextEdit:focus {{
    border: 2px solid {PRIMARY};
    padding: 6px 9px;
}}
QComboBox::drop-down {{
    border: none;
    width: 28px;
    background-color: transparent;
}}
QComboBox::drop-down:hover {{
    background-color: {SURFACE_VARIANT};
    border-radius: 6px;
}}
QComboBox::down-arrow {{
    image: none;
    width: 0px;
    height: 0px;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid {ON_SURFACE_VARIANT};
    margin-right: 8px;
}}
QComboBox:!editable {{
    background-color: {SURFACE};
}}
QComboBox QLineEdit {{
    border: none;
    background: transparent;
    padding: 0px;
    margin: 0px;
    color: {ON_SURFACE};
}}
QComboBox QAbstractItemView {{
    background-color: {SURFACE};
    border: 1px solid {OUTLINE};
    border-radius: 8px;
    selection-background-color: {PRIMARY_CONTAINER};
    selection-color: {ON_PRIMARY_CONTAINER};
    outline: none;
}}

/* ---------------------------------------------------------------------
   Onglets Material : fond transparent, indicateur souligne sur l'actif
--------------------------------------------------------------------- */
QTabWidget::pane {{
    border: none;
    border-top: 1px solid {OUTLINE_VARIANT};
    background-color: transparent;
    top: -1px;
}}
QTabBar::tab {{
    background-color: transparent;
    color: {ON_SURFACE_VARIANT};
    padding: 10px 18px;
    margin-right: 4px;
    border: none;
    border-bottom: 3px solid transparent;
    font-weight: 600;
}}
QTabBar::tab:selected {{
    color: {PRIMARY};
    border-bottom: 3px solid {PRIMARY};
}}
QTabBar::tab:hover:!selected {{
    color: {ON_SURFACE};
    background-color: {SURFACE_VARIANT};
    border-radius: 8px;
}}

/* ---------------------------------------------------------------------
   Cases a cocher Material (indicateur rempli quand coche)
--------------------------------------------------------------------- */
QCheckBox {{
    spacing: 8px;
}}
QCheckBox::indicator {{
    width: 18px;
    height: 18px;
    border: 2px solid {OUTLINE};
    border-radius: 4px;
    background-color: {SURFACE};
}}
QCheckBox::indicator:hover {{
    border-color: {PRIMARY};
}}
QCheckBox::indicator:checked {{
    background-color: {PRIMARY};
    border-color: {PRIMARY};
}}

/* ---------------------------------------------------------------------
   Listes (gestionnaire de connexions, etc.)
--------------------------------------------------------------------- */
QListWidget {{
    background-color: {SURFACE};
    border: 1.5px solid {OUTLINE};
    border-radius: 10px;
    padding: 4px;
    outline: none;
}}
QListWidget::item {{
    padding: 8px 10px;
    border-radius: 8px;
    margin: 2px;
}}
QListWidget::item:selected {{
    background-color: {PRIMARY_CONTAINER};
    color: {ON_PRIMARY_CONTAINER};
}}
QListWidget::item:hover:!selected {{
    background-color: {SURFACE_VARIANT};
}}

/* ---------------------------------------------------------------------
   Ascenseurs discrets
--------------------------------------------------------------------- */
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
    margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: {OUTLINE};
    border-radius: 5px;
    min-height: 24px;
}}
QScrollBar::handle:vertical:hover {{
    background: {ON_SURFACE_VARIANT};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}
QScrollBar:horizontal {{
    background: transparent;
    height: 10px;
    margin: 2px;
}}
QScrollBar::handle:horizontal {{
    background: {OUTLINE};
    border-radius: 5px;
    min-width: 24px;
}}

/* ---------------------------------------------------------------------
   Libelles de statut de connexion (utilises dynamiquement en Python)
--------------------------------------------------------------------- */
QLabel#connStatusOk {{ color: {ON_SUCCESS_CONTAINER}; font-weight: 600; }}
QLabel#connStatusBad {{ color: {ERROR}; font-weight: 600; }}
QLabel#connStatusUnknown {{ color: {ON_SURFACE_VARIANT}; font-weight: 600; }}
"""

"""
ok_ko_dialog.py
-----------------
Petit ecran d'administration dedie (V107) pour configurer les repertoires
OK / KO du Data Checker (Pretraitement).

V108 : un seul repertoire PARENT par TPA — les sous-repertoires "OK" et
"KO" sont deduits automatiquement (parent\\OK et parent\\KO).

V109 : sur demande explicite de l'utilisateur, aligne les lignes du
tableau sur les vraies SOURCES (type + pays), et non plus sur le seul
type de TPA — un type comme SPB recouvre en realite 4 sources distinctes
(France, Italie, Espagne, Pologne), chacune potentiellement destinee a un
repertoire different. 9 lignes desormais (au lieu de 6), une par source
reellement configuree dans l'application.
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QWidget, QLabel, QPushButton,
    QLineEdit, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QFileDialog,
)

from core.config_manager import TPA_TYPES

PARENT_COL_TYPE, PARENT_COL_DOSSIER, PARENT_COL_APERCU = range(3)
PARENT_HEADERS = ["Source (Type / Pays)", "Repertoire parent", "Aperçu (deduit automatiquement)"]


def _joindre(parent: str, sous_dossier: str) -> str:
    """Joint un chemin parent et un sous-dossier en respectant la
    convention Windows (barre oblique inverse), quel que soit le systeme
    d'exploitation sur lequel Data Integrator s'execute reellement."""
    parent = parent.strip().rstrip("\\/")
    if not parent:
        return ""
    return f"{parent}\\{sous_dossier}"


def _deduire_parent(ok_folder: str, ko_folder: str) -> str:
    """Retrouve le repertoire parent a partir d'un ancien reglage OK/KO
    independant (V92-V107), pour ne pas perdre une configuration deja
    saisie avant ce changement : si le dossier OK se termine par OK (et
    correspond au meme parent que KO se terminant par KO), le parent
    commun est reconstitue automatiquement — quelle que soit la convention
    de separateur utilisee (\\ ou /)."""
    for folder, suffixe in ((ok_folder, "OK"), (ko_folder, "KO")):
        if not folder:
            continue
        nettoye = folder.rstrip("\\/")
        if nettoye.lower().endswith(suffixe.lower()) and len(nettoye) > len(suffixe) and nettoye[-(len(suffixe) + 1)] in "\\/":
            return nettoye[: -(len(suffixe) + 1)]
    return ""


class OkKoConfigDialog(QDialog):
    """Ecran d'administration : un repertoire PARENT par SOURCE reelle
    (type + pays — V109), dont les sous-dossiers OK et KO sont deduits
    automatiquement. Se ferme simplement (pas de bouton "Annuler" separe)
    car chaque modification est enregistree immediatement, comme le reste
    de l'application."""

    def __init__(self, rules_manager, sources, log_cb, parent=None):
        super().__init__(parent)
        self.rules = rules_manager
        self.log_cb = log_cb
        self.setWindowTitle("Administration — Repertoires OK / KO (Data Checker)")
        self.resize(860, 620)

        # V109 : sources reelles (type, pays) uniques, dans l'ordre des
        # TPA_TYPES puis alphabetique par pays au sein d'un meme type —
        # ex: SPB (France), SPB (Italie), SPB (Espagne), SPB (Pologne),
        # Evy (France), ... Deduplique naturellement les memes sources
        # apparaissant dans plusieurs domaines (Adhesion/Sinistre/FIC).
        paires = {(s.type, s.pays) for s in sources}
        for tpa_type in set(t for t, _ in paires):
            if tpa_type not in TPA_TYPES:
                TPA_TYPES.append(tpa_type)  # securite si un type inconnu existe deja en config

        def _cle_tri(item):
            type_tpa, pays = item
            idx_type = TPA_TYPES.index(type_tpa) if type_tpa in TPA_TYPES else len(TPA_TYPES)
            return (idx_type, pays)

        self.sources_paires = sorted(paires, key=_cle_tri)

        from core.config_manager import types_avec_plusieurs_pays
        self.types_multi_pays = types_avec_plusieurs_pays(sources)

        layout = QVBoxLayout(self)

        info = QLabel(
            "Un seul repertoire PARENT a choisir par source (type + pays) : les sous-dossiers « OK » et "
            "« KO » sont deduits automatiquement (parent\\OK et parent\\KO) et crees si besoin au premier "
            "deplacement. A l'issue du controle (comme dans Orchestrator), un fichier sans erreur part dans "
            "OK, un fichier en erreur part dans KO — un avertissement non bloquant reste considere OK. "
            "Laisse le parent vide pour ne pas deplacer les fichiers de cette source."
        )
        info.setWordWrap(True)
        info.setStyleSheet("color:#5F6368; font-style:italic;")
        layout.addWidget(info)

        self.parent_table = QTableWidget(0, len(PARENT_HEADERS))
        self.parent_table.setHorizontalHeaderLabels(PARENT_HEADERS)
        self.parent_table.horizontalHeader().setSectionResizeMode(PARENT_COL_TYPE, QHeaderView.ResizeMode.Fixed)
        self.parent_table.setColumnWidth(PARENT_COL_TYPE, 150)
        self.parent_table.horizontalHeader().setSectionResizeMode(PARENT_COL_DOSSIER, QHeaderView.ResizeMode.Stretch)
        self.parent_table.horizontalHeader().setSectionResizeMode(PARENT_COL_APERCU, QHeaderView.ResizeMode.Stretch)
        self.parent_table.verticalHeader().setVisible(False)
        self.parent_table.verticalHeader().setDefaultSectionSize(44)
        layout.addWidget(self.parent_table, stretch=1)

        self._populate_parent_table()

        opts_row = QHBoxLayout()
        self.deplacement_checkbox = QCheckBox("Deplacer les fichiers apres chaque controle")
        self.deplacement_checkbox.setChecked(self.rules.deplacement_actif)
        self.deplacement_checkbox.toggled.connect(self._save_move_config)
        self.mail_ko_checkbox = QCheckBox("Envoyer un mail (DSI) si des fichiers sont deplaces en KO")
        self.mail_ko_checkbox.setChecked(self.rules.mail_ko_actif)
        self.mail_ko_checkbox.toggled.connect(self._save_move_config)
        opts_row.addWidget(self.deplacement_checkbox)
        opts_row.addWidget(self.mail_ko_checkbox)
        opts_row.addStretch()
        layout.addLayout(opts_row)

        close_row = QHBoxLayout()
        close_row.addStretch()
        close_btn = QPushButton("Fermer")
        close_btn.setObjectName("primaryBtn")
        close_btn.clicked.connect(self.accept)
        close_row.addWidget(close_btn)
        layout.addLayout(close_row)

    def _populate_parent_table(self):
        self.parent_table.setRowCount(0)
        for type_tpa, pays in self.sources_paires:
            cle = f"{type_tpa}|{pays}"
            ok_actuel = self.rules.ok_folder_by_tpa.get(cle) or self.rules.get_ok_folder(type_tpa)
            ko_actuel = self.rules.ko_folder_by_tpa.get(cle) or self.rules.get_ko_folder(type_tpa)
            parent_actuel = _deduire_parent(ok_actuel or "", ko_actuel or "")
            self._append_parent_row(type_tpa, pays, parent_actuel)

    def _append_parent_row(self, type_tpa: str, pays: str, parent_folder: str):
        row = self.parent_table.rowCount()
        self.parent_table.insertRow(row)
        self.parent_table.setRowHeight(row, 50)

        from core.config_manager import label_tpa
        label = label_tpa(type_tpa, pays, self.types_multi_pays)
        type_item = QTableWidgetItem(label)
        type_item.setFlags(type_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        # cle combinee stockee discretement pour la collecte, sans alourdir l'affichage
        type_item.setData(Qt.ItemDataRole.UserRole, (type_tpa, pays))
        self.parent_table.setItem(row, PARENT_COL_TYPE, type_item)

        widget = QWidget()
        widget.setMinimumHeight(40)
        row_layout = QHBoxLayout(widget)
        row_layout.setContentsMargins(3, 3, 3, 3)
        edit = QLineEdit(parent_folder)
        edit.setMinimumHeight(32)
        edit.setPlaceholderText("(non deplace)")
        edit.setStyleSheet(
            "QLineEdit {"
            "  background-color: #FAFBFF;"
            "  border: 1.5px solid #B0B8C4;"
            "  border-radius: 6px;"
            "  padding: 4px 8px;"
            "  color: #1F1F1F;"
            "  font-size: 10pt;"
            "}"
            "QLineEdit:focus { border: 2px solid #1A73E8; background-color: #FFFFFF; }"
        )
        edit.textChanged.connect(lambda _text, r=row: self._on_parent_changed(r))
        edit.editingFinished.connect(self._save_move_config)
        browse_btn = QPushButton("Parcourir")
        browse_btn.setObjectName("ghostBtn")
        browse_btn.setMinimumHeight(32)
        browse_btn.setFixedWidth(110)
        browse_btn.setToolTip(f"Choisir le repertoire parent pour {label}")
        browse_btn.clicked.connect(lambda: self._browse_parent_folder(edit))
        row_layout.addWidget(edit)
        row_layout.addWidget(browse_btn)
        widget.parent_edit = edit
        self.parent_table.setCellWidget(row, PARENT_COL_DOSSIER, widget)

        apercu_item = QTableWidgetItem(self._texte_apercu(parent_folder))
        apercu_item.setFlags(apercu_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        apercu_item.setForeground(QColor("#5F6368"))
        self.parent_table.setItem(row, PARENT_COL_APERCU, apercu_item)

        # Applique la couleur du placeholder APRES l'insertion dans le
        # tableau (V97) : Qt reinitialise sinon la palette lors du
        # "repolish" declenche par le changement de parent.
        palette = edit.palette()
        palette.setColor(palette.ColorRole.PlaceholderText, QColor("#6B7280"))
        edit.setPalette(palette)

    @staticmethod
    def _texte_apercu(parent_folder: str) -> str:
        parent_folder = parent_folder.strip()
        if not parent_folder:
            return "(non deplace)"
        return f"{_joindre(parent_folder, 'OK')}   /   {_joindre(parent_folder, 'KO')}"

    def _on_parent_changed(self, row: int):
        widget = self.parent_table.cellWidget(row, PARENT_COL_DOSSIER)
        if not widget:
            return
        apercu_item = self.parent_table.item(row, PARENT_COL_APERCU)
        if apercu_item:
            apercu_item.setText(self._texte_apercu(widget.parent_edit.text()))

    def _browse_parent_folder(self, edit: QLineEdit):
        folder = QFileDialog.getExistingDirectory(self, "Choisir le repertoire parent", edit.text().strip())
        if folder:
            edit.setText(folder)  # declenche _on_parent_changed via textChanged
            self._save_move_config()

    def _collect_move_config(self) -> tuple[dict[str, str], dict[str, str]]:
        ok_folders, ko_folders = {}, {}
        for row in range(self.parent_table.rowCount()):
            type_item = self.parent_table.item(row, PARENT_COL_TYPE)
            if not type_item:
                continue
            type_tpa, pays = type_item.data(Qt.ItemDataRole.UserRole)
            widget = self.parent_table.cellWidget(row, PARENT_COL_DOSSIER)
            parent_folder = widget.parent_edit.text().strip() if widget else ""
            cle = f"{type_tpa}|{pays}"
            ok_folders[cle] = _joindre(parent_folder, "OK")
            ko_folders[cle] = _joindre(parent_folder, "KO")
        return ok_folders, ko_folders

    def _save_move_config(self, *_args):
        ok_folders, ko_folders = self._collect_move_config()
        self.rules.save_move_config(
            ok_folder_by_tpa=ok_folders, ko_folder_by_tpa=ko_folders,
            deplacement_actif=self.deplacement_checkbox.isChecked(),
            mail_ko_actif=self.mail_ko_checkbox.isChecked(),
        )
        self.log_cb("info", "Configuration des repertoires OK/KO enregistree.")

"""
console_widget.py
------------------
Console de type terminal pour afficher les logs avec couleur selon le niveau
(info / warning / error / debug / success), horodatage et defilement auto.
"""

from __future__ import annotations

import html
import time

from PySide6.QtGui import QFont, QTextCursor
from PySide6.QtWidgets import QTextEdit

from ui.material_colors import SURFACE_DARK, SURFACE_DARK_BORDER, ON_SURFACE_DARK

LEVEL_COLORS = {
    "info": "#8ce99a",
    "success": "#51cf66",
    "warning": "#ffc078",
    "error": "#ff8787",
    "debug": "#868e96",
}

LEVEL_LABELS = {
    "info": "INFO",
    "success": "OK  ",
    "warning": "WARN",
    "error": "ERR ",
    "debug": "DBG ",
}

CONSOLE_QSS = f"""
QTextEdit {{
    background-color: {SURFACE_DARK};
    color: {ON_SURFACE_DARK};
    border: 1px solid {SURFACE_DARK_BORDER};
    border-radius: 12px;
    padding: 12px;
}}
QScrollBar:vertical {{
    background: {SURFACE_DARK};
    width: 10px;
}}
QScrollBar::handle:vertical {{
    background: #3a4149;
    border-radius: 5px;
}}
"""


class ConsoleWidget(QTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        font = QFont("Consolas")
        if not font.exactMatch():
            font = QFont("Courier New")
        font.setPointSize(10)
        self.setFont(font)
        self.document().setMaximumBlockCount(5000)
        self.setStyleSheet(CONSOLE_QSS)

    def append_log(self, level: str, message: str):
        color = LEVEL_COLORS.get(level, "#d6dae3")
        label = LEVEL_LABELS.get(level, level.upper()[:4].ljust(4))
        ts = time.strftime("%H:%M:%S")
        safe_msg = html.escape(message).replace("\n", "<br>&nbsp;&nbsp;&nbsp;&nbsp;")
        line = (
            f'<span style="color:#5c6577;">[{ts}]</span> '
            f'<span style="color:{color}; font-weight:700;">{label}</span> '
            f'<span style="color:#d6dae3;">{safe_msg}</span>'
        )
        self.append(line)
        self.moveCursor(QTextCursor.MoveOperation.End)

    def clear_console(self):
        self.clear()

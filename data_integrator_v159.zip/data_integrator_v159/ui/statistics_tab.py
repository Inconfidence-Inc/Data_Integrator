from __future__ import annotations

from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGroupBox, QLabel, QComboBox,
    QPushButton, QTableWidget, QTableWidgetItem, QAbstractItemView
)

from core.config_manager import ConfigManager, DOMAINES
from core.load_history import LoadHistoryManager

DOMAIN_LABELS = {"Adhesion": "Adhésion", "Sinistre": "Sinistre", "FIC": "FIC", "Reclamation": "Réclamation"}


MOIS_FR = [
    "Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin",
    "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre",
]


def _month_label(year: int, month: int) -> str:
    return f"{MOIS_FR[month - 1]} {year}"


def _last_n_months(n: int) -> list[tuple[int, int]]:
    """Retourne les n derniers mois (annee, mois), du plus ancien au plus recent."""
    now = datetime.now()
    result = []
    y, m = now.year, now.month
    for _ in range(n):
        result.append((y, m))
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    return list(reversed(result))


class StatisticsTab(QWidget):
    """
    Ecran statistique (V59) : evolution sur 3 mois glissants (bases sur la
    date des chargements effectues dans l'application) du nombre de lignes
    recues et integrees, par TPA et au global ; et etat des contrats
    actifs/resilies par TPA et au global, a partir d'une configuration
    explicite de la colonne de statut par table (aucune supposition faite
    sur un nom de colonne).
    """

    def __init__(self, config: ConfigManager, log_cb=None, parent=None):
        super().__init__(parent)
        self.config = config
        self.log_cb = log_cb or (lambda level, msg: None)
        self.history = LoadHistoryManager()

        layout = QVBoxLayout(self)

        domain_row = QHBoxLayout()
        domain_row.addWidget(QLabel("Domaine :"))
        self.domain_combo = QComboBox()
        self.domain_combo.addItems([DOMAIN_LABELS.get(d, d) for d in DOMAINES])
        self.domain_combo.currentIndexChanged.connect(self._on_domain_changed)
        domain_row.addWidget(self.domain_combo)
        domain_row.addStretch()
        layout.addLayout(domain_row)

        # --- Section evolution 3 mois -------------------------------------
        evo_group = QGroupBox("📈  Evolution sur 3 mois — lignes recues / integrees")
        evo_layout = QVBoxLayout(evo_group)
        evo_info = QLabel(
            "Bascule sur les dates de chargement effectuees dans l'application. Cet historique "
            "demarre a l'introduction de cet ecran : les mois se remplissent progressivement au "
            "fil de vos chargements reels, pas de donnees retroactives disponibles."
        )
        evo_info.setWordWrap(True)
        evo_info.setStyleSheet("color:#5c6577; font-style:italic;")
        evo_layout.addWidget(evo_info)

        self.evo_table = QTableWidget(0, 0)
        self.evo_table.verticalHeader().setVisible(False)
        self.evo_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.evo_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        evo_layout.addWidget(self.evo_table)

        refresh_evo_btn = QPushButton("🔄 Actualiser")
        refresh_evo_btn.setObjectName("ghostBtn")
        refresh_evo_btn.clicked.connect(self._refresh_evolution_table)
        evo_btn_row = QHBoxLayout()
        evo_btn_row.addWidget(refresh_evo_btn)
        evo_btn_row.addStretch()
        evo_layout.addLayout(evo_btn_row)

        layout.addWidget(evo_group)

        self._refresh_evolution_table()

    # ------------------------------------------------------------------

    def _current_domain(self) -> str:
        return DOMAINES[self.domain_combo.currentIndex()]

    def _on_domain_changed(self):
        self._refresh_evolution_table()

    def refresh_after_external_change(self):
        """A appeler quand les sources ont pu changer ailleurs dans
        l'application (Chargement) : ne fait plus rien depuis le retrait de
        la section contrats actifs/resilies (V93), mais reste presente
        car appelee depuis main_window.py."""
        pass

    # --- Evolution 3 mois -----------------------------------------------

    def _refresh_evolution_table(self):
        """
        Tableau d'evolution sur 3 mois (V93) : orientation TPA en colonnes /
        periode en lignes (inverse de la disposition initiale, sur demande
        explicite de l'utilisateur) — une ligne par (mois, Recues/Integrees),
        une colonne par SOURCE (V105 : pays + type, pas seulement le type),
        plus une colonne TOTAL (global)."""
        domaine = self._current_domain()
        self.history.load()
        entries = self.history.entries_for_domain(domaine, n_months=3)
        mois = _last_n_months(3)

        # V105 : les colonnes distinguent chaque source REELLE (pays + type),
        # pas seulement le type — sans quoi les 4 variantes pays de SPB
        # (France/Italie/Espagne/Pologne) se retrouvaient toutes fondues
        # dans une seule colonne "SPB" agregee, rendant invisible l'activite
        # specifique de chaque pays. Meme principe que V104 : inclut aussi
        # les sources CONFIGUREES sans aucune activite recente (0 affiche
        # plutot que colonne absente), et memes libelles que l'ecran Fusion
        # (\"SPB (Italie)\") pour rester coherent dans toute l'application.
        sources_avec_historique = {(e.pays, e.type_tpa) for e in entries}
        sources_configurees = {(s.pays, s.type) for s in self.config.sources if s.domaine == domaine}
        toutes_sources = sorted(sources_avec_historique | sources_configurees)

        from core.config_manager import types_avec_plusieurs_pays, label_tpa
        types_multi_pays = types_avec_plusieurs_pays(self.config.sources, domaine)

        def _libelle(pays: str, type_tpa: str) -> str:
            return label_tpa(type_tpa, pays, types_multi_pays)

        headers = ["Periode"] + [_libelle(p, t) for p, t in toutes_sources] + ["TOTAL"]
        self.evo_table.setColumnCount(len(headers))
        self.evo_table.setHorizontalHeaderLabels(headers)
        self.evo_table.setRowCount(len(mois) * 2)

        for mois_idx, (y, m) in enumerate(mois):
            for metric_idx, (metric_label, metric_attr) in enumerate((("Recues", "nb_lignes_recues"), ("Integrees", "nb_lignes_integrees"))):
                row = mois_idx * 2 + metric_idx
                label_item = QTableWidgetItem(f"{_month_label(y, m)} — {metric_label}")
                font = label_item.font()
                font.setBold(True)
                label_item.setFont(font)
                self.evo_table.setItem(row, 0, label_item)

                total = 0
                for col, (pays, tpa) in enumerate(toutes_sources, start=1):
                    valeur = sum(
                        getattr(e, metric_attr) for e in entries
                        if e.type_tpa == tpa and e.pays == pays and e.date.year == y and e.date.month == m
                    )
                    total += valeur
                    self.evo_table.setItem(row, col, QTableWidgetItem(f"{valeur:,}".replace(",", " ")))

                total_item = QTableWidgetItem(f"{total:,}".replace(",", " "))
                f = total_item.font()
                f.setBold(True)
                total_item.setFont(f)
                self.evo_table.setItem(row, len(headers) - 1, total_item)

        self.evo_table.resizeColumnsToContents()

# Data Integrator — ICI Assurance (V90)

Application PySide6 pour charger les fichiers sources (SPB, Evy, Estaly, NEAT,
LAPI, GP...) vers leurs tables SQL Server respectives, gerer l'historique,
fusionner les tables de staging vers des tables consolidees, et notifier par
mail — organisee par domaine (Adhesion / Sinistre / FIC).

## Installation

```bash
py -m pip install -r requirements.txt
```

Pilote requis sur le poste : **Microsoft ODBC Driver 17 ou 18 for SQL Server**.

## Lancement

```bash
py main.py
```

## Nouveautes V5

- **Profils de connexion multiples** (bouton "Connexions") : Recette / Production / autres, un seul actif a la fois.
- **Sources par dossier** (retour V5) avec **comptage de lignes en direct** des la selection.
- **Gestion de l'historique** par source : case "Vider la table avant integration" (sinon append + ajout auto des colonnes manquantes).
- **Table cible en liste** (interroge les tables reelles de la base active) et **type/TPA en liste**.
- **Ecran Mail** ("Mails") : Nouveau message + Configuration SMTP par categorie (DSI, Clients/TPA, Finance, Direction).
- **Journal de logs complet en direct** ("Logs"), actif des le lancement, fichier `logs/app.log` en rotation.
- **Onglet Fusion** : matching de colonnes editable par domaine + execution vers une table consolidee.

## Utilisation

1. **Connexions** (barre d'outils) : gerer les profils Recette/Production, activer celui a utiliser, tester.
2. **Onglet Chargement > Sources** : ajouter une source (dossier, type, table, domaine, historique). Le nombre de lignes s'affiche des la selection du dossier.
3. Cocher les sources a charger (un ou plusieurs onglets de domaine), puis **Charger la selection**.
4. **Onglet Fusion** : definir le matching de colonnes par domaine, choisir la table de fusion cible, lancer la fusion.
5. **Mails** : configurer les comptes SMTP par categorie, envoyer des notifications manuelles.
6. **Logs** : suivre tout l'historique de l'application en direct, filtrable par niveau/texte.

## Structure du projet

```
data_loader_app/
├── main.py
├── requirements.txt
├── config/                        sources.json, mail_config.json, matching.json
├── core/
│   ├── config_manager.py          profils de connexion + sources
│   ├── db.py                      connexion SQL Server, listage des tables
│   ├── loader_engine.py           chargement (dossier, historique, comptage)
│   ├── mail_manager.py            comptes SMTP, envoi de mail
│   ├── log_manager.py             logging applicatif global
│   ├── merge_config.py            regles de matching par domaine
│   └── merge_engine.py            execution de la fusion
├── workers/load_worker.py         orchestration du chargement (QThread)
└── ui/                            fenetre principale, dialogues, mail, logs, fusion, theme
```

## Points a valider avec toi

- Nom exact de la 4e categorie mail (Direction ?) et destinataires par defaut.
- Regles de matching reelles par TPA/domaine pour la fusion.
- Deduplication/transformations necessaires lors de la fusion (V5 ne fait que renommer les colonnes).
- Chemins reels des dossiers sources et serveurs Recette/Production sur le poste.

## Prochaine etape

- Renforcement du moteur de fusion (deduplication, transformations).
- Envoi automatique de mails de notification en fin de chargement/fusion.


"""
load_worker.py
---------------
QThread qui exécute le chargement d'une ou plusieurs sources en séquence,
sans bloquer l'interface. Émet des signaux consommés par MainWindow :

    log(str level, str message)
    source_started(str source_id)
    source_progress(str source_id, int current, int total, str label)
    source_finished(str source_id, object result)   # SourceLoadResult
    all_finished()
    cancelled()
"""

from __future__ import annotations

from PySide6.QtCore import QThread, Signal

from core.config_manager import ConnectionProfile, SourceConfig
from core.db import build_engine
from core.loader_engine import LoaderSettings, LoadCancelled, load_source


class LoadWorker(QThread):
    log = Signal(str, str)
    source_started = Signal(str)
    source_progress = Signal(str, int, int, str)
    source_finished = Signal(str, object)
    all_finished = Signal()
    cancelled = Signal()

    def __init__(self, connection: ConnectionProfile, sources: list[SourceConfig], settings: LoaderSettings, parent=None):
        super().__init__(parent)
        self.connection = connection
        self.sources = sources
        self.settings = settings
        self._stop_requested = False
        from core.loaded_files_registry import LoadedFilesRegistry
        self.registry = LoadedFilesRegistry()
        from core.load_history import LoadHistoryManager
        self.history = LoadHistoryManager()
        from core.notification_settings import NotificationSettingsManager
        self.notification_settings = NotificationSettingsManager()
        from core.mail_manager import MailConfigManager
        self.mail_config = MailConfigManager()
        from core.thread_registry import register, unregister
        register(self)
        self.finished.connect(lambda: unregister(self))

    def request_stop(self):
        self._stop_requested = True

    def _stop_flag(self) -> bool:
        return self._stop_requested

    def run(self):
        try:
            self._run_impl()
        except Exception as e:
            # Filet de securite absolu : quoi qu'il arrive, le thread se
            # termine proprement (jamais d'exception non geree qui le
            # laisserait bloque ou detruit pendant qu'il tourne encore).
            self.log.emit("error", f"Erreur fatale inattendue dans le worker de chargement : {e}")
            self.all_finished.emit()

    def _run_impl(self):
        try:
            engine = build_engine(self.connection)
        except Exception as e:
            self.log.emit("error", f"Impossible de construire la connexion : {e}")
            self.all_finished.emit()
            return

        # V112, sur demande explicite de l'utilisateur : plus de mail DSI
        # envoye source par source pendant la boucle (jusqu'a 27 mails pour
        # un chargement complet des 3 domaines) — les resultats sont
        # collectes ici, pour un seul mail RECAPITULATIF envoye a la toute
        # fin de toutes les insertions.
        resultats_pour_mail: list = []

        for source in self.sources:
            if self._stop_requested:
                self.cancelled.emit()
                return

            self.source_started.emit(source.id)
            self.log.emit("info", f"=== Debut chargement : {source.pays} / {source.type} ({source.dossier_source}) -> {source.table} [historique {'conserve' if not source.vider_avant_integration else 'vide'}] ===")

            settings = LoaderSettings(
                chunk_size=self.settings.chunk_size,
                max_read_workers=self.settings.max_read_workers,
                max_retries=self.settings.max_retries,
                retry_delay=self.settings.retry_delay,
                header_mode=source.header_mode,
            )

            def log_cb(level, msg, _sid=source.id):
                self.log.emit(level, msg)

            def progress_cb(current, total, label, _sid=source.id):
                self.source_progress.emit(_sid, current, total, label)

            try:
                result = load_source(
                    engine=engine,
                    source_dir=source.dossier_source,
                    table=source.table,
                    settings=settings,
                    source_id=source.id,
                    vider_avant_integration=source.vider_avant_integration,
                    log_cb=log_cb,
                    progress_cb=progress_cb,
                    stop_flag=self._stop_flag,
                    registry=self.registry,
                    flux=source.type,
                )
                if result.total_rows_read > 0 or result.files_ok > 0:
                    # N'enregistre une entree d'historique que si le
                    # chargement a reellement traite quelque chose cette
                    # execution (pas de trace inutile si tous les fichiers
                    # etaient deja charges precedemment et ignores).
                    try:
                        self.history.record(
                            domaine=source.domaine, pays=source.pays, type_tpa=source.type,
                            table=source.table, nb_lignes_recues=result.total_rows_read,
                            nb_lignes_integrees=result.total_rows,
                        )
                    except Exception as e:
                        self.log.emit("warning", f"Impossible d'enregistrer l'historique statistique pour {source.table} : {e}")

                if self.notification_settings.settings.mail_dsi_apres_chargement and (result.total_rows_read > 0 or result.files_ok > 0 or result.errors):
                    # V112 : n'ajoute au recapitulatif final que si quelque
                    # chose a reellement ete traite ou a echoue cette
                    # execution (pas d'entree inutile pour une source
                    # entierement ignoree, deja a jour).
                    resultats_pour_mail.append((source.domaine, source.pays, source.type, source.table, result))
                self.source_finished.emit(source.id, result)
            except LoadCancelled:
                self.log.emit("warning", f"Chargement annule pendant : {source.table}")
                self.cancelled.emit()
                return
            except Exception as e:
                self.log.emit("error", f"Erreur inattendue sur {source.table} : {e}")

        if resultats_pour_mail:
            from core.mail_manager import send_dsi_load_report_recap
            send_dsi_load_report_recap(self.mail_config, resultats_pour_mail, lambda l, m: self.log.emit(l, m))

        self.all_finished.emit()

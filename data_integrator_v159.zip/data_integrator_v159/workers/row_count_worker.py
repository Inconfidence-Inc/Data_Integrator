"""
row_count_worker.py
--------------------
Calcule le nombre EXACT de lignes d'une source (dossier) en arriere-plan,
dans un QThread dedie, pour ne jamais bloquer l'interface pendant ce calcul
(qui necessite un parsing complet de chaque fichier — potentiellement long
sur un gros dossier).
"""

from __future__ import annotations

from PySide6.QtCore import QThread, Signal

from core.loader_engine import count_exact_rows


class RowCountWorker(QThread):
    finished_count = Signal(str, int, int)  # source_id, nb_fichiers, nb_lignes
    failed = Signal(str, str)               # source_id, message d'erreur
    progress = Signal(str, int, int, str)   # source_id, fichiers_traites, total, nom_fichier

    def __init__(self, source_id: str, folder: str, header_mode: str, parent=None):
        super().__init__(parent)
        self.source_id = source_id
        self.folder = folder
        self.header_mode = header_mode
        from core.thread_registry import register, unregister
        register(self)
        self.finished.connect(lambda: unregister(self))

    def run(self):
        try:
            def on_progress(traites, total, nom_fichier):
                self.progress.emit(self.source_id, traites, total, nom_fichier)
            nb_fichiers, nb_lignes = count_exact_rows(self.folder, header_mode=self.header_mode, progress_cb=on_progress)
            self.finished_count.emit(self.source_id, nb_fichiers, nb_lignes)
        except Exception as e:
            self.failed.emit(self.source_id, str(e))

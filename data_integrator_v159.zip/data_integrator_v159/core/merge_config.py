"""
merge_config.py
----------------
Gere le "matching" (mapping de colonnes source -> colonne cible) par domaine
et par TPA, utilise par l'onglet Fusion. Persistance dans config/matching.json.

Chaque ligne de matching relie :
    domaine (Adhesion/Sinistre/FIC) + type TPA + table source
    -> colonne_source (telle que presente dans la table de staging)
    -> colonne_cible  (nom de colonne dans la table de fusion consolidee)
"""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

from core.app_paths import resolve_config_path

DEFAULT_MATCHING_PATH = resolve_config_path("matching.json")


@dataclass
class MatchingRule:
    id: str
    domaine: str
    type_tpa: str
    table_source: str
    colonne_source: str
    colonne_cible: str

    @staticmethod
    def new(domaine: str, type_tpa: str, table_source: str, colonne_source: str, colonne_cible: str) -> "MatchingRule":
        return MatchingRule(
            id=uuid.uuid4().hex[:8], domaine=domaine, type_tpa=type_tpa,
            table_source=table_source, colonne_source=colonne_source, colonne_cible=colonne_cible,
        )


class MergeConfigManager:
    def __init__(self, path: Path | str = DEFAULT_MATCHING_PATH, log_cb=None):
        self.path = Path(path)
        self.log_cb = log_cb
        self.rules: list[MatchingRule] = []
        # table de fusion cible + option de vidage, par domaine
        self.target_tables: dict[str, str] = {}
        self.vider_avant_fusion: dict[str, bool] = {}
        # inclusion/exclusion d'une table TPA dans l'execution de la fusion
        # (V83) : cle "domaine|type_tpa|table_source" -> bool. Absent =
        # inclus par defaut (une table nouvellement ajoutee participe tant
        # qu'elle n'a pas ete explicitement decochee).
        self.tpa_inclus: dict[str, bool] = {}
        self.load()

    def load(self) -> None:
        # V141 : synchronise integralement ce fichier si une version plus
        # recente du mapping est fournie avec l'application — evite d'avoir
        # a supprimer manuellement le dossier de configuration a chaque
        # amelioration du mapping livree.
        from core.app_paths import sync_generated_config_if_newer
        sync_generated_config_if_newer(self.path, "matching.json", self.log_cb)

        if not self.path.exists():
            self.rules = []
            self.target_tables = {}
            self.vider_avant_fusion = {}
            self.tpa_inclus = {}
            return

        # Filet de securite (V99, corrige V100), meme principe que
        # ConfigManager : seule la cle "rules" est completee si vide,
        # jamais les autres cles de ce fichier (target_tables,
        # vider_avant_fusion, tpa_inclus), meme si ce fichier a deja un
        # vrai mapping personnalise pour certains de ces autres reglages.
        from core.app_paths import backfill_key_if_empty
        backfill_key_if_empty(self.path, "matching.json", "rules")

        with open(self.path, encoding="utf-8") as f:
            data = json.load(f)
        self.rules = [
            MatchingRule(
                id=r.get("id") or uuid.uuid4().hex[:8],
                domaine=r.get("domaine", ""),
                type_tpa=r.get("type_tpa", ""),
                table_source=r.get("table_source", ""),
                colonne_source=r.get("colonne_source", ""),
                colonne_cible=r.get("colonne_cible", ""),
            )
            for r in data.get("rules", [])
        ]
        self.target_tables = data.get("target_tables", {})
        self.vider_avant_fusion = data.get("vider_avant_fusion", {})
        self.tpa_inclus = data.get("tpa_inclus", {})
        self._version = data.get("_version", 0)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "rules": [asdict(r) for r in self.rules],
            "target_tables": self.target_tables,
            "vider_avant_fusion": self.vider_avant_fusion,
            "tpa_inclus": self.tpa_inclus,
            "_version": getattr(self, "_version", 0),  # V141 : preserve tel quel a la sauvegarde locale
        }
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def _tpa_key(self, domaine: str, type_tpa: str, table_source: str) -> str:
        return f"{domaine}|{type_tpa}|{table_source}"

    def is_tpa_inclus(self, domaine: str, type_tpa: str, table_source: str) -> bool:
        return self.tpa_inclus.get(self._tpa_key(domaine, type_tpa, table_source), True)

    def set_tpa_inclus(self, domaine: str, type_tpa: str, table_source: str, inclus: bool) -> None:
        self.tpa_inclus[self._tpa_key(domaine, type_tpa, table_source)] = inclus
        self.save()

    def rules_for_domain(self, domaine: str) -> list[MatchingRule]:
        return [r for r in self.rules if r.domaine == domaine]

    def add_rule(self, rule: MatchingRule, persist: bool = True) -> None:
        self.rules.append(rule)
        if persist:
            self.save()

    def update_rule(self, rule_id: str, persist: bool = True, **changes) -> None:
        for r in self.rules:
            if r.id == rule_id:
                for k, v in changes.items():
                    setattr(r, k, v)
                if persist:
                    self.save()
                return
        raise KeyError(f"Regle de matching introuvable : {rule_id}")

    def remove_rule(self, rule_id: str, persist: bool = True) -> None:
        self.rules = [r for r in self.rules if r.id != rule_id]
        if persist:
            self.save()

    def remove_table(self, domaine: str, type_tpa: str, table_source: str, persist: bool = True) -> None:
        """Retire du mapping TOUTES les regles d'une table donnee d'un
        coup (V117) — utilise notamment pour nettoyer une table orpheline
        qui ne correspond plus a aucune source reelle du Chargement."""
        self.rules = [
            r for r in self.rules
            if not (r.domaine == domaine and r.type_tpa == type_tpa and r.table_source == table_source)
        ]
        if persist:
            self.save()

    def get_target_table(self, domaine: str) -> str:
        return self.target_tables.get(domaine, f"dbo.SRC_{domaine}_Transformer_Contenu")

    def set_target_table(self, domaine: str, table: str) -> None:
        self.target_tables[domaine] = table
        self.save()

    def get_vider_avant_fusion(self, domaine: str) -> bool:
        return self.vider_avant_fusion.get(domaine, True)

    def set_vider_avant_fusion(self, domaine: str, vider: bool) -> None:
        self.vider_avant_fusion[domaine] = vider
        self.save()

"""
db.py
-----
Construction du moteur SQLAlchemy / pyodbc, test de connexion et listage des
tables reelles d'une base, a partir d'un ConnectionProfile.
"""

from __future__ import annotations

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError

from core.config_manager import ConnectionProfile


def build_engine(conn: ConnectionProfile) -> Engine:
    driver_url = conn.driver.replace(" ", "+")
    if conn.username:
        conn_str = (
            f"mssql+pyodbc://{conn.username}:{conn.password}@{conn.server}/{conn.database}"
            f"?driver={driver_url}&Encrypt=yes&TrustServerCertificate=yes"
        )
    else:
        conn_str = (
            f"mssql+pyodbc://@{conn.server}/{conn.database}"
            f"?driver={driver_url}&Trusted_Connection=yes&Encrypt=no"
        )
    return create_engine(
        conn_str,
        fast_executemany=True,
        pool_size=5,
        max_overflow=10,
        pool_pre_ping=True,
        pool_recycle=1800,
    )


def test_connection(conn: ConnectionProfile) -> tuple[bool, str]:
    """Retourne (succes, message)."""
    try:
        engine = build_engine(conn)
        with engine.connect() as c:
            c.execute(text("SELECT 1"))
        return True, "Connexion reussie."
    except SQLAlchemyError as e:
        return False, str(e)
    except Exception as e:  # pilote ODBC manquant, etc.
        return False, str(e)


def list_tables(conn: ConnectionProfile) -> list[str]:
    """
    Retourne la liste des tables existantes ('schema.table') de la base
    ciblee par le profil de connexion. Leve une exception si la connexion
    echoue : a l'appelant de gerer (ex: repli sur saisie libre).
    """
    engine = build_engine(conn)
    query = text(
        "SELECT TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
        "WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_SCHEMA, TABLE_NAME"
    )
    with engine.connect() as c:
        rows = c.execute(query).fetchall()
    return [f"{schema}.{name}" for schema, name in rows]


def get_existing_columns(engine: Engine, schema: str, table_name: str) -> list[str] | None:
    """Retourne la liste des colonnes d'une table existante, ou None si la table n'existe pas."""
    query = text(
        "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
        "WHERE TABLE_SCHEMA = :schema AND TABLE_NAME = :table "
        "ORDER BY ORDINAL_POSITION"
    )
    with engine.connect() as c:
        rows = c.execute(query, {"schema": schema, "table": table_name}).fetchall()
    if not rows:
        return None
    return [r[0] for r in rows]


def list_columns(conn: ConnectionProfile, table: str) -> list[str]:
    """
    Raccourci pratique : liste les colonnes d'une table ('schema.table') a
    partir d'un profil de connexion directement (construit son propre
    moteur). Retourne une liste vide si la table n'existe pas ou est vide.
    Utilise par l'ecran de mapping assiste (Fusion) pour proposer les vraies
    colonnes chargees dans les tables cibles.
    """
    schema, table_name = table.split(".", 1) if "." in table else ("dbo", table)
    engine = build_engine(conn)
    return get_existing_columns(engine, schema, table_name) or []


def count_contracts_by_status(
    conn: ConnectionProfile, table: str, colonne_statut: str,
    valeurs_actif: list[str], valeurs_resilie: list[str],
) -> tuple[int, int]:
    """
    Compte, dans la table cible donnee, le nombre de lignes dont la colonne
    de statut correspond aux valeurs "actif" et "resilie" configurees (V59,
    ecran statistique). Comparaison insensible a la casse et aux espaces en
    trop, pour tolerer de petites variations (\" Actif \" vs \"actif\").
    Retourne (nb_actifs, nb_resilies). Leve une exception si la table ou la
    colonne n'existe pas : a l'appelant de gerer proprement (config
    probablement obsolete ou table renommee).
    """
    schema, table_name = table.split(".", 1) if "." in table else ("dbo", table)
    engine = build_engine(conn)

    def _count_for(valeurs: list[str]) -> int:
        if not valeurs:
            return 0
        placeholders = {f"v{i}": v.strip().lower() for i, v in enumerate(valeurs)}
        in_clause = ", ".join(f":{k}" for k in placeholders)
        query = text(
            f"SELECT COUNT(*) FROM [{schema}].[{table_name}] "
            f"WHERE LOWER(LTRIM(RTRIM(CAST([{colonne_statut}] AS NVARCHAR(200))))) IN ({in_clause})"
        )
        with engine.connect() as c:
            return c.execute(query, placeholders).scalar() or 0

    return _count_for(valeurs_actif), _count_for(valeurs_resilie)

"""
auth_db.py
----------
Acces a la base OUTILS (authentification centralisee, V148) : construction
du moteur de connexion, test, verification d'identifiants (USERS_PYTHON) et
historisation des evenements de connexion (USERS_PYTHON_HISTO).

Format du mot de passe en base : hash bcrypt ("$2b$12$...", cout 12),
deja utilise par les applications existantes (ex: Reco Compta) qui
partagent cette meme base de comptes — verifie ici a l'identique, jamais
un autre algorithme, pour rester compatible avec les comptes deja crees.

Format de la colonne USERS_PYTHON.applications : liste de paires
"CODE_APPLICATION:ROLE" separees par des points-virgules (ex:
"ARGOS:Administrateur;FILE_MANAGER:Lecteur"). Un utilisateur n'est
autorise a se connecter a Data Integrator que si "DATA_INTEGRATOR"
(ou le code_application configure) figure dans cette liste.
"""

from __future__ import annotations

import getpass
import socket
from dataclasses import dataclass
from datetime import datetime
from urllib.parse import quote_plus

import bcrypt
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError

from core.auth_config import AuthConfig
from core.log_manager import get_logger


def build_auth_engine(cfg: AuthConfig) -> Engine:
    driver_url = cfg.driver.replace(" ", "+")
    server_part = f"{cfg.server},{cfg.port}" if cfg.port else cfg.server
    encrypt = "yes" if cfg.encrypt else "no"
    trust = "yes" if cfg.trust_server_certificate else "no"
    if cfg.username:
        conn_str = (
            f"mssql+pyodbc://{quote_plus(cfg.username)}:{quote_plus(cfg.password)}"
            f"@{server_part}/{quote_plus(cfg.database)}"
            f"?driver={driver_url}&Encrypt={encrypt}&TrustServerCertificate={trust}"
        )
    else:
        conn_str = (
            f"mssql+pyodbc://@{server_part}/{quote_plus(cfg.database)}"
            f"?driver={driver_url}&Trusted_Connection=yes&Encrypt={encrypt}&TrustServerCertificate={trust}"
        )
    return create_engine(conn_str, pool_pre_ping=True, pool_recycle=1800)


def test_auth_connection(cfg: AuthConfig) -> tuple[bool, str]:
    """Teste la connexion a OUTILS et verifie que les deux tables
    configurees existent reellement (au-dela du simple SELECT 1)."""
    try:
        engine = build_auth_engine(cfg)
        with engine.connect() as c:
            c.execute(text("SELECT 1"))
            for table in (cfg.table_users, cfg.table_histo):
                row = c.execute(
                    text(
                        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES "
                        "WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = :t"
                    ),
                    {"t": table},
                ).scalar()
                if not row:
                    return False, f"Connexion reussie, mais la table 'dbo.{table}' est introuvable."
        return True, "Connexion reussie. Tables USERS_PYTHON / USERS_PYTHON_HISTO trouvees."
    except SQLAlchemyError as e:
        return False, str(e)
    except Exception as e:  # pilote ODBC manquant, etc.
        return False, str(e)


def parse_applications(raw: str | None) -> dict[str, str]:
    """Decoupe la colonne 'applications' (ex: 'ARGOS:Administrateur;
    FILE_MANAGER:Lecteur') en dict {CODE: ROLE}, cle normalisee en
    majuscules pour une comparaison insensible a la casse."""
    result: dict[str, str] = {}
    for part in (raw or "").split(";"):
        part = part.strip()
        if not part:
            continue
        if ":" in part:
            code, role = part.split(":", 1)
            result[code.strip().upper()] = role.strip()
        else:
            result[part.upper()] = ""
    return result


@dataclass
class AuthenticatedUser:
    id: int
    login: str
    nom: str
    prenom: str
    email: str
    role: str
    must_change_password: bool


@dataclass
class AuthResult:
    success: bool
    message: str = ""
    user: AuthenticatedUser | None = None
    # Distingue une erreur de connexion reseau/serveur (ne doit pas etre
    # interpretee comme "identifiants invalides") d'un echec d'identifiants.
    connection_error: bool = False


def _poste_et_utilisateur_systeme() -> tuple[str, str]:
    try:
        poste = socket.gethostname()
    except Exception:
        poste = ""
    try:
        utilisateur_systeme = getpass.getuser()
    except Exception:
        utilisateur_systeme = ""
    return poste, utilisateur_systeme


def log_event(cfg: AuthConfig, login: str, evenement: str, detail: str = "") -> None:
    """Historise un evenement dans USERS_PYTHON_HISTO. Best-effort : une
    panne d'ecriture de l'historique ne doit jamais bloquer le flux de
    connexion (meme philosophie que le reste de l'application : ne jamais
    faire echouer une action metier a cause d'un enregistrement annexe)."""
    try:
        poste, utilisateur_systeme = _poste_et_utilisateur_systeme()
        engine = build_auth_engine(cfg)
        with engine.begin() as c:
            c.execute(
                text(
                    f"INSERT INTO [dbo].[{cfg.table_histo}] "
                    "(login, application, evenement, horodatage, poste, utilisateur_systeme, detail) "
                    "VALUES (:login, :application, :evenement, :horodatage, :poste, :utilisateur_systeme, :detail)"
                ),
                {
                    "login": login,
                    "application": cfg.code_application,
                    "evenement": evenement,
                    "horodatage": datetime.now(),
                    "poste": poste,
                    "utilisateur_systeme": utilisateur_systeme,
                    "detail": detail,
                },
            )
    except Exception as e:
        try:
            get_logger().error("Echec d'ecriture dans %s (evenement=%s, login=%s) : %s", cfg.table_histo, evenement, login, e)
        except Exception:
            pass


def authenticate(cfg: AuthConfig, login: str, password: str) -> AuthResult:
    """Verifie les identifiants aupres de USERS_PYTHON et consigne le
    resultat dans USERS_PYTHON_HISTO. Message volontairement generique en
    cas d'echec (identifiant inconnu ou mot de passe incorrect rendent le
    meme message) pour ne pas reveler si un login existe."""
    login = (login or "").strip()
    if not login or not password:
        return AuthResult(success=False, message="Identifiant et mot de passe requis.")

    try:
        engine = build_auth_engine(cfg)
        with engine.connect() as c:
            row = c.execute(
                text(
                    f"SELECT [id], [login], [mot_de_passe_hash], [nom], [prenom], [email], "
                    f"[applications], [actif], [doit_changer_mdp] "
                    f"FROM [dbo].[{cfg.table_users}] WHERE [login] = :login"
                ),
                {"login": login},
            ).mappings().first()
    except SQLAlchemyError as e:
        return AuthResult(success=False, message=f"Impossible de contacter le serveur d'authentification : {e}", connection_error=True)
    except Exception as e:
        return AuthResult(success=False, message=f"Impossible de contacter le serveur d'authentification : {e}", connection_error=True)

    if row is None:
        log_event(cfg, login, "CONNEXION_ECHEC", "identifiant ou mot de passe incorrect")
        return AuthResult(success=False, message="Identifiant ou mot de passe incorrect.")

    if not row["actif"]:
        log_event(cfg, login, "CONNEXION_ECHEC", "compte desactive")
        return AuthResult(success=False, message="Ce compte est desactive. Contactez un administrateur.")

    stored_hash = row["mot_de_passe_hash"] or ""
    try:
        valid = bcrypt.checkpw(password.encode("utf-8"), stored_hash.encode("utf-8"))
    except Exception:
        valid = False
    if not valid:
        log_event(cfg, login, "CONNEXION_ECHEC", "identifiant ou mot de passe incorrect")
        return AuthResult(success=False, message="Identifiant ou mot de passe incorrect.")

    applications = parse_applications(row["applications"])
    code = cfg.code_application.strip().upper()
    if code not in applications:
        log_event(cfg, login, "CONNEXION_ECHEC", f"non autorise pour l'application {cfg.code_application}")
        return AuthResult(success=False, message="Vous n'etes pas autorise a utiliser cette application.")

    try:
        engine = build_auth_engine(cfg)
        with engine.begin() as c:
            c.execute(
                text(f"UPDATE [dbo].[{cfg.table_users}] SET [derniere_connexion] = :now WHERE [id] = :id"),
                {"now": datetime.now(), "id": row["id"]},
            )
    except Exception as e:
        try:
            get_logger().error("Echec de mise a jour de derniere_connexion pour '%s' : %s", login, e)
        except Exception:
            pass

    log_event(cfg, login, "CONNEXION_REUSSIE")

    user = AuthenticatedUser(
        id=row["id"],
        login=row["login"],
        nom=row["nom"] or "",
        prenom=row["prenom"] or "",
        email=row["email"] or "",
        role=applications.get(code, ""),
        must_change_password=bool(row["doit_changer_mdp"]),
    )
    return AuthResult(success=True, message="Connexion reussie.", user=user)


def change_password(cfg: AuthConfig, user_id: int, new_password: str) -> tuple[bool, str]:
    """Change le mot de passe d'un utilisateur (hash bcrypt, cout 12,
    identique au format deja utilise en base) et leve le drapeau
    doit_changer_mdp."""
    try:
        new_hash = bcrypt.hashpw(new_password.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")
        engine = build_auth_engine(cfg)
        with engine.begin() as c:
            c.execute(
                text(
                    f"UPDATE [dbo].[{cfg.table_users}] "
                    "SET [mot_de_passe_hash] = :h, [doit_changer_mdp] = 0, [date_modification] = :now "
                    "WHERE [id] = :id"
                ),
                {"h": new_hash, "now": datetime.now(), "id": user_id},
            )
        return True, "Mot de passe modifie."
    except Exception as e:
        return False, str(e)

"""
auth_config.py
---------------
Configuration de l'authentification centralisee (V148) : connexion a la base
OUTILS (serveur Azure partage entre plusieurs applications internes, dont
Reco Compta), qui porte les comptes utilisateurs (table USERS_PYTHON) et
l'historique de connexion (table USERS_PYTHON_HISTO).

Cette base est volontairement DISTINCTE de la base metier (TECH_BI) : elle
ne depend d'aucun environnement Local/Recette/Production de l'application,
c'est une base de comptes partagee, unique quel que soit l'environnement
metier choisi.

Stockee comme les profils de connexion metier (meme emplacement stable,
cf. app_paths.py), dans un fichier dedie auth_config.json.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from core.app_paths import resolve_config_path

DEFAULT_AUTH_CONFIG_PATH = resolve_config_path("auth_config.json")

# Code identifiant cette application aupres de la base OUTILS partagee —
# doit correspondre a une entree "DATA_INTEGRATOR:<role>" dans la colonne
# USERS_PYTHON.applications pour qu'un utilisateur soit autorise a se
# connecter ici (meme principe que les codes existants ARGOS, FILE_MANAGER).
DEFAULT_CODE_APPLICATION = "DATA_INTEGRATOR"


@dataclass
class AuthConfig:
    server: str = ""
    port: int = 1433
    database: str = "OUTILS"
    auth_mode: str = "sql"  # "sql" = connexion SQL (utilisateur/mot de passe)
    username: str = ""
    password: str = ""
    driver: str = "ODBC Driver 18 for SQL Server"
    encrypt: bool = True
    trust_server_certificate: bool = True
    table_users: str = "USERS_PYTHON"
    table_histo: str = "USERS_PYTHON_HISTO"
    code_application: str = DEFAULT_CODE_APPLICATION
    # Authentification centralisee activee ou non : tant que False (reglage
    # par defaut), l'application se lance normalement sans ecran de
    # connexion, exactement comme avant l'ajout de cette fonctionnalite —
    # le temps qu'un administrateur configure et teste la connexion a OUTILS.
    active: bool = False


class AuthConfigManager:
    """Charge/sauvegarde la configuration d'authentification centralisee."""

    def __init__(self, path: Path | str = DEFAULT_AUTH_CONFIG_PATH):
        self.path = Path(path)
        self.config: AuthConfig = AuthConfig()
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            self.config = AuthConfig()
            return
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            self.config = AuthConfig()
            return
        defaults = AuthConfig()
        self.config = AuthConfig(
            server=data.get("server", defaults.server),
            port=data.get("port", defaults.port),
            database=data.get("database", defaults.database),
            auth_mode=data.get("auth_mode", defaults.auth_mode),
            username=data.get("username", defaults.username),
            password=data.get("password", defaults.password),
            driver=data.get("driver", defaults.driver),
            encrypt=data.get("encrypt", defaults.encrypt),
            trust_server_certificate=data.get("trust_server_certificate", defaults.trust_server_certificate),
            table_users=data.get("table_users", defaults.table_users),
            table_histo=data.get("table_histo", defaults.table_histo),
            code_application=data.get("code_application", defaults.code_application),
            active=data.get("active", defaults.active),
        )

    def save(self, config: AuthConfig | None = None) -> None:
        if config is not None:
            self.config = config
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(asdict(self.config), f, ensure_ascii=False, indent=2)

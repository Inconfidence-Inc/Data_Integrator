"""
thread_registry.py
--------------------
Registre global des QThread actifs dans l'application (LoadWorker,
RowCountWorker, ...). Chaque worker s'enregistre a sa creation et se
desenregistre automatiquement a la fin de son execution.

Sert de filet de securite final, appele juste avant la fermeture reelle de
l'application (signal QApplication.aboutToQuit) : quel que soit le chemin
qui a mene a la fermeture (fenetre principale fermee, dialogue ferme,
Ctrl+C, etc.), on s'assure qu'aucun thread n'est detruit alors qu'il tourne
encore — c'est ce qui provoque l'avertissement/plantage
"QThread: Destroyed while thread is still running".

Complementaire (pas un remplacement) des gestions de fermeture propres deja
en place au niveau de chaque fenetre/dialogue, qui offrent une meilleure
experience utilisateur (confirmation, message clair) quand c'est possible.
"""

from __future__ import annotations

_active_threads: list = []


def register(thread) -> None:
    if thread not in _active_threads:
        _active_threads.append(thread)


def unregister(thread) -> None:
    if thread in _active_threads:
        _active_threads.remove(thread)


def wait_for_all(timeout_ms: int = 5000) -> None:
    """
    A appeler juste avant la fermeture reelle de l'application. Attend que
    chaque thread encore actif se termine (jusqu'a timeout_ms), et force
    l'arret en dernier recours si necessaire — jamais de thread laisse
    tourner au moment ou l'application se ferme.
    """
    for thread in list(_active_threads):
        try:
            if thread.isRunning():
                request_stop = getattr(thread, "request_stop", None)
                if callable(request_stop):
                    request_stop()
                if not thread.wait(timeout_ms):
                    thread.terminate()
                    thread.wait(1000)
        except RuntimeError:
            pass  # l'objet Qt sous-jacent a deja ete detruit, rien a faire
        finally:
            unregister(thread)

"""
log_manager.py
---------------
Configure le logging Python de l'ensemble de l'application des le lancement
(main.py doit appeler setup_logging() en tout premier). Deux sorties :
    - fichier rotatif logs/app.log (trace complete, persistante)
    - un handler Qt (QtLogBridge) qui emet un signal pour alimenter la fenetre
      de logs en direct (console live), sans dependre de PySide6 dans ce module.
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_FILE = LOG_DIR / "app.log"

APP_LOGGER_NAME = "chargeur_donnees"


class CallbackLogHandler(logging.Handler):
    """Handler generique qui relaie chaque log vers une fonction callback
    (level, message). Le pont vers Qt (signal thread-safe) est fait cote UI."""

    def __init__(self, callback):
        super().__init__()
        self._callback = callback

    def emit(self, record: logging.LogRecord) -> None:
        try:
            level = record.levelname.lower()
            level = {"warning": "warning", "error": "error", "critical": "error", "info": "info", "debug": "debug"}.get(level, "info")
            message = self.format(record)
            self._callback(level, message)
        except Exception:
            pass  # un handler de logging ne doit jamais lever


def setup_logging() -> logging.Logger:
    """A appeler une seule fois, au tout debut de main.py."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger(APP_LOGGER_NAME)
    if logger.handlers:
        return logger  # deja initialise

    logger.setLevel(logging.DEBUG)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=5_000_000, backupCount=5, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-8s  %(name)s  %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    logger.addHandler(file_handler)

    logger.info("=== Demarrage de l'application : logging initialise (%s) ===", LOG_FILE)
    return logger


def get_logger() -> logging.Logger:
    return logging.getLogger(APP_LOGGER_NAME)


def default_log_cb(level: str, message: str) -> None:
    """
    Callback de log de secours : a utiliser partout ou un composant accepte
    un log_cb optionnel. Garantit qu'un message n'est JAMAIS ignore
    silencieusement, meme si l'appelant n'a pas fourni de callback dedie
    (ex: widget instancie hors du contexte normal de la fenetre principale) —
    il finit toujours au moins dans le journal applicatif (fichier + console
    live si la fenetre de logs est ouverte).
    """
    logger = get_logger()
    {"info": logger.info, "success": logger.info, "warning": logger.warning,
     "error": logger.error, "debug": logger.debug}.get(level, logger.info)(message)


def attach_callback_handler(callback) -> CallbackLogHandler:
    """Ajoute un handler qui relaie chaque log vers callback(level, message)."""
    handler = CallbackLogHandler(callback)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(message)s"))
    get_logger().addHandler(handler)
    return handler

"""
loaded_files_registry.py
--------------------------
Registre persistant des fichiers deja charges avec succes, par source.
Permet d'eviter de retraiter (relire + reinserer) des fichiers deja integres
lors d'un chargement precedent, ce qui devient critique pour des tables
volumineuses ou des dossiers qui grossissent avec le temps.

Principe :
    - Un fichier est identifie par son NOM + sa TAILLE + sa DATE DE
      MODIFICATION. Si ces trois elements sont identiques a ce qui est
      enregistre, le fichier est considere comme deja charge et est ignore.
    - Si un fichier de meme nom a une taille ou une date differente, il est
      considere comme MODIFIE : il est retraite (par prudence, on ne veut
      jamais ignorer une donnee potentiellement nouvelle), mais comme
      l'application ne fait pas de suppression ligne par ligne, ses
      anciennes lignes (si deja chargees) resteront presentes en base en
      mode "historique conserve" — a signaler clairement dans les logs.
    - Ce suivi n'a de sens qu'en mode "historique conserve"
      (vider_avant_integration=False) : en mode "vider", la table est
      recreee a neuf a chaque fois, donc tous les fichiers doivent de toute
      facon etre retraites.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from core.app_paths import resolve_config_path

DEFAULT_REGISTRY_PATH = resolve_config_path("loaded_files.json")


class LoadedFilesRegistry:
    def __init__(self, path: Path | str = DEFAULT_REGISTRY_PATH):
        self.path = Path(path)
        self.data: dict[str, dict[str, dict]] = {}
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            with open(self.path, encoding="utf-8") as f:
                self.data = json.load(f)
        except (json.JSONDecodeError, OSError):
            self.data = {}

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _signature(filepath: Path) -> tuple[int, float]:
        stat = filepath.stat()
        return stat.st_size, stat.st_mtime

    def is_already_loaded(self, source_id: str, filepath: Path) -> bool:
        entry = self.data.get(source_id, {}).get(filepath.name)
        if entry is None:
            return False
        try:
            taille, mtime = self._signature(filepath)
        except OSError:
            return False
        return entry.get("taille") == taille and entry.get("modifie_le") == mtime

    def was_seen_with_different_signature(self, source_id: str, filepath: Path) -> bool:
        """True si ce fichier a deja ete charge AUPARAVANT mais avec une
        taille/date differente (fichier modifie depuis) — sert a avertir
        d'un risque de doublon en mode historique conserve."""
        entry = self.data.get(source_id, {}).get(filepath.name)
        if entry is None:
            return False
        try:
            taille, mtime = self._signature(filepath)
        except OSError:
            return False
        return not (entry.get("taille") == taille and entry.get("modifie_le") == mtime)

    def mark_loaded(self, source_id: str, filepath: Path, nb_lignes: int) -> None:
        try:
            taille, mtime = self._signature(filepath)
        except OSError:
            return
        self.data.setdefault(source_id, {})[filepath.name] = {
            "taille": taille,
            "modifie_le": mtime,
            "lignes": nb_lignes,
        }
        self.save()

    def reset_source(self, source_id: str) -> None:
        """Efface le suivi pour une source : au prochain chargement, tous
        ses fichiers seront retraites, meme ceux deja vus."""
        if source_id in self.data:
            del self.data[source_id]
            self.save()

    def count_loaded(self, source_id: str) -> int:
        return len(self.data.get(source_id, {}))

"""
mail_manager.py
----------------
Configuration et envoi de mails via SMTP, avec un compte distinct par
categorie (ex: DSI, Clients / TPA, Finance, Direction), conformement a
l'ecran de parametrage mail. Persistance dans config/mail_config.json.
"""

from __future__ import annotations

import json
import smtplib
import ssl
import uuid
from dataclasses import asdict, dataclass, field
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

from core.app_paths import resolve_config_path

DEFAULT_MAIL_CONFIG_PATH = resolve_config_path("mail_config.json")

# Categories par defaut (le 4e nom exact reste a confirmer avec l'utilisateur ;
# facilement renommable/ajoutable depuis l'IHM)
DEFAULT_CATEGORIES = ["DSI", "Clients / TPA", "Finance", "Direction"]


def _split_addresses(raw: str) -> list[str]:
    import re
    return [a.strip() for a in re.split(r"[;,]", raw) if a.strip()]


@dataclass
class MailAccountConfig:
    id: str
    categorie: str
    smtp_server: str = "smtp.office365.com"
    port: int = 587
    identifiant: str = ""
    mot_de_passe: str = ""
    expediteur: str = ""
    tls: bool = True
    destinataires: list[str] = field(default_factory=list)
    cc: list[str] = field(default_factory=list)
    description: str = ""

    @staticmethod
    def new(categorie: str) -> "MailAccountConfig":
        return MailAccountConfig(id=uuid.uuid4().hex[:8], categorie=categorie)


class MailConfigManager:
    def __init__(self, path: Path | str = DEFAULT_MAIL_CONFIG_PATH):
        self.path = Path(path)
        self.accounts: list[MailAccountConfig] = []
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            self.accounts = [MailAccountConfig.new(cat) for cat in DEFAULT_CATEGORIES]
            self.save()
            return
        with open(self.path, encoding="utf-8") as f:
            data = json.load(f)
        self.accounts = [
            MailAccountConfig(
                id=a.get("id") or uuid.uuid4().hex[:8],
                categorie=a.get("categorie", ""),
                smtp_server=a.get("smtp_server", "smtp.office365.com"),
                port=a.get("port", 587),
                identifiant=a.get("identifiant", ""),
                mot_de_passe=a.get("mot_de_passe", ""),
                expediteur=a.get("expediteur", ""),
                tls=a.get("tls", True),
                destinataires=a.get("destinataires", []),
                cc=a.get("cc", []),
                description=a.get("description", ""),
            )
            for a in data.get("accounts", [])
        ]
        if not self.accounts:
            self.accounts = [MailAccountConfig.new(cat) for cat in DEFAULT_CATEGORIES]

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {"accounts": [asdict(a) for a in self.accounts]}
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def get_account(self, categorie: str) -> MailAccountConfig | None:
        return next((a for a in self.accounts if a.categorie == categorie), None)

    def update_account(self, account_id: str, **changes) -> None:
        for a in self.accounts:
            if a.id == account_id:
                for k, v in changes.items():
                    setattr(a, k, v)
                self.save()
                return
        raise KeyError(f"Compte mail introuvable : {account_id}")

    def add_category(self, categorie: str) -> MailAccountConfig:
        account = MailAccountConfig.new(categorie)
        self.accounts.append(account)
        self.save()
        return account

    def remove_account(self, account_id: str) -> None:
        self.accounts = [a for a in self.accounts if a.id != account_id]
        self.save()


def test_smtp(account: MailAccountConfig) -> tuple[bool, str]:
    """Teste la connexion/authentification SMTP sans envoyer de mail."""
    try:
        with smtplib.SMTP(account.smtp_server, account.port, timeout=10) as server:
            if account.tls:
                server.starttls(context=ssl.create_default_context())
            if account.identifiant:
                server.login(account.identifiant, account.mot_de_passe)
        return True, "Connexion SMTP reussie."
    except Exception as e:
        return False, str(e)


def send_mail(
    account: MailAccountConfig,
    subject: str,
    body: str,
    destinataires_override: str | None = None,
    cc_override: str | None = None,
) -> tuple[bool, str]:
    """Envoie un mail via le compte SMTP fourni. Retourne (succes, message)."""
    destinataires = _split_addresses(destinataires_override) if destinataires_override is not None else account.destinataires
    cc = _split_addresses(cc_override) if cc_override is not None else account.cc

    if not destinataires:
        return False, "Aucun destinataire principal renseigne."

    msg = MIMEMultipart()
    msg["From"] = account.expediteur or account.identifiant
    msg["To"] = ", ".join(destinataires)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    try:
        with smtplib.SMTP(account.smtp_server, account.port, timeout=15) as server:
            if account.tls:
                server.starttls(context=ssl.create_default_context())
            if account.identifiant:
                server.login(account.identifiant, account.mot_de_passe)
            server.sendmail(msg["From"], destinataires + cc, msg.as_string())
        return True, "Mail envoye avec succes."
    except Exception as e:
        return False, str(e)


def send_dsi_load_report(
    mail_config: "MailConfigManager", source_pays: str, source_type: str, domaine: str,
    table: str, result, log_cb=None,
) -> None:
    """
    Envoie automatiquement au compte DSI un mail de rapport a l'issue du
    chargement d'un TPA (V71), avec le detail du traitement (fichiers,
    lignes, duree, erreurs eventuelles). Jamais bloquant : un echec d'envoi
    est journalise en avertissement, sans jamais faire echouer le
    chargement reel des donnees (deja termine a ce stade).
    """
    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    dsi_account = next((a for a in mail_config.accounts if a.categorie == "DSI"), None)
    if not dsi_account or not dsi_account.destinataires:
        log("warning", "Mail DSI non envoye : aucun compte DSI configure ou aucun destinataire renseigne (voir l'ecran Mails).")
        return

    statut = "✅ OK" if result.success else "⚠ TERMINE AVEC ERREUR(S)"
    subject = f"[Data Integrator] {statut} — {domaine} / {source_pays} {source_type}"

    lignes_rapport = [
        f"Rapport de chargement automatique — {domaine} / {source_pays} {source_type}",
        f"Table cible : {table}",
        "",
        f"Statut : {statut}",
        f"Fichiers traites avec succes : {result.files_ok} / {result.total_files}",
        f"Lignes lues dans les fichiers sources : {result.total_rows_read:,}".replace(",", " "),
        f"Lignes integrees en base : {result.total_rows:,}".replace(",", " "),
        f"Duree du traitement : {result.elapsed_seconds:.1f} secondes",
    ]
    if result.errors:
        lignes_rapport.append("")
        lignes_rapport.append(f"Erreur(s) rencontree(s) ({len(result.errors)}) :")
        for fichier, message in result.errors[:20]:
            lignes_rapport.append(f"  - {fichier} : {message}")
        if len(result.errors) > 20:
            lignes_rapport.append(f"  ... et {len(result.errors) - 20} autre(s) erreur(s) (voir le journal complet dans l'application).")
    lignes_rapport.append("")
    lignes_rapport.append("Ce mail a ete genere automatiquement par Data Integrator (ICI Assurance).")
    body = "\n".join(lignes_rapport)

    try:
        ok, message = send_mail(dsi_account, subject, body)
        if ok:
            log("success", f"Mail DSI envoye pour {source_pays} / {source_type}.")
        else:
            log("warning", f"Echec de l'envoi du mail DSI pour {source_pays} / {source_type} : {message}")
    except Exception as e:
        log("warning", f"Echec de l'envoi du mail DSI pour {source_pays} / {source_type} : {e}")


def send_dsi_load_report_recap(mail_config: "MailConfigManager", resultats: list, log_cb=None) -> None:
    """
    V112, sur demande explicite de l'utilisateur : un seul mail DSI
    RECAPITULATIF envoye a la toute fin d'un chargement (au lieu d'un mail
    separe par source individuelle, jusqu'a 27 mails pour un chargement
    complet des 3 domaines) — resume chaque source traitee, avec un total
    global en tete. `resultats` est une liste de tuples
    (domaine, pays, type_tpa, table, result). Jamais bloquant : un echec
    d'envoi est journalise en avertissement, sans jamais faire echouer le
    chargement reel des donnees (deja termine a ce stade)."""
    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    if not resultats:
        return

    dsi_account = next((a for a in mail_config.accounts if a.categorie == "DSI"), None)
    if not dsi_account or not dsi_account.destinataires:
        log("warning", "Mail recapitulatif DSI non envoye : aucun compte DSI configure ou aucun destinataire renseigne (voir l'ecran Mails).")
        return

    total_fichiers_ok = sum(r.files_ok for _, _, _, _, r in resultats)
    total_fichiers = sum(r.total_files for _, _, _, _, r in resultats)
    total_lignes_lues = sum(r.total_rows_read for _, _, _, _, r in resultats)
    total_lignes_integrees = sum(r.total_rows for _, _, _, _, r in resultats)
    total_duree = sum(r.elapsed_seconds for _, _, _, _, r in resultats)
    sources_en_erreur = [(d, p, t, tb, r) for d, p, t, tb, r in resultats if not r.success]

    statut_global = "✅ OK" if not sources_en_erreur else f"⚠ {len(sources_en_erreur)} SOURCE(S) EN ERREUR"
    subject = f"[Data Integrator] {statut_global} — Rapport recapitulatif de chargement ({len(resultats)} source(s))"

    lignes_rapport = [
        f"Rapport recapitulatif de chargement automatique — {len(resultats)} source(s) traitee(s)",
        "",
        f"Statut global : {statut_global}",
        f"Fichiers traites avec succes (total) : {total_fichiers_ok} / {total_fichiers}",
        f"Lignes lues dans les fichiers sources (total) : {total_lignes_lues:,}".replace(",", " "),
        f"Lignes integrees en base (total) : {total_lignes_integrees:,}".replace(",", " "),
        f"Duree totale du traitement : {total_duree:.1f} secondes",
        "",
        "Detail par source :",
    ]
    for domaine, pays, type_tpa, table, r in resultats:
        statut_source = "OK" if r.success else "ERREUR"
        nb_lignes_fmt = f"{r.total_rows:,}".replace(",", " ")
        lignes_rapport.append(
            f"  - [{statut_source}] {domaine} / {pays} {type_tpa} ({table}) : "
            f"{r.files_ok}/{r.total_files} fichier(s), "
            f"{nb_lignes_fmt} ligne(s) integree(s)"
        )
        if r.errors:
            for fichier, message in r.errors[:5]:
                lignes_rapport.append(f"      * {fichier} : {message}")
            if len(r.errors) > 5:
                lignes_rapport.append(f"      * ... et {len(r.errors) - 5} autre(s) erreur(s) (voir le journal complet dans l'application).")

    lignes_rapport.append("")
    lignes_rapport.append("Ce mail a ete genere automatiquement par Data Integrator (ICI Assurance).")
    body = "\n".join(lignes_rapport)

    try:
        ok, message = send_mail(dsi_account, subject, body)
        if ok:
            log("success", f"Mail recapitulatif DSI envoye ({len(resultats)} source(s)).")
        else:
            log("warning", f"Echec de l'envoi du mail recapitulatif DSI : {message}")
    except Exception as e:
        log("warning", f"Echec de l'envoi du mail recapitulatif DSI : {e}")


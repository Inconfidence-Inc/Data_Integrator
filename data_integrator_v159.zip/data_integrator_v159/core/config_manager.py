"""
config_manager.py
------------------
Gère la lecture/écriture du fichier de configuration (sources.json) :
    - profils de connexion SQL Server multiples (ex: Recette, Production)
    - liste des sources (pays, type/TPA, dossier source, table cible, domaine,
      gestion de l'historique, header_mode)

Le fichier config est cherché à côté de l'exécutable / du script (compatible
PyInstaller --onefile via app_paths si besoin plus tard).
"""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional


from core.app_paths import resolve_config_path

DEFAULT_CONFIG_PATH = resolve_config_path("sources.json")

# Domaines de donnees geres par l'application (cle interne sans accent, utilisee
# aussi dans les noms de table ; libelle affiche defini dans DOMAIN_LABELS cote UI)
DOMAINES = ["Adhesion", "Sinistre", "FIC", "Reclamation"]

# Base de donnees cible attendue pour toutes les insertions (memes tables
# quel que soit l'environnement Local/Recette/Production, qui pointent
# chacun vers un serveur different mais la meme base TECH_BI).
EXPECTED_DATABASE = "TECH_BI"

# Types de source (TPA) connus, proposes dans le formulaire (liste modifiable/completable)
TPA_TYPES = ["SPB", "Evy", "Estaly", "NEAT", "LAPI", "GP"]


@dataclass
class ConnectionProfile:
    id: str
    nom: str
    server: str = r"(localdb)\MSSQLLocalDB"
    database: str = "TECH_BI"
    username: str = ""
    password: str = ""
    driver: str = "ODBC Driver 18 for SQL Server"
    derniere_connexion_ok: bool = False

    @staticmethod
    def new(nom: str, server: str = r"(localdb)\MSSQLLocalDB", database: str = "TECH_BI",
            username: str = "", password: str = "", driver: str = "ODBC Driver 18 for SQL Server") -> "ConnectionProfile":
        return ConnectionProfile(
            id=uuid.uuid4().hex[:8], nom=nom, server=server, database=database,
            username=username, password=password, driver=driver,
        )


def types_avec_plusieurs_pays(sources: "list[SourceConfig]", domaine: str | None = None) -> set[str]:
    """
    V137, sur demande explicite de l'utilisateur : le libellay affiche pour
    une source (colonne source_tpa des donnees fusionnees, en-tetes Fusion,
    colonne TPA de Chargement, ecran OK/KO, tableau Statistiques) ne doit
    inclure le pays QUE lorsque ce type de TPA a reellement plusieurs
    variantes pays distinctes (cas de SPB : France/Italie/Espagne/Pologne)
    — pour un type a un seul pays (Evy, Estaly, NEAT, LAPI, GP...), le nom
    seul suffit et evite un suffixe \"France\" inutile partout.

    Retourne l'ensemble des TYPES de TPA ayant plusieurs pays distincts
    parmi les sources fournies (optionnellement filtrees par domaine) —
    ce sont les seuls types pour lesquels le pays doit etre affiche."""
    par_type: dict[str, set[str]] = {}
    for s in sources:
        if domaine is not None and s.domaine != domaine:
            continue
        par_type.setdefault(s.type, set()).add(s.pays)
    return {t for t, pays_set in par_type.items() if len(pays_set) > 1}


def label_tpa(type_tpa: str, pays: str, types_multi_pays: set[str]) -> str:
    """Libelle a afficher pour une source donnee (V137) : le pays n'est
    inclus que si ce type figure dans types_multi_pays (calcule via
    types_avec_plusieurs_pays), sinon le type seul suffit."""
    if pays and type_tpa in types_multi_pays:
        return f"{type_tpa} {pays}"
    return type_tpa


@dataclass
class SourceConfig:
    id: str
    pays: str
    type: str
    dossier_source: str
    table: str
    domaine: str = "Adhesion"
    header_mode: str = "auto"
    vider_avant_integration: bool = True
    nb_fichiers_estimes: int = 0
    nb_lignes_estimees: int = 0
    pretraitement_statut: str = "Non controle"

    @staticmethod
    def new(pays: str, type_: str, dossier_source: str, table: str, domaine: str = "Adhesion",
            header_mode: str = "auto", vider_avant_integration: bool = True,
            nb_fichiers_estimes: int = 0, nb_lignes_estimees: int = 0,
            pretraitement_statut: str = "Non controle") -> "SourceConfig":
        return SourceConfig(
            id=uuid.uuid4().hex[:8],
            pays=pays,
            type=type_,
            dossier_source=dossier_source,
            table=table,
            domaine=domaine,
            header_mode=header_mode,
            vider_avant_integration=vider_avant_integration,
            nb_fichiers_estimes=nb_fichiers_estimes,
            nb_lignes_estimees=nb_lignes_estimees,
            pretraitement_statut=pretraitement_statut,
        )


class ConfigManager:
    """Charge, modifie et sauvegarde la configuration (profils de connexion + sources)."""

    def __init__(self, path: Path | str = DEFAULT_CONFIG_PATH):
        self.path = Path(path)
        self.connections: list[ConnectionProfile] = []
        self.active_connection_id: str = ""
        # Connexion a utiliser automatiquement a chaque lancement de
        # l'application (V90), choisie explicitement par l'utilisateur —
        # distincte de active_connection_id (qui suit simplement le dernier
        # profil consulte pendant la session en cours). Si non definie,
        # active_connection_id garde son comportement habituel (dernier
        # profil utilise).
        self.default_connection_id: str = ""
        self.sources: list[SourceConfig] = []
        self.load()

    # -- Chargement / sauvegarde --------------------------------------

    def load(self) -> None:
        if not self.path.exists():
            self._init_defaults()
            return

        # Filet de securite (V99, corrige V100) : si le fichier existe mais
        # que la seule cle "sources" est vide (cas reel rencontre :
        # utilisateur ayant deja lance une version V94-V97 sans config/
        # livre), on recupere UNIQUEMENT les sources par defaut fournies
        # avec cette version — sans jamais toucher aux connexions deja en
        # place dans ce meme fichier, meme si elles sont personnalisees.
        from core.app_paths import backfill_key_if_empty, ensure_all_default_sources_present
        backfill_key_if_empty(self.path, "sources.json", "sources")

        # V132, sur demande explicite de l'utilisateur : complement plus
        # fin — une liste PARTIELLEMENT remplie (certains TPA deja
        # configures, d'autres manquants) ne declenchait pas le filet
        # ci-dessus (qui ne verifie que "la liste est-elle VIDE ?"). Chaque
        # source par defaut manquante est desormais ajoutee individuellement,
        # sans jamais toucher a une source deja presente (meme avec un
        # chemin de dossier personnalise et different de la valeur par
        # defaut).
        ensure_all_default_sources_present(self.path, "sources.json")

        with open(self.path, encoding="utf-8") as f:
            data = json.load(f)

        if "connections" in data:
            self.connections = [
                ConnectionProfile(
                    id=c.get("id") or uuid.uuid4().hex[:8],
                    nom=c.get("nom", "Sans nom"),
                    server=c.get("server", ConnectionProfile.server),
                    database=c.get("database", ConnectionProfile.database),
                    username=c.get("username", ""),
                    password=c.get("password", ""),
                    driver=c.get("driver", ConnectionProfile.driver),
                    derniere_connexion_ok=c.get("derniere_connexion_ok", False),
                )
                for c in data["connections"]
            ]
            self.active_connection_id = data.get("active_connection_id", "")
            self.default_connection_id = data.get("default_connection_id", "")
        elif "connection" in data:
            # compatibilite ascendante V1-V4 : un seul profil "connection"
            c = data["connection"]
            profile = ConnectionProfile.new(
                nom="Production",
                server=c.get("server", ConnectionProfile.server),
                database=c.get("database", ConnectionProfile.database),
                username=c.get("username", ""),
                password=c.get("password", ""),
                driver=c.get("driver", ConnectionProfile.driver),
            )
            self.connections = [profile]
            self.active_connection_id = profile.id
        else:
            self.connections = [ConnectionProfile.new(nom="Production")]
            self.active_connection_id = self.connections[0].id

        if not self.connections:
            self.connections = [ConnectionProfile.new(nom="Production")]
        self._ensure_local_profile()
        # La connexion par defaut choisie explicitement (V90) prime toujours
        # sur le simple "dernier profil consulte" au demarrage, si elle est
        # toujours valide.
        if self.default_connection_id and any(c.id == self.default_connection_id for c in self.connections):
            self.active_connection_id = self.default_connection_id
        if not self.active_connection_id or not any(c.id == self.active_connection_id for c in self.connections):
            self.active_connection_id = self.connections[0].id

        self.sources = [
            SourceConfig(
                id=s.get("id") or uuid.uuid4().hex[:8],
                pays=s.get("pays", ""),
                type=s.get("type", ""),
                # compatibilite ascendante : dossier_source (V5) <- fichier_source (V3/V4) <- dossier (V1/V2)
                dossier_source=s.get("dossier_source") or s.get("fichier_source") or s.get("dossier", ""),
                table=s.get("table", ""),
                domaine=s.get("domaine", "Adhesion"),
                header_mode=s.get("header_mode", "auto"),
                vider_avant_integration=s.get("vider_avant_integration", True),
                nb_fichiers_estimes=s.get("nb_fichiers_estimes", 0),
                nb_lignes_estimees=s.get("nb_lignes_estimees", 0),
                pretraitement_statut=s.get("pretraitement_statut", "Non controle"),
            )
            for s in data.get("sources", [])
        ]

    def _ensure_local_profile(self) -> None:
        """Garantit la presence d'un profil 'Local' (poste de dev/localdb),
        ajoute automatiquement pour les configs V5 anterieures qui ne l'avaient pas."""
        if not any(c.nom.strip().lower() == "local" for c in self.connections):
            self.connections.insert(0, ConnectionProfile.new(
                nom="Local", server=r"(localdb)\MSSQLLocalDB", database="TECH_BI",
            ))

    def _init_defaults(self):
        self.connections = [
            ConnectionProfile.new(nom="Local", server=r"(localdb)\MSSQLLocalDB", database="TECH_BI"),
            ConnectionProfile.new(nom="Recette"),
            ConnectionProfile.new(nom="Production"),
        ]
        self.active_connection_id = self.connections[0].id
        self.sources = []

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "connections": [asdict(c) for c in self.connections],
            "active_connection_id": self.active_connection_id,
            "default_connection_id": self.default_connection_id,
            "sources": [asdict(s) for s in self.sources],
        }
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def set_default_connection(self, connection_id: str) -> None:
        """Definit explicitement (V90) quelle connexion doit etre utilisee
        automatiquement a chaque lancement de l'application, independamment
        du profil consulte en dernier pendant une session. Passer une chaine
        vide retire ce choix (retour au comportement \"dernier profil
        utilise\")."""
        if connection_id and not any(c.id == connection_id for c in self.connections):
            raise KeyError(f"Profil de connexion introuvable : {connection_id}")
        self.default_connection_id = connection_id
        self.save()

    # -- CRUD sources ----------------------------------------------------

    def add_source(self, source: SourceConfig) -> None:
        self.sources.append(source)
        self.save()

    def update_source(self, source_id: str, **changes) -> None:
        for s in self.sources:
            if s.id == source_id:
                for k, v in changes.items():
                    setattr(s, k, v)
                self.save()
                return
        raise KeyError(f"Source introuvable : {source_id}")

    def remove_source(self, source_id: str) -> None:
        self.sources = [s for s in self.sources if s.id != source_id]
        self.save()

    def get_source(self, source_id: str) -> Optional[SourceConfig]:
        return next((s for s in self.sources if s.id == source_id), None)

    # -- CRUD profils de connexion ---------------------------------------

    def get_active_connection(self) -> ConnectionProfile:
        conn = next((c for c in self.connections if c.id == self.active_connection_id), None)
        return conn or self.connections[0]

    def set_active_connection(self, connection_id: str) -> None:
        if any(c.id == connection_id for c in self.connections):
            self.active_connection_id = connection_id
            self.save()

    def add_connection(self, profile: ConnectionProfile) -> None:
        self.connections.append(profile)
        self.save()

    def update_connection(self, connection_id: str, **changes) -> None:
        for c in self.connections:
            if c.id == connection_id:
                for k, v in changes.items():
                    setattr(c, k, v)
                self.save()
                return
        raise KeyError(f"Profil de connexion introuvable : {connection_id}")

    def remove_connection(self, connection_id: str) -> None:
        if len(self.connections) <= 1:
            return  # toujours garder au moins un profil
        self.connections = [c for c in self.connections if c.id != connection_id]
        if self.active_connection_id == connection_id:
            self.active_connection_id = self.connections[0].id
        self.save()

    def get_connection(self, connection_id: str) -> Optional[ConnectionProfile]:
        return next((c for c in self.connections if c.id == connection_id), None)


PREPROCESSING_RULES_PATH = resolve_config_path("preprocessing_rules.json")


class PreprocessingRulesManager:
    """Persiste les regles generiques de controle : liste de colonnes
    attendues configuree PAR TPA (SPB, Evy, Estaly, ...) et un motif de
    nommage des fichiers (generique, commun a tous les TPA). Persiste
    egalement (V92) les dossiers OK/KO de deplacement des fichiers apres
    controle, par TPA, ainsi que le reglage d'activation de ce
    deplacement — inspire du fonctionnement d'Orchestrator."""

    def __init__(self, path: Path | str = PREPROCESSING_RULES_PATH):
        self.path = Path(path)
        self.expected_columns_by_tpa: dict[str, str] = {}
        self.filename_pattern: str = ""
        self.ok_folder_by_tpa: dict[str, str] = {}
        self.ko_folder_by_tpa: dict[str, str] = {}
        self.deplacement_actif: bool = False
        self.mail_ko_actif: bool = False
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            return
        with open(self.path, encoding="utf-8") as f:
            data = json.load(f)
        self.expected_columns_by_tpa = data.get("expected_columns_by_tpa", {})
        self.filename_pattern = data.get("filename_pattern", "")
        self.ok_folder_by_tpa = data.get("ok_folder_by_tpa", {})
        self.ko_folder_by_tpa = data.get("ko_folder_by_tpa", {})
        self.deplacement_actif = data.get("deplacement_actif", False)
        self.mail_ko_actif = data.get("mail_ko_actif", False)

    def save(self, expected_columns_by_tpa: dict[str, str], filename_pattern: str) -> None:
        self.expected_columns_by_tpa = dict(expected_columns_by_tpa)
        self.filename_pattern = filename_pattern
        self._write()

    def save_move_config(
        self, ok_folder_by_tpa: dict[str, str], ko_folder_by_tpa: dict[str, str],
        deplacement_actif: bool, mail_ko_actif: bool,
    ) -> None:
        self.ok_folder_by_tpa = dict(ok_folder_by_tpa)
        self.ko_folder_by_tpa = dict(ko_folder_by_tpa)
        self.deplacement_actif = deplacement_actif
        self.mail_ko_actif = mail_ko_actif
        self._write()

    def _write(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "expected_columns_by_tpa": self.expected_columns_by_tpa,
                    "filename_pattern": self.filename_pattern,
                    "ok_folder_by_tpa": self.ok_folder_by_tpa,
                    "ko_folder_by_tpa": self.ko_folder_by_tpa,
                    "deplacement_actif": self.deplacement_actif,
                    "mail_ko_actif": self.mail_ko_actif,
                },
                f, ensure_ascii=False, indent=2,
            )

    def get_ok_folder(self, tpa_type: str, pays: str | None = None) -> str:
        return self._get_folder(self.ok_folder_by_tpa, tpa_type, pays)

    def get_ko_folder(self, tpa_type: str, pays: str | None = None) -> str:
        return self._get_folder(self.ko_folder_by_tpa, tpa_type, pays)

    @staticmethod
    def _get_folder(folders: dict[str, str], tpa_type: str, pays: str | None) -> str:
        """V109 : les dossiers OK/KO sont desormais stockes par SOURCE
        reelle (type + pays), et non plus par simple type — un type comme
        SPB recouvre en realite plusieurs sources distinctes (France,
        Italie, Espagne, Pologne), chacune avec potentiellement son propre
        repertoire. La cle combinee 'Type|Pays' est utilisee en priorite ;
        a defaut, on retombe sur l'ancienne cle par type seul (V92-V108),
        pour ne rien perdre d'une configuration deja saisie avant ce
        changement."""
        if pays:
            valeur = folders.get(f"{tpa_type}|{pays}", "").strip()
            if valeur:
                return valeur
        return folders.get(tpa_type, "").strip()

    def get_expected_columns(self, tpa_type: str) -> list[str]:
        """
        Decoupe la liste de colonnes collee par l'utilisateur. Tolerant au
        format de copier-coller : virgule, point-virgule (CSV francais),
        tabulation (colle depuis Excel), retour a la ligne (une colonne par
        ligne) ou barre verticale sont tous acceptes comme separateurs.
        Les guillemets residuels d'un export CSV sont egalement retires.
        """
        raw = self.expected_columns_by_tpa.get(tpa_type, "")
        if not raw.strip():
            return []
        parts = re.split(r"[;,\t\n|]+", raw)
        return [p.strip().strip('"').strip("'") for p in parts if p.strip().strip('"').strip("'")]

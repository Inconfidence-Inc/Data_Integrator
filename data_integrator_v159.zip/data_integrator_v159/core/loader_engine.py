"""
loader_engine.py
-----------------
Logique métier de chargement, reprise du script load_to_sqlserver.py d'origine.
Mêmes comportements (détection encodage/séparateur/en-tête, réparation mojibake,
DDL VARCHAR(MAX), insertion par chunks avec retry) mais :
    - paramétrée (plus de constantes globales CONFIG)
    - pilotée par callbacks (log_cb, progress_cb) pour être utilisée depuis un
      QThread sans bloquer l'IHM ni dépendre du module logging
    - annulable (stop_flag) pour permettre un bouton "Annuler" côté IHM

Ce module ne dépend pas de PySide6 : il reste testable/utilisable en ligne de
commande si besoin.
"""

from __future__ import annotations

import csv
import math
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import chardet
import pandas as pd
import pyodbc
from sqlalchemy import text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError

_NULLISH = frozenset(("", "nan", "none", "nat", "null", "n/a", "#n/a"))

LogCallback = Callable[[str, str], None]           # (level, message)
ProgressCallback = Callable[[int, int, str], None]  # (current, total, label)

READERS_SUFFIXES = (".csv", ".txt", ".xlsx", ".xls", ".json")

_ENCODING_CANDIDATES = ["utf-8-sig", "utf-8", "cp1252", "iso-8859-15", "latin-1"]
_LOW_CONFIDENCE_THRESHOLD = 50


@dataclass
class LoaderSettings:
    chunk_size: int = 50_000
    max_read_workers: int = 4
    max_retries: int = 3
    retry_delay: int = 2
    header_mode: str = "auto"
    optimize_bulk_insert: bool = True
    # Delai maximal (secondes) tolere pour une seule requete SQL (insertion
    # d'un paquet de lignes, ou operation DDL) avant d'etre consideree comme
    # bloquee et interrompue de force (V84). Sans cela, une coupure reseau
    # en cours d'insertion pouvait bloquer indefiniment, sans aucun message
    # et sans que le bouton "Annuler" ne puisse jamais reprendre la main
    # (stop_flag n'est verifie qu'ENTRE deux requetes, jamais PENDANT).
    sql_timeout_seconds: int = 120


@dataclass
class SourceLoadResult:
    source_id: str
    table: str
    total_files: int = 0
    files_ok: int = 0
    total_rows: int = 0
    total_rows_read: int = 0  # lignes reellement lues dans les fichiers cette execution (avant filtrage/erreurs), distinct de total_rows (lignes effectivement inserees) — sert a l'ecran statistique (V59)
    elapsed_seconds: float = 0.0
    errors: list[tuple[str, str]] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return not self.errors


class LoadCancelled(Exception):
    """Levée quand l'utilisateur annule le chargement en cours."""


# ===========================================================================
#  Réparation mojibake
# ===========================================================================

def fix_mojibake(s):
    if not isinstance(s, str):
        return s
    for enc in ("latin-1", "cp1252"):
        try:
            fixed = s.encode(enc).decode("utf-8")
            if fixed != s:
                return fixed
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass
    return s


def repair_dataframe(df: pd.DataFrame, log_cb: Optional[LogCallback] = None) -> pd.DataFrame:
    original_cols = list(df.columns)
    fixed_cols = [fix_mojibake(c) for c in original_cols]
    changed_cols = sum(1 for a, b in zip(original_cols, fixed_cols) if a != b)
    if changed_cols and log_cb:
        log_cb("info", f"  [mojibake] {changed_cols} noms de colonnes reparés")
    df.columns = fixed_cols

    # V120 : si plusieurs colonnes portent EXACTEMENT le meme nom (rencontre
    # en usage reel : un en-tete mal detecte, avec de nombreuses colonnes
    # vides ""), df[col] renvoie un DataFrame (toutes les colonnes de ce
    # nom) plutot qu'une Series (une seule colonne) — .any() plante alors
    # avec "The truth value of a Series is ambiguous", bloquant totalement
    # la lecture du fichier. On traite donc chaque colonne par POSITION
    # (iloc), jamais par nom, pour rester correct meme en presence de noms
    # dupliques.
    for i in range(len(df.columns)):
        col_serie = df.iloc[:, i]
        mask = col_serie.notna()
        if mask.any():
            try:
                df.iloc[:, i] = col_serie.where(~mask, col_serie[mask].map(fix_mojibake))
            except Exception:
                pass
    return df


# ===========================================================================
#  Gestion des en-têtes
# ===========================================================================

def parse_header_mode(mode: str) -> tuple:
    m = mode.strip().lower()
    if m in ("auto", "always"):
        return 0, None
    if m == "never":
        return None, None
    match = re.fullmatch(r"skip_(\d+)", m)
    if match:
        return 0, int(match.group(1))
    match = re.fullmatch(r"row_(\d+)", m)
    if match:
        return int(match.group(1)), None
    return 0, None


def looks_like_header(row: pd.Series) -> bool:
    total = len(row)
    values = [str(v).strip() for v in row if str(v).strip() not in ("", "nan", "None")]
    if not values:
        return False
    # V120, suite a un cas reel rencontre (fichier LAPI) : une ligne de
    # TITRE DE SECTION ("DONNEE CONTRAT|||CLIENT PERSONNE PHYSIQUE||||||...",
    # tres largement vide avec seulement quelques intitules de groupe
    # eparpilles) etait a tort acceptee comme en-tete valide — les cellules
    # vides etaient filtrees AVANT l'evaluation, et ce qui restait (du texte
    # sans chiffres) ressemblait alors superficiellement a un en-tete. Une
    # vraie ligne d'en-tete nomme quasiment toujours TOUTES ses colonnes :
    # on exige desormais qu'au moins 60% des cellules soient effectivement
    # remplies pour rester une candidate valide.
    if total and (len(values) / total) < 0.6:
        return False
    numeric = sum(
        1 for v in values
        if re.fullmatch(r"[-+]?(\d+[\.,]?\d*|\.\d+)([eE][-+]?\d+)?", v)
    )
    return (numeric / len(values)) < 0.5


def sniff_separator(filepath: Path, encoding: str) -> str:
    try:
        with open(filepath, encoding=encoding, errors="replace") as f:
            sample = "".join(f.readline() for _ in range(3))
        for sep in ("|", ";", "\t", ","):
            if sep in sample:
                return sep
    except Exception:
        pass
    return ","


def _corruption_score(text_: str) -> int:
    bad_patterns = [
        "ã©", "ã ", "ã¨", "ã«", "ã®", "ã´", "ã»", "ã¢", "ã§", "ã¯",
        "â€", "â€™", "â€œ", "â€", "Ã©", "Ã ", "Ã¨",
        "\ufffd",
    ]
    return sum(text_.lower().count(p) for p in bad_patterns)


def _best_encoding_for_header(filepath: Path, sep: str, candidates: list) -> str:
    best_enc = candidates[0]
    best_score = 999_999
    for enc in candidates:
        try:
            with open(filepath, encoding=enc, errors="strict") as f:
                first_line = f.readline()
            score = _corruption_score(first_line)
            if score < best_score:
                best_score = score
                best_enc = enc
            if score == 0:
                break
        except (UnicodeDecodeError, LookupError):
            continue
    return best_enc


def normalize_encoding(encoding: str) -> str:
    enc = (encoding or "utf-8").lower()
    if enc in ("windows-1252", "iso-8859-1"):
        return "cp1252"
    if enc in ("utf-8-sig", "utf-8"):
        return "utf-8-sig"
    return encoding


def detect_encoding(filepath: Path, log_cb: Optional[LogCallback] = None) -> str:
    with open(filepath, "rb") as f:
        raw = f.read(200_000)

    if raw[:3] == b"\xef\xbb\xbf":
        if log_cb:
            log_cb("info", "  Encodage detecte : utf-8-sig (BOM UTF-8 present)")
        return "utf-8-sig"

    result = chardet.detect(raw)
    confidence = int((result.get("confidence") or 0) * 100)
    encoding = normalize_encoding(result.get("encoding") or "utf-8")

    if confidence < _LOW_CONFIDENCE_THRESHOLD:
        if log_cb:
            log_cb("info", f"  chardet peu confiant ({confidence}% pour {encoding}) -> scan multi-encodage")
        return f"__scan__{encoding}"

    if log_cb:
        log_cb("info", f"  Encodage detecte : {encoding} (confiance {confidence}%)")
    return encoding


def auto_detect_header_csv(filepath: Path, encoding: str, log_cb: Optional[LogCallback] = None) -> tuple:
    sep = sniff_separator(filepath, encoding)
    try:
        sample = pd.read_csv(
            filepath, encoding=encoding, sep=sep, engine="python",
            dtype=str, header=None, nrows=5, on_bad_lines="skip",
        )
        if sample.empty:
            return 0, None, sep
        if looks_like_header(sample.iloc[0]):
            if log_cb:
                log_cb("info", f"  [auto] En-tete detecte ligne 0 (sep='{sep}')")
            return 0, None, sep
        # V120 : si la ligne 0 ne ressemble pas a un vrai en-tete (ex: une
        # ligne de titre de section largement vide, rejetee par
        # looks_like_header depuis ce correctif), on examine les quelques
        # lignes suivantes avant d'abandonner — un fichier peut tres bien
        # avoir 1 ou 2 lignes de titre/groupement au-dessus du vrai en-tete.
        for idx in range(1, min(len(sample), 5)):
            if looks_like_header(sample.iloc[idx]):
                if log_cb:
                    log_cb("info", f"  [auto] En-tete detecte ligne {idx} (sep='{sep}') — {idx} ligne(s) au-dessus ignoree(s)")
                return idx, idx, sep
        if log_cb:
            log_cb("info", f"  [auto] Aucun en-tete detecte (sep='{sep}')")
        return None, None, sep
    except Exception:
        return 0, None, sep


def auto_detect_header_excel(filepath: Path, log_cb: Optional[LogCallback] = None) -> tuple:
    try:
        sample = pd.read_excel(filepath, header=None, nrows=5, dtype=str)
        if sample.empty:
            return 0, None
        if looks_like_header(sample.iloc[0]):
            return 0, None
        return None, None
    except Exception:
        return 0, None


def sanitize_column_name(name) -> str:
    """
    Normalise un seul nom de colonne selon la meme regle que celle appliquee
    aux fichiers charges : espaces/caracteres speciaux -> underscore,
    minuscules. Reutilisee a la fois par sanitize_column_names (sur un
    DataFrame) et par le controle de pretraitement (sur une liste de
    colonnes attendues saisie/collee par l'utilisateur), pour que la
    comparaison se fasse toujours sur la meme forme normalisee.
    """
    n = str(name).strip().lstrip("\ufeff")
    n = re.sub(r"[^\w]", "_", n)
    n = re.sub(r"_+", "_", n).strip("_")
    if not n or re.fullmatch(r"\d+", n):
        n = f"col_{n}" if n else "col"
    return n.lower()


def sanitize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    cleaned = [sanitize_column_name(col) for col in df.columns]

    seen: dict = {}
    result = []
    for name in cleaned:
        if name in seen:
            seen[name] += 1
            result.append(f"{name}_{seen[name]}")
        else:
            seen[name] = 0
            result.append(name)
    df.columns = result
    return df


def rename_columns_by_position(df: pd.DataFrame) -> pd.DataFrame:
    df.columns = [f"col_{i}" for i in range(len(df.columns))]
    return df


def apply_column_strategy(df: pd.DataFrame, had_header: bool, log_cb: Optional[LogCallback] = None) -> pd.DataFrame:
    df = repair_dataframe(df, log_cb)
    if had_header:
        return sanitize_column_names(df)
    return rename_columns_by_position(df)


# ===========================================================================
#  Lecture des fichiers
# ===========================================================================

def _read_csv_with_params(filepath, encoding, sep, header, skiprows, log_cb=None):
    """
    V111 : les lignes avec TROP de champs (separateur en trop non echappe
    dans un champ texte) etaient ignorees en silence par pandas
    (on_bad_lines="skip"), sans aucune trace — corrige en comptant et
    signalant ces lignes.

    V119, suite a un signalement utilisateur (donnees dans de mauvaises
    colonnes sur de gros volumes, SPB France) : le correctif V111 ne
    couvrait qu'UNE direction du probleme. Une ligne avec un separateur
    MANQUANT (au lieu d'un en trop) n'etait PAS detectee par pandas — elle
    est silencieusement acceptee comme "ligne plus courte", avec les
    valeurs manquantes ajoutees en NaN en FIN de ligne plutot qu'a
    l'endroit reel du champ absent. Consequence : TOUTES les colonnes
    suivant le champ manquant se retrouvent decalees d'une position, sans
    aucun avertissement — exactement le symptome observe. Remplace donc la
    lecture pandas seule par un pre-scan avec le module csv standard (qui
    respecte correctement les guillemets, contrairement a un simple
    split()) : chaque ligne de donnees dont le nombre de champs ne
    correspond PAS exactement a celui de l'en-tete est exclue et signalee
    — dans les DEUX sens (trop ou pas assez), de facon symetrique.
    """
    with open(filepath, encoding=encoding, newline="") as f:
        toutes_lignes = list(csv.reader(f, delimiter=sep))

    idx_entete = skiprows or 0
    if header is None or idx_entete >= len(toutes_lignes):
        # Pas d'en-tete identifiable : aucune validation de coherence
        # possible, on delegue integralement a pandas comme avant.
        return pd.read_csv(
            filepath, encoding=encoding, sep=sep, engine="python",
            dtype=str, header=header, skiprows=skiprows, on_bad_lines="skip",
        )

    entete = toutes_lignes[idx_entete]
    nb_champs_attendu = len(entete)

    lignes_valides = []
    lignes_rejetees = []
    for ligne in toutes_lignes[idx_entete + 1:]:
        if not ligne or (len(ligne) == 1 and not ligne[0].strip()):
            continue  # ligne vide en fin de fichier, ignoree silencieusement (normal)

        if len(ligne) > nb_champs_attendu:
            # V120, suite a un cas reel rencontre (SPB France, 138 lignes
            # sur 138 rejetees a tort) : un delimiteur final en fin de
            # chaque ligne du fichier source cree un champ "fantome"
            # supplementaire, vide, non reflete dans l'en-tete — un
            # artefact d'export benin, systematique sur tout le fichier, a
            # bien distinguer d'une vraie corruption (delimiteur non
            # echappe AU MILIEU d'un champ texte, qui cree elle aussi un
            # champ en trop mais avec du contenu). Si TOUS les champs en
            # trop, en fin de ligne, sont vides, on les retire simplement
            # plutot que de rejeter toute la ligne ; sinon, comportement
            # inchange (rejet, cas reellement suspect).
            excedent = ligne[nb_champs_attendu:]
            if all(not v.strip() for v in excedent):
                lignes_valides.append(ligne[:nb_champs_attendu])
                continue
            lignes_rejetees.append(ligne)
        elif len(ligne) != nb_champs_attendu:
            lignes_rejetees.append(ligne)
        else:
            lignes_valides.append(ligne)

    if lignes_rejetees and log_cb:
        trop = sum(1 for l in lignes_rejetees if len(l) > nb_champs_attendu)
        pas_assez = len(lignes_rejetees) - trop
        detail = []
        if trop:
            detail.append(f"{trop} avec trop de colonnes")
        if pas_assez:
            detail.append(f"{pas_assez} avec pas assez de colonnes")
        log_cb(
            "warning",
            f"  {len(lignes_rejetees)} ligne(s) ignoree(s) dans {filepath.name} ({', '.join(detail)} "
            f"par rapport aux {nb_champs_attendu} attendues — separateur en trop ou manquant, souvent "
            f"a l'interieur d'un champ texte). Premiere ligne concernee (extrait) : {lignes_rejetees[0][:8]}",
        )

    df = pd.DataFrame(lignes_valides, columns=entete, dtype=str)
    return df


def read_csv_file(filepath: Path, header_mode: str, log_cb: Optional[LogCallback] = None) -> pd.DataFrame:
    raw_encoding = detect_encoding(filepath, log_cb)

    if raw_encoding.startswith("__scan__"):
        fallback_enc = raw_encoding.replace("__scan__", "") or "utf-8"
        sep = sniff_separator(filepath, fallback_enc)
        encoding = _best_encoding_for_header(filepath, sep, _ENCODING_CANDIDATES)
        if log_cb:
            log_cb("info", f"  Meilleur encodage retenu apres scan : {encoding}")
    else:
        encoding = raw_encoding
        sep = sniff_separator(filepath, encoding)

    if header_mode == "auto":
        header, skiprows, sep = auto_detect_header_csv(filepath, encoding, log_cb)
    else:
        header, skiprows = parse_header_mode(header_mode)

    had_header = header is not None
    candidates = [encoding] + [e for e in _ENCODING_CANDIDATES if e != encoding] + ["latin-1"]

    for enc in candidates:
        try:
            df = _read_csv_with_params(filepath, enc, sep, header, skiprows, log_cb)
            return apply_column_strategy(df, had_header, log_cb)
        except UnicodeDecodeError:
            if log_cb:
                log_cb("warning", f"  Encodage {enc} echoue, tentative suivante...")
        except Exception:
            break

    raise ValueError(f"Impossible de lire {filepath.name} avec les encodages disponibles")


def read_txt_file(filepath: Path, header_mode: str, log_cb: Optional[LogCallback] = None) -> pd.DataFrame:
    return read_csv_file(filepath, header_mode, log_cb)


def read_excel_file(filepath: Path, engine_name: str, header_mode: str, log_cb: Optional[LogCallback] = None) -> pd.DataFrame:
    if header_mode == "auto":
        header, skiprows = auto_detect_header_excel(filepath, log_cb)
    else:
        header, skiprows = parse_header_mode(header_mode)
    had_header = header is not None
    df = pd.read_excel(filepath, engine=engine_name, dtype=str, header=header, skiprows=skiprows)
    return apply_column_strategy(df, had_header, log_cb)


def read_json_file(filepath: Path, header_mode: str, log_cb: Optional[LogCallback] = None) -> pd.DataFrame:
    df = pd.read_json(filepath, dtype=str)
    return sanitize_column_names(df)


def read_file(filepath: Path, header_mode: str, log_cb: Optional[LogCallback] = None):
    suffix = filepath.suffix.lower()
    try:
        if suffix in (".csv",):
            df = read_csv_file(filepath, header_mode, log_cb)
        elif suffix == ".txt":
            df = read_txt_file(filepath, header_mode, log_cb)
        elif suffix == ".xlsx":
            df = read_excel_file(filepath, "openpyxl", header_mode, log_cb)
        elif suffix == ".xls":
            df = read_excel_file(filepath, "xlrd", header_mode, log_cb)
        elif suffix == ".json":
            df = read_json_file(filepath, header_mode, log_cb)
        else:
            raise ValueError(f"Extension non prise en charge : {suffix}")
        return filepath, df
    except Exception as e:
        return filepath, e


# ===========================================================================
#  DDL
# ===========================================================================

_MAX_BOUNDED_VARCHAR = 4000  # au-dela, on reste sur VARCHAR(MAX) par securite/coherence SQL Server


def compute_column_lengths(dataframes: list, margin: float = 1.3, minimum: int = 50) -> dict:
    """
    Calcule, pour chaque colonne (union de toutes les dataframes fournies), la
    longueur de chaine maximale observee, avec une marge de securite (+30% par
    defaut). Sert a dimensionner des colonnes VARCHAR(N) bornees plutot que
    VARCHAR(MAX) : c'est ce qui restaure la capacite de pyodbc/fast_executemany
    a grouper reellement les insertions (le mode MAX force silencieusement un
    envoi ligne par ligne, beaucoup plus lent — c'est la cause principale des
    chargements lents constates).

    Une colonne dont la longueur maximale (avec marge) depasse le seuil
    raisonnable n'est pas incluse dans le resultat : elle reste en
    VARCHAR(MAX) (colonne de texte libre trop variable pour etre bornee
    sereinement).
    """
    max_lengths: dict = {}
    for df in dataframes:
        if df is None or not hasattr(df, "columns"):
            continue
        for col in df.columns:
            try:
                col_max = df[col].dropna().astype(str).map(len).max()
            except Exception:
                col_max = None
            if col_max is None or (isinstance(col_max, float) and math.isnan(col_max)):
                col_max = 0
            col_max = int(col_max)
            max_lengths[col] = max(max_lengths.get(col, 0), col_max)

    sized: dict = {}
    for col, max_len in max_lengths.items():
        target = max(int(max_len * margin), minimum)
        if target <= _MAX_BOUNDED_VARCHAR:
            sized[col] = target
    return sized


def create_table_varchar(
    engine: Engine, schema: str, table_name: str, columns: list,
    column_lengths: Optional[dict] = None, log_cb: Optional[LogCallback] = None,
):
    column_lengths = column_lengths or {}
    col_defs = []
    nb_bounded = 0
    for col in columns:
        length = column_lengths.get(col)
        if length:
            col_defs.append(f"[{col}] VARCHAR({length})")
            nb_bounded += 1
        else:
            col_defs.append(f"[{col}] VARCHAR(MAX)")
    cols_ddl = ",\n    ".join(col_defs)
    ddl = f"""
    IF OBJECT_ID(N'[{schema}].[{table_name}]', N'U') IS NOT NULL
        DROP TABLE [{schema}].[{table_name}];
    CREATE TABLE [{schema}].[{table_name}] (
        {cols_ddl}
    );
    """
    with engine.begin() as conn:
        conn.execute(text(ddl))
    if log_cb:
        log_cb(
            "info",
            f"Table [{schema}].[{table_name}] creee/recreee ({len(columns)} colonnes, "
            f"{nb_bounded} bornees VARCHAR(N) pour l'insertion rapide, {len(columns) - nb_bounded} en VARCHAR(MAX))",
        )


def ensure_table_ready(
    engine: Engine, schema: str, table_name: str, columns: list,
    vider_avant: bool, column_lengths: Optional[dict] = None, log_cb: Optional[LogCallback] = None,
) -> None:
    """
    Prepare la table cible avant insertion, selon le mode choisi :
      - vider_avant=True  : DROP + CREATE (table remise a neuf, historique perdu)
      - vider_avant=False : la table existante est conservee (historique garde) ;
                             si elle n'existe pas encore, elle est creee ; si des
                             colonnes du fichier n'existent pas encore en base,
                             elles sont ajoutees automatiquement (ALTER TABLE ADD).
    Les colonnes sont dimensionnees en VARCHAR(N) quand column_lengths le permet
    (insertion nettement plus rapide), sinon VARCHAR(MAX) par defaut.
    """
    from core.db import get_existing_columns

    if vider_avant:
        create_table_varchar(engine, schema, table_name, columns, column_lengths, log_cb)
        return

    existing = get_existing_columns(engine, schema, table_name)
    if existing is None:
        create_table_varchar(engine, schema, table_name, columns, column_lengths, log_cb)
        return

    missing = [c for c in columns if c not in existing]
    if not missing:
        return

    column_lengths = column_lengths or {}
    with engine.begin() as conn:
        for col in missing:
            length = column_lengths.get(col)
            col_type = f"VARCHAR({length})" if length else "VARCHAR(MAX)"
            conn.execute(text(f"ALTER TABLE [{schema}].[{table_name}] ADD [{col}] {col_type}"))
    if log_cb:
        log_cb("info", f"  {len(missing)} colonne(s) ajoutee(s) a la table existante [{schema}].[{table_name}] : {missing}")


def quick_count_rows(source_dir: str) -> tuple[int, int]:
    """
    Estimation rapide (sans parsing complet) du nombre de fichiers compatibles
    et du nombre total de lignes de donnees (hors en-tete) dans un dossier.
    Utilisee pour l'apercu immediat lors de la selection du dossier dans l'IHM.
    Approximation : compte les sauts de ligne ; retire 1 ligne par fichier CSV/TXT
    (en-tete suppose present). Pour Excel/JSON, ouverture legere (sans dtype=str).
    """
    folder = Path(source_dir)
    if not folder.is_dir():
        return 0, 0

    nb_fichiers = 0
    total_lignes = 0
    for f in sorted(folder.iterdir()):
        if not f.is_file() or f.suffix.lower() not in READERS_SUFFIXES:
            continue
        nb_fichiers += 1
        try:
            suffix = f.suffix.lower()
            if suffix in (".csv", ".txt"):
                with open(f, "rb") as fh:
                    nb_lignes = sum(1 for _ in fh)
                total_lignes += max(nb_lignes - 1, 0)  # -1 pour l'en-tete estime
            elif suffix in (".xlsx", ".xls"):
                import openpyxl
                wb = openpyxl.load_workbook(f, read_only=True)
                ws = wb.active
                total_lignes += max((ws.max_row or 1) - 1, 0)
                wb.close()
            elif suffix == ".json":
                import json as _json
                with open(f, encoding="utf-8", errors="replace") as fh:
                    data = _json.load(fh)
                total_lignes += len(data) if isinstance(data, list) else 1
        except Exception:
            continue  # estimation best-effort : on ignore les fichiers illisibles

    return nb_fichiers, total_lignes


def _scan_file_once(filepath: Path) -> tuple[bool, int, bool]:
    """
    Un SEUL passage sur le fichier (lecture binaire par blocs de 1 Mo) pour
    obtenir a la fois : la presence de guillemets, le nombre de sauts de
    ligne, et si le fichier se termine par un saut de ligne. Remplace deux
    lectures completes separees (_file_contains_quote_byte +
    _count_newlines_raw) par une seule — deux fois plus rapide sur les gros
    fichiers, ou le temps est domine par la lecture disque/OS.
    """
    has_quote = False
    newline_count = 0
    last_byte = b""
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            if not has_quote and b'"' in chunk:
                has_quote = True
            newline_count += chunk.count(b"\n")
            last_byte = chunk[-1:]
    return has_quote, newline_count, (last_byte == b"\n")


def _count_newlines_raw(filepath: Path) -> tuple[int, bool]:
    """
    Compte le nombre de sauts de ligne d'un fichier par lecture BINAIRE
    brute, sans aucun decodage ni parsing — la methode la plus rapide
    possible (un simple comptage d'octets par blocs de 1 Mo). Retourne
    (nombre de \\n trouves, le fichier se termine-t-il par un saut de ligne).
    Conservee pour compatibilite/tests ; count_rows_csv_ultra_fast utilise
    desormais _scan_file_once (un seul passage au lieu de deux).
    """
    count = 0
    last_byte = b""
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            count += chunk.count(b"\n")
            last_byte = chunk[-1:]
    return count, (last_byte == b"\n")


def _file_contains_quote_byte(filepath: Path) -> bool:
    """Scan binaire rapide (arret des le premier trouve) : le fichier
    utilise-t-il des guillemets quelque part ? Conservee pour compatibilite/
    tests ; count_rows_csv_ultra_fast utilise desormais _scan_file_once."""
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                return False
            if b'"' in chunk:
                return True


def _count_rows_csv_ultra_fast(filepath: Path, header_mode: str) -> int:
    """
    Methode ULTRA rapide, garantie fiable :
      - Si le fichier ne contient AUCUN guillemet (cas des fichiers plats
        TPA rencontres jusqu'ici) : comptage brut de sauts de ligne, sans
        aucun decodage ni parsing — extremement rapide, et 100% fiable dans
        ce cas puisqu'aucun mecanisme de guillemets n'est en jeu, donc aucun
        risque qu'un champ contienne un saut de ligne interne.
      - Si le fichier contient des guillemets : utilise le module csv natif
        de Python (implemente en C), qui gere correctement les valeurs
        contenant un saut de ligne interne entre guillemets — un peu moins
        rapide, mais toujours sans construction de DataFrame et toujours
        fiable a 100%, quel que soit le contenu.
    """
    raw_encoding = detect_encoding(filepath)
    if raw_encoding.startswith("__scan__"):
        fallback_enc = raw_encoding.replace("__scan__", "") or "utf-8"
        sep = sniff_separator(filepath, fallback_enc)
        encoding = _best_encoding_for_header(filepath, sep, _ENCODING_CANDIDATES)
    else:
        encoding = raw_encoding
        sep = sniff_separator(filepath, encoding)

    if header_mode == "auto":
        header, skiprows, sep = auto_detect_header_csv(filepath, encoding)
    else:
        header, skiprows = parse_header_mode(header_mode)
    skiprows = skiprows or 0
    lignes_entete = skiprows + (1 if header is not None else 0)

    has_quote, nb_lignes_brutes, ends_with_newline = _scan_file_once(filepath)

    if not has_quote:
        if not ends_with_newline and nb_lignes_brutes >= 0 and filepath.stat().st_size > 0:
            nb_lignes_brutes += 1  # derniere ligne sans saut de ligne final, comptee quand meme
        return max(nb_lignes_brutes - lignes_entete, 0)

    if len(sep) != 1:
        raise ValueError("Separateur multi-caractere non supporte par le comptage csv rapide")

    import csv as csv_module
    count = 0
    with open(filepath, encoding=encoding, newline="", errors="replace") as f:
        reader = csv_module.reader(f, delimiter=sep)
        for i, _row in enumerate(reader):
            if i < lignes_entete:
                continue
            count += 1
    return count


def _count_rows_csv_fast_v41(filepath: Path, header_mode: str) -> int:
    """
    Compte le nombre de lignes de donnees d'un fichier CSV/TXT rapidement :
    reutilise EXACTEMENT la meme detection d'encodage/separateur/en-tete que
    la lecture reelle (read_csv_file), mais ne parse que la 1re colonne
    (usecols=[0]) et utilise le moteur C de pandas (separateur mono-caractere,
    toujours le cas ici) au lieu du moteur python — nettement plus rapide,
    tout en donnant un resultat strictement identique (meme nombre de lignes
    qu'une lecture complete). Repli fiable de _count_rows_csv_ultra_fast pour
    les fichiers contenant des sauts de ligne au sein d'un champ entre
    guillemets.
    """
    raw_encoding = detect_encoding(filepath)
    if raw_encoding.startswith("__scan__"):
        fallback_enc = raw_encoding.replace("__scan__", "") or "utf-8"
        sep = sniff_separator(filepath, fallback_enc)
        encoding = _best_encoding_for_header(filepath, sep, _ENCODING_CANDIDATES)
    else:
        encoding = raw_encoding
        sep = sniff_separator(filepath, encoding)

    if header_mode == "auto":
        header, skiprows, sep = auto_detect_header_csv(filepath, encoding)
    else:
        header, skiprows = parse_header_mode(header_mode)

    engine = "c" if len(sep) == 1 else "python"
    try:
        df = pd.read_csv(
            filepath, encoding=encoding, sep=sep, engine=engine,
            usecols=[0], dtype=str, header=header, skiprows=skiprows,
            on_bad_lines="skip",
        )
    except Exception:
        # Repli sur le moteur python si le moteur C echoue pour une raison
        # quelconque (separateur/format inhabituel) — jamais d'echec silencieux.
        df = pd.read_csv(
            filepath, encoding=encoding, sep=sep, engine="python",
            usecols=[0], dtype=str, header=header, skiprows=skiprows,
            on_bad_lines="skip",
        )
    return len(df)


def _count_rows_csv_fast(filepath: Path, header_mode: str) -> int:
    """
    Compte le nombre de lignes de donnees d'un fichier CSV/TXT. Tente
    d'abord la methode ULTRA rapide (comptage brut d'octets, voir
    _count_rows_csv_ultra_fast) ; si le fichier semble contenir des
    guillemets non apparies (signe possible de valeur multi-lignes), utilise
    directement la methode V41 (moteur C pandas) qui reste fiable dans ce
    cas. En cas d'echec inattendu de la methode ultra rapide, repli
    automatique sur la methode V41 — jamais d'echec silencieux.
    """
    try:
        return _count_rows_csv_ultra_fast(filepath, header_mode)
    except Exception:
        return _count_rows_csv_fast_v41(filepath, header_mode)


def _count_rows_excel_fast(filepath: Path, engine_name: str, header_mode: str) -> int:
    """Compte les lignes d'un Excel via openpyxl en mode lecture seule
    (read_only=True), sans charger le contenu des cellules — beaucoup plus
    rapide qu'un parsing pandas complet pour un simple comptage."""
    if header_mode == "auto":
        header, skiprows = auto_detect_header_excel(filepath)
    else:
        header, skiprows = parse_header_mode(header_mode)
    had_header = header is not None
    skip = skiprows or 0

    try:
        import openpyxl
        wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
        try:
            max_row = wb.active.max_row or 0
        finally:
            wb.close()
        n = max_row - skip - (1 if had_header else 0)
        return max(n, 0)
    except Exception:
        df = pd.read_excel(filepath, engine=engine_name, dtype=str, header=header, skiprows=skiprows, usecols=[0])
        return len(df)


def count_rows_fast(filepath: Path, header_mode: str) -> int:
    """
    Point d'entree du comptage rapide : redirige vers la methode optimisee
    selon le format. En cas d'echec (fichier atypique), retombe sur une
    lecture complete via read_file() pour garantir un resultat correct dans
    tous les cas (jamais de perte d'exactitude au profit de la vitesse).
    """
    suffix = filepath.suffix.lower()
    try:
        if suffix in (".csv", ".txt"):
            return _count_rows_csv_fast(filepath, header_mode)
        if suffix == ".xlsx":
            return _count_rows_excel_fast(filepath, "openpyxl", header_mode)
        if suffix == ".xls":
            return _count_rows_excel_fast(filepath, "xlrd", header_mode)
    except Exception:
        pass  # repli sur la lecture complete ci-dessous

    _fp, res = read_file(filepath, header_mode)
    if isinstance(res, Exception):
        raise res
    return len(res)


def count_exact_rows(
    source_dir: str, header_mode: str = "auto", max_workers: int = 8,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
) -> tuple[int, int]:
    """
    Calcule le nombre EXACT de fichiers compatibles et de lignes de donnees
    d'un dossier, avec la meme detection d'encodage/separateur/en-tete que le
    chargement reel (donc un resultat strictement comparable a la colonne
    \"Lignes chargees\" apres execution), mais via count_rows_fast() — moteur C
    pandas + une seule colonne parsee pour les CSV/TXT, mode lecture seule
    openpyxl pour les Excel — au lieu d'une lecture complete de chaque
    fichier. Lecture en parallele (8 workers par defaut, adapte a des dossiers
    sur lecteur reseau ou la latence domine plus que le CPU).

    progress_cb(fichiers_traites, total, nom_dernier_fichier), appele apres
    chaque fichier compte : sans cela, un dossier avec beaucoup de fichiers
    ou de gros volumes (reseau) ne donne AUCUN signe d'avancement avant la
    toute fin, ce qui peut donner l'impression a tort que le calcul est
    bloque alors qu'il travaille toujours (meme constat que pour la phase de
    lecture du chargement reel, corrige separement).
    """
    folder = Path(source_dir)
    if not folder.is_dir():
        # Important de faire la difference avec "dossier vide" (0 fichier
        # compatible trouve, cas normal) : ici le dossier n'existe pas ou
        # n'est plus accessible du tout (lecteur reseau deconnecte, chemin
        # errone, etc.) — ne jamais faire disparaitre silencieusement le
        # resultat en (0, 0), sinon l'utilisateur ne voit qu'un retour au
        # bouton "Calculer" sans comprendre pourquoi. Cette exception
        # remonte via RowCountWorker.failed, avec un message explicite.
        raise FileNotFoundError(f"Dossier introuvable ou inaccessible : {source_dir}")

    files = sorted(f for f in folder.iterdir() if f.is_file() and f.suffix.lower() in READERS_SUFFIXES)
    if not files:
        return 0, 0

    total_lignes = 0
    nb_traites = 0
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(count_rows_fast, f, header_mode): f for f in files}
        for future in as_completed(futures):
            filepath = futures[future]
            nb_traites += 1
            try:
                total_lignes += future.result()
            except Exception:
                pass  # fichier illisible : ignore pour le comptage, comme avant
            if progress_cb:
                progress_cb(nb_traites, len(files), filepath.name)

    return len(files), total_lignes


# ===========================================================================
#  Nettoyage des valeurs
# ===========================================================================

def safe(v):
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    s = str(v).strip()
    return None if s.lower() in _NULLISH else s


def clean_df(df: pd.DataFrame) -> pd.DataFrame:
    df = df.where(df.notna(), None)
    # V120 : traitement par POSITION (iloc), jamais par nom (df[col]) — un
    # nom de colonne duplique (rencontre en usage reel avec un en-tete mal
    # detecte) ferait sinon planter ce traitement (df[col] renvoie un
    # DataFrame au lieu d'une Series des qu'un nom apparait plusieurs fois).
    for i in range(len(df.columns)):
        col_data = df.iloc[:, i]
        mask = col_data.notna()
        if mask.any():
            col_data = col_data.copy()
            col_data.loc[mask] = col_data.loc[mask].astype(str).str.strip()
            nullish_mask = col_data.astype(str).str.lower().isin(_NULLISH)
            col_data.loc[nullish_mask] = None
            df.iloc[:, i] = col_data
    return df


_TRUNCATION_MARKERS = ("would be truncated", "8152", "2628")
_TRUNCATION_COLUMN_RE = re.compile(r"column\s+'([^']+)'", re.IGNORECASE)


def _is_truncation_error(e: Exception) -> bool:
    msg = str(e).lower()
    return any(marker in msg for marker in _TRUNCATION_MARKERS)


_TIMEOUT_MARKERS = ("timeout expired", "hyt00", "hyt01", "query timeout")


def _is_timeout_error(e: Exception) -> bool:
    """Detecte si une erreur correspond a un delai depasse (V84), pour
    donner un message clair a l'utilisateur ('connexion probablement
    interrompue') plutot qu'un message pyodbc brut et cryptique."""
    msg = str(e).lower()
    return any(marker in msg for marker in _TIMEOUT_MARKERS)


def _widen_columns_after_truncation(
    engine: Engine, schema: str, table_name: str, chunk: pd.DataFrame,
    error: Exception, log_cb: Optional[LogCallback] = None,
) -> None:
    """
    Filet de securite : si une insertion echoue par troncature (colonne
    VARCHAR(N) trop etroite pour une valeur reelle rencontree), on elargit
    la ou les colonnes concernees puis on laisse la boucle de retry
    reessayer le meme chunk. Jamais de perte de donnees par troncature
    silencieuse — au pire, la colonne repasse en VARCHAR(MAX).
    """
    full_name = f"[{schema}].[{table_name}]"
    match = _TRUNCATION_COLUMN_RE.search(str(error))
    if match:
        candidates = [match.group(1)]
    else:
        # Impossible d'identifier la colonne fautive dans le message d'erreur
        # (certaines versions de SQL Server ne la mentionnent pas) : on
        # elargit par securite toutes les colonnes texte du chunk courant.
        candidates = list(chunk.columns)

    for col in candidates:
        try:
            with engine.begin() as conn:
                conn.execute(text(f"ALTER TABLE {full_name} ALTER COLUMN [{col}] VARCHAR(MAX)"))
            if log_cb:
                log_cb("warning", f"  [auto] Colonne [{col}] elargie en VARCHAR(MAX) suite a une troncature detectee.")
        except Exception as widen_error:
            if log_cb:
                log_cb("warning", f"  [auto] Impossible d'elargir la colonne [{col}] : {widen_error}")


# ===========================================================================
#  Insertion par chunks avec retry
# ===========================================================================

def _chunk_probably_already_inserted(
    engine: Engine, schema: str, table_name: str,
    total_before_chunk: int, chunk_size: int, log_cb: Optional[LogCallback] = None,
) -> bool:
    """
    Verifie si le nombre de lignes actuellement en base est deja coherent
    avec un chunk qui aurait reussi cote serveur malgre une erreur cote
    client (accuse de reception perdu suite a une coupure reseau). Ne bloque
    jamais le chargement si la verification elle-meme echoue (retombe alors
    sur le comportement normal : nouvelle tentative)."""
    try:
        with engine.connect() as check_conn:
            result = check_conn.execute(text(f"SELECT COUNT(*) FROM [{schema}].[{table_name}]"))
            current_count = result.scalar()
        return current_count is not None and current_count >= total_before_chunk + chunk_size
    except Exception as e:
        if log_cb:
            log_cb("warning", f"  Impossible de verifier le comptage avant nouvelle tentative ({e}) — nouvelle tentative normale.")
        return False


def insert_df(
    engine: Engine,
    schema: str,
    table_name: str,
    df: pd.DataFrame,
    settings: LoaderSettings,
    log_cb: Optional[LogCallback] = None,
    stop_flag: Optional[Callable[[], bool]] = None,
) -> int:
    if df.empty:
        if log_cb:
            log_cb("info", "  -> fichier vide, ignore")
        return 0

    df = clean_df(df)
    cols = ", ".join(f"[{c}]" for c in df.columns)
    placeholders = ", ".join("?" * len(df.columns))
    sql = f"INSERT INTO [{schema}].[{table_name}] ({cols}) VALUES ({placeholders})"

    total_inserted = 0
    nb_chunks = math.ceil(len(df) / settings.chunk_size)

    for chunk_idx in range(nb_chunks):
        if stop_flag and stop_flag():
            raise LoadCancelled()

        chunk = df.iloc[chunk_idx * settings.chunk_size: (chunk_idx + 1) * settings.chunk_size]
        rows = [tuple(safe(v) for v in row) for row in chunk.itertuples(index=False, name=None)]

        total_before_chunk = total_inserted
        for attempt in range(1, settings.max_retries + 1):
            try:
                with engine.begin() as conn:
                    raw_connection = conn.connection
                    raw_cursor = raw_connection.cursor()
                    # CRITIQUE : fast_executemany=True sur le moteur SQLAlchemy n'a
                    # d'effet que lorsque SQLAlchemy execute lui-meme l'insertion.
                    # Ici on utilise le curseur pyodbc brut (necessaire pour figer
                    # precisement le SQL et les types), ce qui contourne ce
                    # mecanisme : il faut donc l'activer explicitement sur CE
                    # curseur, sans quoi chaque ligne repart en aller-retour
                    # individuel malgre le parametre du moteur (c'etait la cause
                    # racine de la lenteur, independante du dimensionnement
                    # VARCHAR(N) deja en place).
                    raw_cursor.fast_executemany = True
                    # Delai maximal (V84, corrige V85) : sans ceci, une coupure
                    # reseau en plein executemany() peut bloquer indefiniment
                    # (aucun timeout par defaut sur pyodbc), rendant le bouton
                    # "Annuler" totalement inoperant puisque stop_flag n'est
                    # jamais reverifie tant qu'on reste bloque dans cet appel.
                    # IMPORTANT : pyodbc.Cursor est un objet C sans __dict__, il
                    # n'accepte PAS qu'on lui affecte un attribut .timeout — ce
                    # reglage doit se faire sur la CONNEXION (pyodbc.Connection),
                    # qui elle le supporte nativement et l'applique a toute
                    # requete executee via ses curseurs.
                    raw_connection.timeout = settings.sql_timeout_seconds
                    raw_cursor.executemany(sql, rows)
                total_inserted += len(rows)
                break
            except (SQLAlchemyError, pyodbc.Error) as e:
                # Reverifie l'annulation ICI (V84) : si l'utilisateur a
                # clique "Annuler" PENDANT que ce chunk etait bloque, on
                # honore la demande immediatement plutot que de repartir
                # pour 1 a 2 nouvelles tentatives (jusqu'a
                # sql_timeout_seconds chacune) avant de la reverifier au
                # prochain chunk.
                if stop_flag and stop_flag():
                    raise LoadCancelled()

                if _is_truncation_error(e):
                    if log_cb:
                        log_cb("warning", f"  Chunk {chunk_idx + 1}/{nb_chunks} : troncature detectee, elargissement automatique en cours...")
                    _widen_columns_after_truncation(engine, schema, table_name, chunk, e, log_cb)
                    continue  # retente immediatement sans consommer une tentative "erreur reseau"

                # Risque de doublon : l'insertion a pu reussir COTE SERVEUR juste
                # avant que la confirmation ne se perde (coupure reseau au moment
                # precis du commit) — dans ce cas, retenter aveuglement reinsere
                # les memes lignes une seconde fois. On verifie le nombre reel de
                # lignes en base avant de retenter : si le compte confirme deja
                # l'insertion de ce chunk, on ne le reinsere pas.
                if _chunk_probably_already_inserted(engine, schema, table_name, total_before_chunk, len(rows), log_cb):
                    if log_cb:
                        log_cb("warning", f"  Chunk {chunk_idx + 1}/{nb_chunks} : erreur apres l'insertion ({e}), mais le comptage en base confirme qu'elle a reussi -> pas de nouvelle tentative (evite un doublon).")
                    total_inserted += len(rows)
                    break

                if attempt < settings.max_retries:
                    if log_cb:
                        if _is_timeout_error(e):
                            log_cb("warning", f"  Chunk {chunk_idx + 1}/{nb_chunks} : ⏱ delai de {settings.sql_timeout_seconds}s depasse (connexion probablement interrompue ou tres lente) — nouvelle tentative {attempt}/{settings.max_retries}...")
                        else:
                            log_cb("warning", f"  Chunk {chunk_idx + 1}/{nb_chunks} : erreur tentative {attempt}/{settings.max_retries} -> {e}")
                    time.sleep(settings.retry_delay)
                else:
                    if log_cb:
                        if _is_timeout_error(e):
                            log_cb("error", f"  Chunk {chunk_idx + 1}/{nb_chunks} : ⏱ echec apres {settings.max_retries} tentatives — delai de {settings.sql_timeout_seconds}s systematiquement depasse. La connexion reseau vers SQL Server semble interrompue ou trop lente pour continuer.")
                        else:
                            log_cb("error", f"  Chunk {chunk_idx + 1}/{nb_chunks} : echec apres {settings.max_retries} tentatives -> {e}")
                    raise

        if nb_chunks > 1 and log_cb:
            log_cb("info", f"  Chunk {chunk_idx + 1}/{nb_chunks} insere ({len(rows)} lignes)")

    return total_inserted


# ===========================================================================
#  Orchestration d'une source complète
# ===========================================================================

def load_source(
    engine: Engine,
    source_dir: str,
    table: str,
    settings: LoaderSettings,
    source_id: str = "",
    vider_avant_integration: bool = True,
    log_cb: Optional[LogCallback] = None,
    progress_cb: Optional[ProgressCallback] = None,
    stop_flag: Optional[Callable[[], bool]] = None,
    registry: Optional["LoadedFilesRegistry"] = None,
    flux: str = "",
) -> SourceLoadResult:
    """
    Charge tous les fichiers compatibles d'un dossier vers une table SQL Server.
    Reproduit le comportement du script original (lecture parallele, DDL VARCHAR(MAX),
    insertion par chunks) et gere l'historique :
        - vider_avant_integration=True  : la table est recreee (DROP+CREATE) au
          premier fichier traite (historique precedent perdu).
        - vider_avant_integration=False : la table existante est conservee ; les
          nouvelles lignes s'ajoutent a la suite. Si la structure de colonnes
          differe, les colonnes manquantes sont ajoutees automatiquement.

    Si un registry (LoadedFilesRegistry) est fourni ET que le mode est
    "historique conserve", les fichiers deja charges avec succes lors d'un
    precedent lancement (meme nom, meme taille, meme date de modification)
    sont automatiquement ignores — evite de tout retraiter a chaque fois pour
    les tables volumineuses/dossiers qui grossissent avec le temps. Sans
    objet en mode "vider" (la table est de toute facon recreee a neuf).
    """
    t_start = time.perf_counter()
    result = SourceLoadResult(source_id=source_id, table=table)

    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    files = sorted(
        f for f in Path(source_dir).iterdir()
        if f.is_file() and f.suffix.lower() in READERS_SUFFIXES
    )
    result.total_files = len(files)

    if not files:
        log("error", f"Aucun fichier compatible trouve dans : {source_dir}")
        result.errors.append(("-", "Aucun fichier compatible trouve"))
        return result

    if registry is not None and vider_avant_integration and source_id:
        # La table va etre recreee a neuf (DROP+CREATE) : le suivi precedent
        # n'a plus de sens (les fichiers "deja charges" ne sont plus
        # reellement en base). On le reinitialise pour eviter qu'un futur
        # passage en mode "historique conserve" n'ignore a tort des fichiers
        # qui ne sont en realite plus dans la table actuelle.
        registry.reset_source(source_id)

    nb_ignores = 0
    if registry is not None and not vider_avant_integration and source_id:
        files_a_traiter = []
        for f in files:
            if registry.was_seen_with_different_signature(source_id, f):
                log(
                    "warning",
                    f"  {f.name} : deja charge precedemment mais semble modifie depuis "
                    "(taille/date differente) — retraite par prudence. Attention : en mode "
                    "historique conserve, les anciennes lignes de ce fichier ne sont pas "
                    "supprimees automatiquement, un doublon partiel est possible.",
                )
                files_a_traiter.append(f)
            elif registry.is_already_loaded(source_id, f):
                nb_ignores += 1
            else:
                files_a_traiter.append(f)
        if nb_ignores:
            log("info", f"{nb_ignores} fichier(s) deja charge(s) lors d'un precedent lancement, ignore(s) (suivi par nom+taille+date).")
        files = files_a_traiter

    if not files:
        log("info", f"Tous les fichiers de {source_dir} ont deja ete charges precedemment ({nb_ignores} ignore(s)), rien a faire.")
        return result

    log("info", f"{len(files)} fichier(s) a traiter dans {source_dir}" + (f" ({nb_ignores} deja charge(s) et ignore(s))" if nb_ignores else ""))
    schema, table_name = table.split(".", 1) if "." in table else ("dbo", table)

    log("info", f"Lecture des fichiers en parallele ({settings.max_read_workers} workers)...")
    read_results: dict = {}
    nb_lus = 0
    # Frequence des messages de progression : environ 10 messages au total,
    # jamais plus d'un par fichier, jamais moins que le 1er et le dernier —
    # evite qu'une phase de lecture longue (gros fichiers, lecteur reseau
    # lent) ne donne l'impression que le chargement s'est arrete, en
    # l'absence de toute trace pendant potentiellement plusieurs minutes.
    intervalle_log = max(1, len(files) // 10)
    with ThreadPoolExecutor(max_workers=settings.max_read_workers) as executor:
        futures = {
            executor.submit(read_file, f, settings.header_mode, log_cb): f
            for f in files
        }
        for future in as_completed(futures):
            if stop_flag and stop_flag():
                for fut in futures:
                    fut.cancel()
                raise LoadCancelled()
            filepath, res = future.result()
            read_results[filepath] = res
            nb_lus += 1
            if progress_cb:
                progress_cb(nb_lus, len(files), f"lecture : {filepath.name}")
            if nb_lus == 1 or nb_lus == len(files) or nb_lus % intervalle_log == 0:
                log("info", f"  lecture {nb_lus}/{len(files)} fichier(s)...")

    valid_dataframes = [res for res in read_results.values() if not isinstance(res, Exception)]
    result.total_rows_read = sum(len(df) for df in valid_dataframes)
    column_lengths = compute_column_lengths(valid_dataframes) if settings.optimize_bulk_insert else {}
    if column_lengths:
        log("info", f"  [optim] {len(column_lengths)} colonne(s) dimensionnee(s) en VARCHAR(N) pour l'insertion rapide (calcule sur {len(valid_dataframes)} fichier(s))")

    table_prepared = False
    optim_state = None

    try:
        for i, filepath in enumerate(files):
            if stop_flag and stop_flag():
                raise LoadCancelled()

            if progress_cb:
                progress_cb(i + 1, len(files), filepath.name)
            log("info", f"[{i + 1}/{len(files)}] {filepath.name}")

            res = read_results[filepath]
            if isinstance(res, Exception):
                log("error", f"  ERREUR lecture : {res}")
                result.errors.append((filepath.name, f"Lecture : {res}"))
                continue

            df = res
            preview_cols = list(df.columns[:6]) + (["..."] if len(df.columns) > 6 else [])
            log("info", f"  -> {len(df)} lignes, {len(df.columns)} colonnes : {preview_cols}")

            try:
                # Seul le premier fichier applique vider_avant_integration (DROP+CREATE
                # si coche) ; les fichiers suivants du meme lot ne font qu'ajouter les
                # colonnes manquantes, pour ne pas ecraser ce qui vient d'etre insere.
                ensure_table_ready(
                    engine, schema, table_name, list(df.columns),
                    vider_avant=(vider_avant_integration and not table_prepared),
                    column_lengths=column_lengths,
                    log_cb=log_cb,
                )

                if not table_prepared and settings.optimize_bulk_insert:
                    # Applique systematiquement, quel que soit le mode historique.
                    # En mode "vider", la table vient d'etre recreee a neuf (DROP+CREATE
                    # juste au-dessus) : aucun index/trigger/contrainte n'existe encore,
                    # donc l'appel ne fait rien (no-op rapide) mais reste sans risque —
                    # utile si une contrainte/trigger a ete ajoutee entre deux executions.
                    from core.db_optimize import disable_for_bulk_load
                    log("info", f"  [optim] Preparation du chargement rapide sur [{schema}].[{table_name}]...")
                    optim_state = disable_for_bulk_load(engine, schema, table_name, log_cb)

                table_prepared = True

                n = insert_df(engine, schema, table_name, df, settings, log_cb, stop_flag)
                result.total_rows += n
                result.files_ok += 1
                log("info", f"  -> {n} lignes inserees")
                if registry is not None and source_id:
                    registry.mark_loaded(source_id, filepath, n)
                if engine is not None:
                    # Alimentation de la table d'historique ADM_Fichiers_Integres
                    # (V61) : jamais bloquant, un echec ici n'empeche pas le
                    # chargement reel des donnees (deja fait juste au-dessus).
                    from core.integration_history import record_integration_history
                    record_integration_history(engine, filepath.name, n, flux, log_cb)
            except LoadCancelled:
                raise
            except Exception as e:
                log("error", f"  ERREUR insertion : {e}")
                result.errors.append((filepath.name, f"Insertion : {e}"))
    finally:
        if optim_state is not None:
            from core.db_optimize import restore_after_bulk_load
            log("info", f"  [optim] Reactivation des composants sur [{schema}].[{table_name}]...")
            restore_after_bulk_load(engine, optim_state, log_cb)

    result.elapsed_seconds = time.perf_counter() - t_start
    if result.errors:
        log("warning", f"{len(result.errors)} fichier(s) en erreur pour {table}")
    else:
        log("info", f"Tous les fichiers de {table} charges sans erreur ({result.total_rows} lignes, {result.elapsed_seconds:.1f}s).")

    return result

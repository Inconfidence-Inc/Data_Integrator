"""
preprocessing.py
-----------------
"Pretraitement" des fichiers sources avant chargement (etape du schema
d'architecture situee en amont de "Integration et Chargement"). Controles
generiques, memes regles pour les 3 domaines (Adhesion / Sinistre / FIC) :

    - Nommage du fichier : le nom doit correspondre a un motif (regex),
      optionnel.
    - Encodage : signale les fichiers dont l'encodage n'a pas pu etre
      detecte avec confiance (necessite un scan multi-encodage a la lecture).
    - Structure des colonnes : compare les colonnes detectees a une liste de
      colonnes attendues, optionnelle (colonnes manquantes = erreur,
      colonnes en plus = avertissement).

Controle en lecture seule, rapide : ne lit que l'en-tete + quelques lignes
de chaque fichier (jamais le fichier entier), et ne modifie jamais rien.
Reutilise les memes fonctions de detection que le moteur de chargement
(core/loader_engine.py) pour rester coherent avec ce qui sera reellement
charge ensuite.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd

from core.loader_engine import (
    READERS_SUFFIXES, detect_encoding, sniff_separator,
    auto_detect_header_csv, auto_detect_header_excel,
    sanitize_column_names, sanitize_column_name, repair_dataframe, parse_header_mode,
)


@dataclass
class FileCheckResult:
    filename: str
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    colonnes_detectees: list[str] = field(default_factory=list)
    encodage_detecte: str = ""
    is_reference: bool = False

    @property
    def status(self) -> str:
        if self.errors:
            return "Erreur"
        if self.warnings:
            return "Avertissement"
        return "OK"


@dataclass
class SourceCheckResult:
    source_id: str
    files: list[FileCheckResult] = field(default_factory=list)

    @property
    def status(self) -> str:
        if not self.files:
            return "Erreur"
        if any(f.status == "Erreur" for f in self.files):
            return "Erreur"
        if any(f.status == "Avertissement" for f in self.files):
            return "Avertissement"
        return "OK"


def _peek_columns(filepath: Path, header_mode: str) -> list[str]:
    """Lit uniquement l'en-tete (+ quelques lignes) pour recuperer les
    colonnes, sans parser tout le fichier. Reutilise la logique de
    detection du loader_engine pour rester coherent avec le chargement reel."""
    suffix = filepath.suffix.lower()
    try:
        if suffix in (".csv", ".txt"):
            encoding = detect_encoding(filepath)
            if encoding.startswith("__scan__"):
                encoding = encoding.replace("__scan__", "") or "utf-8"
            if header_mode == "auto":
                header, skiprows, sep = auto_detect_header_csv(filepath, encoding)
            else:
                sep = sniff_separator(filepath, encoding)
                header, skiprows = parse_header_mode(header_mode)
            df = pd.read_csv(
                filepath, encoding=encoding, sep=sep, engine="python",
                dtype=str, header=header, skiprows=skiprows, nrows=5, on_bad_lines="skip",
            )
        elif suffix in (".xlsx", ".xls"):
            if header_mode == "auto":
                header, skiprows = auto_detect_header_excel(filepath)
            else:
                header, skiprows = parse_header_mode(header_mode)
            engine_name = "openpyxl" if suffix == ".xlsx" else "xlrd"
            df = pd.read_excel(filepath, engine=engine_name, dtype=str, header=header, skiprows=skiprows, nrows=5)
        elif suffix == ".json":
            df = pd.read_json(filepath, dtype=str)
        else:
            return []
    except Exception:
        return []

    df = repair_dataframe(df.copy())
    df = sanitize_column_names(df)
    return list(df.columns)


def check_file(
    filepath: Path,
    expected_columns: Optional[list[str]] = None,
    filename_pattern: Optional[str] = None,
    header_mode: str = "auto",
) -> FileCheckResult:
    result = FileCheckResult(filename=filepath.name)

    # -- Nommage ------------------------------------------------------
    if filename_pattern:
        try:
            if not re.search(filename_pattern, filepath.name, re.IGNORECASE):
                result.warnings.append(f"Le nom de fichier ne correspond pas au motif attendu ({filename_pattern!r})")
        except re.error as e:
            result.warnings.append(f"Motif de nommage invalide : {e}")

    # -- Encodage -------------------------------------------------------
    if filepath.suffix.lower() in (".csv", ".txt"):
        try:
            encoding = detect_encoding(filepath)
            result.encodage_detecte = encoding.replace("__scan__", "") or "utf-8"
            if encoding.startswith("__scan__"):
                result.warnings.append("Encodage incertain : detection automatique multi-encodage necessaire (a verifier)")
        except Exception as e:
            result.errors.append(f"Impossible de determiner l'encodage : {e}")

    # -- Colonnes -------------------------------------------------------
    columns = _peek_columns(filepath, header_mode)
    result.colonnes_detectees = columns
    if not columns:
        result.errors.append("Impossible de lire l'en-tete du fichier (fichier vide, corrompu ou format non reconnu)")
    elif expected_columns:
        # Meme normalisation que celle appliquee aux fichiers reellement charges
        # (espaces/accents/caracteres speciaux -> underscore, minuscules), pour
        # que coller les en-tetes exactement tels qu'ils apparaissent dans le
        # fichier source (ex: "Nom Client", "N° Contrat") fonctionne directement.
        expected_set = {sanitize_column_name(c) for c in expected_columns if c.strip()}
        detected_set = {c.lower() for c in columns}
        missing = expected_set - detected_set
        extra = detected_set - expected_set
        if missing:
            result.errors.append(f"Colonne(s) attendue(s) manquante(s) : {sorted(missing)}")
        if extra:
            result.warnings.append(f"Colonne(s) presente(s) non attendue(s) : {sorted(extra)}")

    return result


def check_source_folder(
    source_id: str,
    folder: str,
    expected_columns: Optional[list[str]] = None,
    filename_pattern: Optional[str] = None,
    header_mode: str = "auto",
) -> SourceCheckResult:
    result = SourceCheckResult(source_id=source_id)
    folder_path = Path(folder)

    if not folder_path.is_dir():
        result.files.append(FileCheckResult(filename="-", errors=["Dossier introuvable"]))
        return result

    files = sorted(f for f in folder_path.iterdir() if f.is_file() and f.suffix.lower() in READERS_SUFFIXES)
    if not files:
        result.files.append(FileCheckResult(filename="-", errors=["Aucun fichier compatible trouve dans le dossier"]))
        return result

    # Le premier fichier du dossier sert de reference structurelle : tous les
    # fichiers suivants du meme dossier (meme TPA) doivent avoir exactement
    # les memes colonnes ET le meme encodage que lui (V111, sur demande
    # explicite de l'utilisateur pour l'encodage — les colonnes etaient deja
    # comparees ainsi). Ce controle est automatique, sans aucune
    # configuration necessaire, et vient en complement des colonnes
    # attendues eventuellement configurees par TPA.
    reference_columns: list[str] | None = None
    reference_encoding: str = ""
    reference_filename = files[0].name

    for i, f in enumerate(files):
        file_result = check_file(f, expected_columns, filename_pattern, header_mode)
        if i == 0:
            file_result.is_reference = True
            reference_columns = file_result.colonnes_detectees
            reference_encoding = file_result.encodage_detecte
        else:
            if reference_columns and file_result.colonnes_detectees:
                ref_set = {c.lower() for c in reference_columns}
                det_set = {c.lower() for c in file_result.colonnes_detectees}
                if ref_set != det_set:
                    missing = sorted(ref_set - det_set)
                    extra = sorted(det_set - ref_set)
                    msg = f"Structure differente du 1er fichier du dossier ({reference_filename})"
                    if missing:
                        msg += f" — colonne(s) manquante(s) : {missing}"
                    if extra:
                        msg += f" — colonne(s) en plus : {extra}"
                    file_result.errors.append(msg)
            if reference_encoding and file_result.encodage_detecte and file_result.encodage_detecte != reference_encoding:
                file_result.errors.append(
                    f"Encodage different du 1er fichier du dossier ({reference_filename}, "
                    f"{reference_encoding}) : ce fichier est en {file_result.encodage_detecte}"
                )
        result.files.append(file_result)

    return result

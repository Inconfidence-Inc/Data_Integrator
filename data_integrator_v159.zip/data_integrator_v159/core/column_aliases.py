"""
column_aliases.py
-------------------
Dictionnaire persistant de correspondances entre un nom de colonne source
(dans n'importe quelle langue/convention, ex: 'police_number') et le nom
canonique de la colonne cible reelle (ex: 'Numéro_Police'), utilise en
complement de l'association automatique par nom normalise du mapping
Fusion (V76).

Sans ce dictionnaire, une colonne anglaise comme 'police_number' ne peut
jamais s'associer automatiquement a 'Numéro_Police' (aucune ressemblance de
caracteres apres normalisation), meme si elles representent exactement la
meme donnee — chaque colonne anglaise demanderait un rapprochement manuel
systematique. Le dictionnaire se construit progressivement, a la demande de
l'utilisateur, au fur et a mesure des correspondances rencontrees.
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import asdict, dataclass
from pathlib import Path

from core.app_paths import resolve_config_path

DEFAULT_PATH = resolve_config_path("column_aliases.json")


def _normalize_key(name: str) -> str:
    """Meme logique de normalisation que fusion_tab._normalize, dupliquee
    ici pour eviter une dependance circulaire entre core/ et ui/."""
    sans_accents = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]", "", sans_accents.lower())


@dataclass
class ColumnAlias:
    alias: str        # nom source tel que saisi par l'utilisateur (ex: 'police_number')
    cible: str         # nom canonique exact de la colonne cible (ex: 'Numéro_Police')


class ColumnAliasManager:
    def __init__(self, path: Path | str = DEFAULT_PATH, log_cb=None):
        self.path = Path(path)
        self.log_cb = log_cb
        self.aliases: list[ColumnAlias] = []
        self.propositions: list[ColumnAlias] = []
        self.load()

    def load(self) -> None:
        # V141 : synchronise integralement ce fichier si une version plus
        # recente du dictionnaire est fournie avec l'application.
        from core.app_paths import sync_generated_config_if_newer
        sync_generated_config_if_newer(self.path, "column_aliases.json", self.log_cb)

        if not self.path.exists():
            self.aliases = []
            self.propositions = []
            return

        # Filet de securite (V99, corrige V100) : seule la cle "aliases"
        # est completee si vide, jamais "propositions" qui pourrait deja
        # contenir de vraies suggestions en attente de revue.
        from core.app_paths import backfill_key_if_empty
        backfill_key_if_empty(self.path, "column_aliases.json", "aliases")

        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.aliases = [ColumnAlias(**a) for a in data.get("aliases", [])]
            self.propositions = [ColumnAlias(**a) for a in data.get("propositions", [])]
            self._version = data.get("_version", 0)
        except Exception:
            self.aliases = []
            self.propositions = []
            self._version = 0

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "aliases": [asdict(a) for a in self.aliases],
            "propositions": [asdict(a) for a in self.propositions],
            "_version": getattr(self, "_version", 0),  # V141 : preserve tel quel a la sauvegarde locale
        }
        self.path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def add(self, alias: str, cible: str) -> None:
        alias, cible = alias.strip(), cible.strip()
        if not alias or not cible:
            return
        # Remplace une eventuelle correspondance existante pour ce meme alias
        self.aliases = [a for a in self.aliases if _normalize_key(a.alias) != _normalize_key(alias)]
        self.aliases.append(ColumnAlias(alias=alias, cible=cible))
        self.save()

    def remove(self, alias: str) -> None:
        self.aliases = [a for a in self.aliases if a.alias != alias]
        self.save()

    def add_proposition(self, alias: str, cible: str) -> None:
        """Ajoute une correspondance SUGGEREE (V80), jamais utilisee par
        resolve() tant qu'elle n'a pas ete explicitement acceptee — a
        utiliser pour des correspondances devinees par deduction
        semantique, sans confirmation directe (ex: capture d'ecran reelle),
        pour ne jamais risquer de fausser un mapping sur une simple
        supposition."""
        alias, cible = alias.strip(), cible.strip()
        if not alias or not cible:
            return
        if any(_normalize_key(a.alias) == _normalize_key(alias) for a in self.aliases):
            return  # deja confirmee, pas besoin de la re-proposer
        self.propositions = [p for p in self.propositions if _normalize_key(p.alias) != _normalize_key(alias)]
        self.propositions.append(ColumnAlias(alias=alias, cible=cible))
        self.save()

    def accept_proposition(self, alias: str) -> None:
        prop = next((p for p in self.propositions if p.alias == alias), None)
        if not prop:
            return
        self.propositions = [p for p in self.propositions if p.alias != alias]
        self.add(prop.alias, prop.cible)  # add() appelle deja save()

    def reject_proposition(self, alias: str) -> None:
        self.propositions = [p for p in self.propositions if p.alias != alias]
        self.save()

    def resolve(self, colonne_source: str) -> str | None:
        """Retourne le nom de colonne cible canonique correspondant a cette
        colonne source, si une correspondance CONFIRMEE existe dans le
        dictionnaire (comparaison normalisee : casse/espaces/accents
        ignores), sinon None. Les propositions non encore validees ne sont
        JAMAIS utilisees ici."""
        cle = _normalize_key(colonne_source)
        for a in self.aliases:
            if _normalize_key(a.alias) == cle:
                return a.cible
        return None

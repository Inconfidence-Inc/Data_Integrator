"""
db_optimize.py
---------------
Optimisation des insertions en masse sur SQL Server : desactive temporairement
les objets qui ralentissent les chargements volumineux (index NON CLUSTERED,
triggers, contraintes de cle etrangere/CHECK), puis les reactive une fois le
chargement termine.

Principe :
    - Un index CLUSTERED n'est JAMAIS desactive : le desactiver rendrait la
      table totalement inaccessible (meme en insertion). Seuls les index
      NON CLUSTERED sont concernes.
    - Les triggers et contraintes sont desactives puis reactives sans
      reconstruction necessaire (contrairement aux index).
    - Les index desactives sont reconstruits (REBUILD) a la reactivation :
      un index desactive ne redevient pas utilisable par un simple "enable",
      il doit etre reconstruit.
    - Chaque etape est protegee individuellement (try/except + log) : un
      manque de permission ou une table sans objet a optimiser ne bloque
      jamais le chargement, au pire l'optimisation est simplement ignoree.

A utiliser en paire, systematiquement dans un bloc try/finally :
    state = disable_for_bulk_load(engine, schema, table, log_cb)
    try:
        ... inserts ...
    finally:
        restore_after_bulk_load(engine, state, log_cb)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

from sqlalchemy import text
from sqlalchemy.engine import Engine

LogCallback = Callable[[str, str], None]


@dataclass
class TableOptimizationState:
    schema: str
    table_name: str
    disabled_indexes: list[str] = field(default_factory=list)
    triggers_disabled: bool = False
    constraints_disabled: bool = False

    @property
    def full_name(self) -> str:
        return f"[{self.schema}].[{self.table_name}]"


def disable_for_bulk_load(
    engine: Engine, schema: str, table_name: str, log_cb: Optional[LogCallback] = None,
) -> TableOptimizationState:
    """
    A appeler une seule fois, avant la premiere insertion dans la table.
    Desactive les index non-clusters, les triggers et les contraintes pour
    accelerer les INSERT en masse qui suivent.
    """
    state = TableOptimizationState(schema=schema, table_name=table_name)

    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    full_name = state.full_name

    # -- Index non-clusters --------------------------------------------
    try:
        with engine.connect() as conn:
            rows = conn.execute(
                text(
                    "SELECT i.name FROM sys.indexes i "
                    "WHERE i.object_id = OBJECT_ID(:full_name) "
                    "AND i.type = 2 AND i.is_disabled = 0 AND i.name IS NOT NULL"
                ),
                {"full_name": f"{schema}.{table_name}"},
            ).fetchall()
        index_names = [r[0] for r in rows]

        if index_names:
            with engine.begin() as conn:
                for idx in index_names:
                    conn.execute(text(f"ALTER INDEX [{idx}] ON {full_name} DISABLE"))
            state.disabled_indexes = index_names
            log("info", f"  [optim] {len(index_names)} index non-cluster desactive(s) sur {full_name} : {index_names}")
    except Exception as e:
        log("warning", f"  [optim] Impossible de desactiver les index sur {full_name} : {e}")

    # -- Triggers ---------------------------------------------------------
    try:
        with engine.begin() as conn:
            conn.execute(text(f"DISABLE TRIGGER ALL ON {full_name}"))
        state.triggers_disabled = True
        log("info", f"  [optim] Triggers desactives sur {full_name}")
    except Exception as e:
        log("warning", f"  [optim] Impossible de desactiver les triggers sur {full_name} : {e}")

    # -- Contraintes FK / CHECK -------------------------------------------
    try:
        with engine.begin() as conn:
            conn.execute(text(f"ALTER TABLE {full_name} NOCHECK CONSTRAINT ALL"))
        state.constraints_disabled = True
        log("info", f"  [optim] Contraintes (FK/CHECK) desactivees sur {full_name}")
    except Exception as e:
        log("warning", f"  [optim] Impossible de desactiver les contraintes sur {full_name} : {e}")

    return state


def restore_after_bulk_load(
    engine: Engine, state: TableOptimizationState, log_cb: Optional[LogCallback] = None,
) -> None:
    """
    A appeler systematiquement (meme en cas d'erreur, via un bloc finally)
    une fois le chargement de la table termine : reconstruit les index
    desactives et reactive triggers/contraintes.
    """
    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    full_name = state.full_name

    if state.disabled_indexes:
        try:
            with engine.begin() as conn:
                for idx in state.disabled_indexes:
                    conn.execute(text(f"ALTER INDEX [{idx}] ON {full_name} REBUILD"))
            log("info", f"  [optim] {len(state.disabled_indexes)} index reconstruit(s) sur {full_name}")
        except Exception as e:
            log("error", f"  [optim] Echec de reconstruction des index sur {full_name} : {e}")

    if state.triggers_disabled:
        try:
            with engine.begin() as conn:
                conn.execute(text(f"ENABLE TRIGGER ALL ON {full_name}"))
            log("info", f"  [optim] Triggers reactives sur {full_name}")
        except Exception as e:
            log("error", f"  [optim] Echec de reactivation des triggers sur {full_name} : {e}")

    if state.constraints_disabled:
        try:
            with engine.begin() as conn:
                conn.execute(text(f"ALTER TABLE {full_name} WITH CHECK CHECK CONSTRAINT ALL"))
            log("info", f"  [optim] Contraintes revalidees et reactivees sur {full_name}")
        except Exception as e:
            log("error", f"  [optim] Echec de reactivation des contraintes sur {full_name} : {e}")

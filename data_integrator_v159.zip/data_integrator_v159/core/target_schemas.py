"""
target_schemas.py
-------------------
Structures REELLES des tables de destination finales (transformees) pour
chaque domaine — les vraies colonnes cible du mapping Fusion, a ne pas
confondre avec les colonnes d'une table source TPA individuelle.

DEFAULT_TARGET_SCHEMAS ci-dessous sert de valeur de depart (confirmee par
l'utilisateur en V74), mais la structure REELLEMENT utilisee par
l'application est geree par TargetSchemaManager, persistee dans
config/target_schemas.json et modifiable directement depuis l'interface
(V78, coller une requete SQL SELECT ... FROM ...) sans jamais necessiter de
modification du code.
"""

from __future__ import annotations

DEFAULT_TARGET_SCHEMAS: dict[str, list[str]] = {
    "Adhesion": [
        "ID_Adhesion", "Numéro_Police", "Libellé_Distributeur", "Libellé_Produit",
        "Numéro_Adhésion", "Numéro_Extension", "Date_Souscription_Adhésion",
        "Date_Prise_Effet_Résiliation", "Motif_Résiliation", "Statut_Adhésion",
        "Date_Achat_Bien_Garanti", "Date_Evénement",
        "Critère_Identification_Bien_Garanti_1", "Critère_Identification_Bien_Garanti_2",
        "Critère_Identification_Bien_Garanti_3", "Critère_Identification_Bien_Garanti_4",
        "Critère_Identification_Bien_Garanti_5", "Critère_Identification_Bien_Garanti_6",
        "Critère_Tarifaire_1", "Critère_Tarifaire_2", "Critère_Tarifaire_3", "Critère_Tarifaire_4",
        "Valeur_Achat", "Canal_Adhésion", "Nom_Magasin", "Date_Activation",
        "Période_Bordereau_Cotisation", "Période_Bordereau_Résiliation", "SKU",
        "Date_Début_Garantie", "Date_Fin_Garantie_Théorique", "Statut_Adhésion_2",
        "TVA_Gestionnaire", "Qualité_Client", "Nom_Client", "Prénom_Client",
        "Numéro_Rue_Client", "Code_Postal_Client", "Ville_Client", "Pays_Client",
        "Numéro_Identification_Client", "Devise", "Nom_Fichier_Source",
        "Police_Dans_Nom_Fichier_Source", "Année_Data", "Mois_Data", "Date_Integration",
        "A_Controler", "ID_RGPD", "Date_De_Naissance_Client", "Sexe_Client",
        "Telephone_Client", "Email_Client", "Type_Adresse_Client",
        "Date_Demande_Résiliation", "Civilité_Client", "Statut_Ligne",
        "Date_Prise_Effet_Annulée_Terminée", "Motif_Terminée", "Date_Modification_Client",
        "Date_Modification_Offre", "Date_Dernier_Paiement", "Critère_Tarifaire_5",
        "Valeur_Catalogue", "Montant_Occurence_Prélevée_TTC",
        "Montant_Total_Historique_Prélevé_TTC", "MONTANT_TOTAL_TAXES_1",
        "MONTANT_TOTAL_TAXES_2", "REMBOURSEMENT_TOTAL_COMPAGNIE",
        "Lieu_de_Naissance_Client", "Pays_de_Naissance_Client", "Date_Extraction",
        "Ordre_Théorique_Paiement", "Ordre_Dernier_Paiement", "Nombre_de_Paiement",
        "Motif_Paiement", "MONTANT_TOTAL_AUTRES_COMMISSIONS_1",
        "MONTANT_TOTAL_AUTRES_COMMISSIONS_2", "MONTANT_TOTAL_AUTRES_COMMISSIONS_3",
        "MONTANT_TOTAL_COMMISSION_DISTRIBUTEUR", "MONTANT_TOTAL_FRAIS_GESTION",
        "MONTANT_TOTAL_HT", "MONTANT_TOTAL_NET_COMPAGNIE", "MONTANT_TOTAL_TAXES",
        "MONTANT_TOTAL_TTC",
    ],
    "Sinistre": [
        "ID_Sinistre", "Flux", "Gestionnaire", "Assureur", "Numéro_Police",
        "Libellé_Distributeur", "Numéro_Dossier", "Libellé_Garantie", "Numéro_Adhésion",
        "Numéro_Extension", "Date_Souscription_Adhésion", "Date_Achat_Bien_Garanti",
        "Critère_Identification_Bien_Garanti_1", "Critère_Identification_Bien_Garanti_2",
        "Critère_Identification_Bien_Garanti_3", "Critère_Identification_Bien_Garanti_4",
        "Critère_Identification_Bien_Garanti_5", "Critère_Identification_Bien_Garanti_6",
        "Critère_Tarifaire_1", "Critère_Tarifaire_2", "Critère_Tarifaire_3", "Critère_Tarifaire_4",
        "Canal_Adhésion", "Nom_Magasin", "Date_Activation", "Date_Déclaration",
        "Date_Survenance", "Date_Evénement", "Statut_Technique_Sinistre",
        "Type_Indemnisation", "Critère_Identification_Bien_Remplacement_1",
        "Critère_Identification_Bien_Remplacement_2", "Motif_Refus",
        "Montant_Indemnité_Principale", "Montant_Frais_Annexe", "Montant_Reprise",
        "Montant_Total_Règlement", "Valeur_Achat", "Date_Dernier_Acte", "SKU",
        "Nom_Fichier_Source", "Police_Dans_Nom_Fichier_Source", "Cotisation_TTC",
        "Date_Clôture", "Date_Début_Garantie", "Date_Fin_Garantie",
        "Date_Prise_Effet_Résiliation", "Libellé_Garantie_2", "Libellé_Produit",
        "Montant_Diagnostic", "Montant_Franchise", "Montant_Main_D_Oeuvre",
        "Montant_Pièces", "Montant_Transport", "Montant_Remise_Fournisseur",
        "Nombre_Sinistres", "Nombre_Sinistres_Total", "Statut_Technique_Sinistre_2",
        "Montant_Indemnité_Brute", "Qualité_Client", "Nom_Client", "Prénom_Client",
        "Numéro_Rue_Client", "Code_Postal_Client", "Ville_Client", "Pays_Client",
        "Numéro_Client", "Retraitement_Code_client", "Date_Extraction", "Devise",
        "Taxes", "Cotisation_HT", "Commission_Distributeur", "Prime_Assureur",
        "FIC_Clé", "FIC_Option", "FIC_Date_Règlement", "FIC_Période_Règlement",
        "FIC_Nature", "FIC_Fournisseur", "FIC_Motif_Règlement", "FIC_Nombre_Règlement",
        "FIC_Numéro_Facture", "Statut_tech_dossier", "Statut_compta_ligne",
        "Statut_compta_dossier", "Période_Certification_ICI", "Beneficiaire_Charge",
        "Annee_Data", "Mois_Data", "Date_Integration", "A_Controler", "Ordre",
        "Statut_compta_durée", "Fic_Existant", "FIC_Montant_Règlement", "ID_RGPD",
        "Valeur_Catalogue", "Date_De_Naissance_Client", "Sexe_Client",
        "Telephone_Client", "Email_Client", "Type_Adresse_Client", "Civilité_Client",
        "Pays_De_Naissance_Client", "Type_Indemnisation_2",
        "Numéro_Identification_Client", "Commission_Gestionnaire",
        "Commission_Courtier_1", "Commission_Courtier_2", "Commission_Courtier_3",
        "Centre_De_Réparation", "Date_Réception_Bien", "Date_Décision", "row_number",
    ],
    "FIC": [
        "Flux", "Gestionnaire", "Assureur", "Numéro_Police", "Libellé_Distributeur",
        "Numéro_Dossier", "Libellé_Garantie", "Numéro_Adhésion", "Numéro_Extension",
        "Date_Souscription_Adhésion", "Date_Achat_Bien_Garanti",
        "Critère_Identification_Bien_Garanti_1", "Critère_Identification_Bien_Garanti_2",
        "Critère_Identification_Bien_Garanti_3", "Critère_Identification_Bien_Garanti_4",
        "Critère_Identification_Bien_Garanti_5", "Critère_Identification_Bien_Garanti_6",
        "Critère_Tarifaire_1", "Critère_Tarifaire_2", "Critère_Tarifaire_3", "Critère_Tarifaire_4",
        "Canal_Adhésion", "Nom_Magasin", "Date_Activation", "Date_Déclaration",
        "Date_Survenance", "Date_Evénement", "Statut_Technique_Sinistre",
        "Statut_Sogedep", "Type_Indemnisation", "Critère_Identification_Bien_Remplacement_1",
        "Critère_Identification_Bien_Remplacement_2", "Motif_Refus",
        "Montant_Indemnité_Principale", "Montant_Frais_Annexe", "Montant_Reprise",
        "Montant_Total_Règlement", "Valeur_Achat", "Date_Dernier_Acte", "SKU",
        "Nom_Fichier_Source", "Police_Dans_Nom_Fichier_Source", "Cotisation_TTC",
        "Date_Clôture", "Date_Début_Garantie", "Date_Fin_Garantie",
        "Date_Prise_Effet_Résiliation", "Libellé_Garantie_2", "Libellé_Produit",
        "Montant_Diagnostic", "Montant_Franchise", "Montant_Main_D_Oeuvre",
        "Montant_Pièces", "Montant_Total_Règlement_FR", "Montant_Transport",
        "Montant_Remise_Fournisseur", "Nombre_Sinistres", "Nombre_Sinistres_Total",
        "Statut_Technique_Sinistre_2", "TVA_FR", "Montant_Indemnité_Brute",
        "Montant_Remplacement", "Qualité_Client", "Nom_Client", "Prénom_Client",
        "Numéro_Rue_Client", "Code_Postal_Client", "Ville_Client", "Pays_Client",
        "Numéro_Client", "Code_Client", "Retraitement_Code_client", "Type_Bordereau",
        "Date_Extraction", "Devise", "Indemnity_Payments", "Indemnisation_Client",
        "Frais_Station_Technique", "Taxes", "Cotisation_HT", "Commission_Distributeur",
        "Commission_Intermediaire", "Prime_Assureur", "FIC_Clé", "FIC_Option",
        "FIC_Date_Règlement", "FIC_Période_Règlement", "FIC_Nature", "FIC_Fournisseur",
        "FIC_Motif_Règlement", "FIC_Nombre_Règlement", "FIC_Numéro_Facture",
        "Statut_tech_dossier", "Statut_compta_ligne", "Statut_compta_dossier",
        "Période_Certification_ICI", "Beneficiaire_Charge", "Annee_Data", "Mois_Data",
        "Date_Integration", "A_Controler", "Date_Décision", "Ordre",
        "Statut_compta_durée", "Resultat", "ID_Sinistre_Comptable",
        "ID_Sinistre_Technique", "controle",
    ],
}


import json
import re
from pathlib import Path

from core.app_paths import resolve_config_path

DEFAULT_CONFIG_PATH = resolve_config_path("target_schemas.json")


def parse_sql_select_columns(sql_text: str) -> list[str]:
    """
    Extrait la liste des noms de colonnes, dans l'ordre, depuis un texte de
    requete SQL Server de la forme :

        SELECT  [Colonne_1]
              ,[Colonne_2]
              ,[Colonne_3]
          FROM [Base].[dbo].[Table]

    (V78). Recherche d'abord les identifiants entre crochets `[...]` dans la
    portion SELECT ... FROM (methode la plus fiable pour du SQL Server
    genere par SSMS, "Script Table as SELECT"). A defaut d'aucun crochet
    trouve, retombe sur un simple decoupage par virgules (au cas ou la
    requete est ecrite sans crochets), en ignorant un eventuel alias
    "AS ..." ou une qualification "table.colonne" (ne garde que le dernier
    segment). Leve ValueError si aucune colonne n'a pu etre identifiee, avec
    un message explicite plutot que de retourner une liste vide en silence.
    """
    texte = sql_text.strip()
    if not texte:
        raise ValueError("Aucun texte fourni.")

    match_from = re.search(r"\bFROM\b", texte, flags=re.IGNORECASE)
    match_select = re.search(r"\bSELECT\b", texte, flags=re.IGNORECASE)

    if not match_select and "[" not in texte:
        # Ni mot-cle SELECT, ni le moindre crochet : ce texte n'a
        # vraisemblablement rien a voir avec une requete SQL SELECT ... FROM,
        # mieux vaut le signaler clairement plutot que d'interpreter le
        # texte entier comme une unique colonne (repli par virgules trop
        # permissif sinon).
        raise ValueError(
            "Ce texte ne ressemble pas a une requete SQL (aucun mot-cle SELECT ni crochet [...] trouve). "
            "Colle une requete de la forme : SELECT [Colonne1], [Colonne2] FROM [Table]."
        )

    if match_select and match_from and match_from.start() > match_select.end():
        portion = texte[match_select.end():match_from.start()]
    elif match_from:
        portion = texte[:match_from.start()]
    else:
        portion = texte  # pas de FROM trouve : on tente sur tout le texte

    colonnes_crochets = re.findall(r"\[([^\[\]]+)\]", portion)
    if colonnes_crochets:
        # DISTINCT / TOP N eventuels ne sont jamais entre crochets, donc pas
        # de risque de les recuperer par erreur ici.
        return colonnes_crochets

    # Repli : decoupage par virgules, sans crochets.
    fragments = [f.strip() for f in portion.split(",") if f.strip()]
    colonnes = []
    for frag in fragments:
        frag = re.sub(r"\bAS\b.*$", "", frag, flags=re.IGNORECASE).strip()
        dernier_segment = frag.split(".")[-1].strip()
        dernier_segment = dernier_segment.strip("[]\"` ")
        if dernier_segment:
            colonnes.append(dernier_segment)

    if not colonnes:
        raise ValueError("Aucune colonne n'a pu etre identifiee dans ce texte (verifie qu'il s'agit bien d'un SELECT ... FROM).")
    return colonnes


class TargetSchemaManager:
    """
    Gere la structure REELLEMENT utilisee par l'application pour les
    colonnes cible de chaque domaine (V78) : persistee dans
    config/target_schemas.json, initialisee a partir de
    DEFAULT_TARGET_SCHEMAS au tout premier lancement, et modifiable ensuite
    directement depuis l'interface (coller une requete SQL) sans jamais
    necessiter de modification du code — contrairement a
    DEFAULT_TARGET_SCHEMAS qui reste fige tel que livre."""

    def __init__(self, path: Path | str = DEFAULT_CONFIG_PATH, log_cb=None):
        self.path = Path(path)
        self.log_cb = log_cb
        self.schemas: dict[str, list[str]] = {}
        self.load()

    def load(self) -> None:
        # V141 : synchronise integralement ce fichier si une version plus
        # recente de la structure cible est fournie avec l'application.
        from core.app_paths import sync_generated_config_if_newer
        sync_generated_config_if_newer(self.path, "target_schemas.json", self.log_cb)

        if not self.path.exists():
            self.schemas = {k: list(v) for k, v in DEFAULT_TARGET_SCHEMAS.items()}
            self.save()
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.schemas = data.get("schemas", {})
            self._version = data.get("_version", 0)
            if not self.schemas:
                self.schemas = {k: list(v) for k, v in DEFAULT_TARGET_SCHEMAS.items()}
        except Exception:
            self.schemas = {k: list(v) for k, v in DEFAULT_TARGET_SCHEMAS.items()}
            self._version = 0

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # V141 : le champ _version est prserve tel quel lors d'une
        # sauvegarde locale (une modification manuelle via l'application
        # ne doit pas pretendre etre une nouvelle version officielle du
        # mapping fourni).
        contenu = {"schemas": self.schemas, "_version": getattr(self, "_version", 0)}
        self.path.write_text(json.dumps(contenu, ensure_ascii=False, indent=2), encoding="utf-8")

    def get_schema(self, domaine: str) -> list[str]:
        return self.schemas.get(domaine, [])

    def set_schema(self, domaine: str, colonnes: list[str]) -> None:
        self.schemas[domaine] = list(colonnes)
        self.save()

    def set_schema_from_sql(self, domaine: str, sql_text: str) -> list[str]:
        """Analyse le texte SQL fourni et met a jour la structure du
        domaine ; retourne la liste des colonnes extraites (utile pour
        preview avant confirmation cote interface)."""
        colonnes = parse_sql_select_columns(sql_text)
        self.set_schema(domaine, colonnes)
        return colonnes

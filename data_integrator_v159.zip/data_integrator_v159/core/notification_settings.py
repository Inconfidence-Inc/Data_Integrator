"""
notification_settings.py
--------------------------
Parametres persistants pour les notifications automatiques (V71) : pour
l'instant, uniquement l'envoi ou non d'un mail a la DSI a l'issue de chaque
TPA charge, avec le detail du traitement.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from core.app_paths import resolve_config_path

DEFAULT_PATH = resolve_config_path("notification_settings.json")


@dataclass
class NotificationSettings:
    mail_dsi_apres_chargement: bool = False


class NotificationSettingsManager:
    def __init__(self, path: Path | str = DEFAULT_PATH):
        self.path = Path(path)
        self.settings = NotificationSettings()
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.settings = NotificationSettings(**{
                k: v for k, v in data.items() if k in NotificationSettings.__dataclass_fields__
            })
        except Exception:
            self.settings = NotificationSettings()

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(asdict(self.settings), ensure_ascii=False, indent=2), encoding="utf-8")

    def set_mail_dsi_apres_chargement(self, value: bool) -> None:
        self.settings.mail_dsi_apres_chargement = value
        self.save()

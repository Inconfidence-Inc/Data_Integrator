"""
integration_history.py
------------------------
Alimentation automatique de la table ADM_Fichiers_Integres (deja existante
dans TECH_BI) : a chaque fichier integre avec succes, une ligne est inseree
avec le nom du fichier, le flux (TPA), le nombre de lignes de ce fichier, la
police extraite du nom, l'annee/mois de la donnee (extraits du nom du
fichier si presents, sinon annee/mois du jour au moment de l'integration),
et la date d'integration.

Structure reelle de la table (confirmee par l'utilisateur) :
    ID, Nom_Fichier_Source, Flux, Nb_Lignes, Police,
    Annee_Data, Mois_Data, Date_integration
(ID est une colonne auto-incrementee, non fournie a l'insertion.)

Regle d'extraction de la police (V61) : motif ICIDKT + code variable en
lettres + 2 chiffres + 2 lettres (pays), ex: ICIDKTDM24IT, ICIDKTLADV24ES,
ICIDKTLJD24BE. Regle generique, identique pour tous les TPA.

Regle d'extraction annee/mois (V61) : recherche d'une date a 8 chiffres
(AAAAMMJJ, ex: 20260303) ou a 6 chiffres (AAAAMM, ex: 202608) dans le nom du
fichier ; si aucune des deux n'est trouvee, utilise l'annee et le mois du
jour au moment de l'integration.
"""

from __future__ import annotations

import re
from datetime import datetime

from sqlalchemy import text
from sqlalchemy.engine import Engine

# Nom exact de la table d'historique, deja existante dans TECH_BI.
INTEGRATION_HISTORY_TABLE = "[dbo].[ADM_Fichiers_Intégrés]"

_POLICE_PATTERN = re.compile(r"ICIDKT[A-Z]+\d{2}[A-Z]{2}", re.IGNORECASE)
_DATE_8_PATTERN = re.compile(r"(20\d{2})(\d{2})(\d{2})")  # AAAAMMJJ
_DATE_6_PATTERN = re.compile(r"(20\d{2})(\d{2})(?!\d)")   # AAAAMM (pas suivi d'un 3e chiffre)


def extract_police_from_filename(filename: str) -> str | None:
    """Extrait le numero de police du nom de fichier (motif ICIDKT...),
    ou None si le motif n'est pas trouve."""
    match = _POLICE_PATTERN.search(filename)
    return match.group(0) if match else None


def extract_annee_mois_from_filename(filename: str) -> tuple[int, int]:
    """
    Extrait l'annee et le mois de la donnee depuis le nom du fichier :
    cherche d'abord une date AAAAMMJJ (8 chiffres), puis AAAAMM (6 chiffres).
    Si aucune des deux n'est trouvee, ou si le mois extrait n'est pas valide
    (01-12), retombe sur l'annee et le mois du jour (au moment de l'appel).
    """
    match8 = _DATE_8_PATTERN.search(filename)
    if match8:
        annee, mois = int(match8.group(1)), int(match8.group(2))
        if 1 <= mois <= 12:
            return annee, mois

    match6 = _DATE_6_PATTERN.search(filename)
    if match6:
        annee, mois = int(match6.group(1)), int(match6.group(2))
        if 1 <= mois <= 12:
            return annee, mois

    today = datetime.now()
    return today.year, today.month


def record_integration_history(
    engine: Engine, filename: str, nb_lignes: int, flux: str = "", log_cb=None,
) -> None:
    """
    Insere une ligne dans ADM_Fichiers_Integres pour ce fichier. Echec
    journalise mais jamais bloquant : cette table est un historique auxiliaire,
    son indisponibilite ne doit jamais faire echouer le chargement reel des
    donnees dans la table cible.
    """
    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    police = extract_police_from_filename(filename)
    annee, mois = extract_annee_mois_from_filename(filename)

    try:
        query = text(
            f"INSERT INTO {INTEGRATION_HISTORY_TABLE} "
            "(Nom_Fichier_Source, Flux, Nb_Lignes, Police, Année_Data, Mois_Data, Date_intégration) "
            "VALUES (:nom_fichier, :flux, :nb_lignes, :police, :annee, :mois, :date_integration)"
        )
        with engine.begin() as conn:
            conn.execute(query, {
                "nom_fichier": filename,
                "flux": flux,
                "nb_lignes": nb_lignes,
                "police": police,
                "annee": annee,
                "mois": mois,
                "date_integration": datetime.now(),
            })
        if police is None:
            log("warning", f"  [historique] {filename} : police non reconnue dans le nom (motif ICIDKT... absent) — enregistree avec police vide.")
    except Exception as e:
        log("warning", f"  [historique] Echec de l'enregistrement dans {INTEGRATION_HISTORY_TABLE} pour {filename} : {e}")

"""
contract_status_config.py
---------------------------
Configuration, par table cible, de la colonne de statut de contrat et des
valeurs correspondant a "actif" / "resilie" — necessaire pour l'ecran
statistique (V59), puisque le nom de cette colonne et ses valeurs possibles
varient d'une table a l'autre et ne sont pas connus a l'avance.

Tant qu'une table n'est pas configuree ici, l'ecran statistique affiche
"Non configure" pour cette table plutot que de deviner un nom de colonne au
hasard (risque de resultats faux et trompeurs).
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class ContractStatusRule:
    table: str
    colonne_statut: str
    valeurs_actif: list[str] = field(default_factory=list)
    valeurs_resilie: list[str] = field(default_factory=list)


class ContractStatusConfigManager:
    def __init__(self, path: str | Path = "config/contract_status_rules.json"):
        self.path = Path(path)
        self.rules: dict[str, ContractStatusRule] = {}
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            self.rules = {}
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.rules = {
                r["table"]: ContractStatusRule(**r)
                for r in data.get("rules", [])
            }
        except Exception:
            self.rules = {}

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"rules": [asdict(r) for r in self.rules.values()]}
        self.path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def get_rule(self, table: str) -> ContractStatusRule | None:
        return self.rules.get(table)

    def set_rule(self, table: str, colonne_statut: str, valeurs_actif: list[str], valeurs_resilie: list[str]) -> None:
        self.rules[table] = ContractStatusRule(
            table=table, colonne_statut=colonne_statut,
            valeurs_actif=valeurs_actif, valeurs_resilie=valeurs_resilie,
        )
        self.save()

    def remove_rule(self, table: str) -> None:
        if table in self.rules:
            del self.rules[table]
            self.save()

    def is_configured(self, table: str) -> bool:
        rule = self.rules.get(table)
        return bool(rule and rule.colonne_statut and (rule.valeurs_actif or rule.valeurs_resilie))

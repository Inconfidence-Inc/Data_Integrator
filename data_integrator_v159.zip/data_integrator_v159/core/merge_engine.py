"""
merge_engine.py
----------------
Fusionne plusieurs tables sources (une par TPA) vers une table cible
consolidee, en appliquant le matching de colonnes defini par l'utilisateur
(core/merge_config.py) dans l'onglet Fusion.

Approche V87 (UNION ALL, fidele au principe SSIS Union All Transformation
reproduit dans l'ecran) : une seule requete combinee est executee,
    INSERT INTO cible (colonnes_cibles)
    SELECT ... FROM table_source_1
    UNION ALL
    SELECT ... FROM table_source_2
    UNION ALL
    ...
plutot que plusieurs requetes INSERT separees (approche V5-V86). Chaque
sous-SELECT fournit une valeur pour TOUTES les colonnes cible dans le meme
ordre (NULL explicite pour celles que ce TPA ne mappe pas), avec une colonne
technique 'source_tpa' pour tracer l'origine de chaque ligne.

Limite connue : les colonnes non mappees pour un TPA restent NULL dans la
table cible pour ses lignes. Le pilotage fin (transformations, dedup) sera
ajoute dans une prochaine version.
"""

from __future__ import annotations

import re
import time
import unicodedata
from dataclasses import dataclass, field
from typing import Callable, Optional

from sqlalchemy import text
from sqlalchemy.engine import Engine

from core.db import get_existing_columns
from core.merge_config import MatchingRule
from core.value_aliases import ValueAliasManager

LogCallback = Callable[[str, str], None]


@dataclass
class MergeResult:
    domaine: str
    target_table: str
    total_rows: int = 0
    tpa_results: dict = field(default_factory=dict)  # "type_tpa (table_source)" -> nb lignes
    errors: list[tuple[str, str]] = field(default_factory=list)
    elapsed_seconds: float = 0.0
    sql_executed: str = ""  # derniere requete UNION ALL executee (V87), pour diagnostic/reexecution manuelle

    @property
    def success(self) -> bool:
        return not self.errors


def _split_schema_table(table: str) -> tuple[str, str]:
    return table.split(".", 1) if "." in table else ("dbo", table)


def _cle_colonne(nom: str) -> str:
    """Cle de comparaison insensible a la casse pour un nom de colonne
    cible. SQL Server traite les noms de colonnes sans distinction de casse
    (collation par defaut) : deux graphies differentes du meme nom (ex:
    'Date_naissance_Client' et 'Date_Naissance_Client') provoquent sinon
    l'erreur 'Column names in each table must be unique' a la creation de la
    table de fusion — cas reel rencontre par l'utilisateur en V153, la
    duplication pouvant venir soit de la structure cible officielle
    (target_schemas.json), soit de deux regles de matching.json isolees
    utilisant chacune une casse differente pour la meme colonne cible."""
    return nom.strip().lower()


def _cle_source(nom: str) -> str:
    """V158, suite a une erreur reelle en production (fusion SPB Espagne :
    TOUTES les colonnes ressortaient NULL, sauf la colonne technique
    source_tpa) : la comparaison entre la colonne_source configuree dans
    matching.json et les colonnes reellement presentes dans la table source
    etait jusqu'ici exacte (sensible a la casse ET aux accents). Des que la
    graphie configuree differait meme legerement de la graphie reelle en
    base (ex: 'Numero_Police' configure vs 'numéro_police' reel), la colonne
    etait silencieusement ecartee (un simple avertissement, pas une erreur
    bloquante) et la cible correspondante restait NULL pour tout le TPA
    concerne. Sur instruction explicite de l'utilisateur ("il faut respecter
    le mapping que je t'ai envoye") : plutot que de corriger au cas par cas
    la casse/accentuation de chaque mapping (comme en V153, au risque de
    devoir recommencer a chaque nouvelle table), la correspondance
    colonne_source -> colonne reelle est desormais TOUJOURS normalisee
    (insensible a la casse ET aux accents, comme le referentiel de valeurs
    de core/value_aliases.py), afin que le mapping fourni fonctionne tel
    quel quelle que soit la graphie exacte utilisee cote base."""
    s = unicodedata.normalize("NFKD", nom.strip()).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-zA-Z0-9]+", "_", s).strip("_").lower()


def _resolveur_colonnes_sources(colonnes_reelles) -> dict[str, str]:
    """Associe a chaque colonne REELLEMENT presente dans une table source
    (quelle que soit sa casse/accentuation) sa cle normalisee (_cle_source),
    pour retrouver la graphie exacte a utiliser dans le SQL genere a partir
    de la colonne_source configuree dans matching.json (potentiellement
    ecrite avec une casse ou une accentuation legerement differente)."""
    resolveur: dict[str, str] = {}
    for c in colonnes_reelles:
        resolveur.setdefault(_cle_source(c), c)
    return resolveur


def _resolveur_colonnes_cibles(colonnes_officielles: set[str], rules: list) -> dict[str, str]:
    """Associe a chaque colonne cible, quelle que soit la casse rencontree,
    UNE SEULE graphie canonique a utiliser partout dans la fusion (creation
    de table, construction des SELECT, regroupement COALESCE). Priorite a la
    structure cible officielle (target_schemas.json, source de verite) ; a
    defaut (colonne presente uniquement dans une regle de matching.json), la
    premiere graphie rencontree est conservee."""
    resolveur: dict[str, str] = {}
    for c in sorted(colonnes_officielles):
        resolveur.setdefault(_cle_colonne(c), c)
    for r in rules:
        if r.colonne_cible:
            resolveur.setdefault(_cle_colonne(r.colonne_cible), r.colonne_cible)
    return resolveur


def _count_rows(engine: Engine, schema: str, name: str) -> int:
    """Compte le nombre de lignes d'une table source donnee — utilise
    (V113) pour savoir exactement combien de lignes CHAQUE table physique
    contribue a la fusion, de facon fiable meme quand plusieurs tables
    partagent la meme etiquette type_tpa (ex: SPB France + SPB Italie
    fusionnees ensemble)."""
    sql = f"SELECT COUNT(*) FROM [{schema}].[{name}]"
    with engine.connect() as conn:
        return conn.execute(text(sql)).scalar() or 0


def run_merge(
    engine: Engine,
    domaine: str,
    rules: list[MatchingRule],
    target_table: str,
    vider_avant: bool = True,
    log_cb: Optional[LogCallback] = None,
    stop_flag: Optional[Callable[[], bool]] = None,
    sources: Optional[list] = None,
    value_alias_manager: Optional[ValueAliasManager] = None,
) -> MergeResult:
    t_start = time.perf_counter()
    result = MergeResult(domaine=domaine, target_table=target_table)

    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    # V151 : normalisation de VALEURS (ex: Pays_Client — "Fr"/"FR"/"France"
    # tous harmonises en "France"), appliquee cote SQL via une expression
    # CASE WHEN injectee au moment de la construction de chaque SELECT
    # (voir _valeur_sql ci-dessous) — jamais de traitement ligne par ligne
    # en Python, conformement a l'architecture UNION ALL de cette fonction.
    # Instancie ici (et non par l'appelant) pour que la fusion applique
    # TOUJOURS le referentiel le plus a jour, sans dependre de chaque appelant.
    if value_alias_manager is None:
        value_alias_manager = ValueAliasManager(log_cb=log_cb)
    colonnes_avec_referentiel = set(value_alias_manager.columns_with_aliases())
    if colonnes_avec_referentiel:
        log("info", f"Referentiel de normalisation de valeurs actif pour : {', '.join(sorted(colonnes_avec_referentiel))}.")
    # Cle insensible a la casse (voir _cle_colonne) : evite qu'une colonne
    # cible normalisee avec une casse legerement differente (ex: a l'issue
    # de _resolveur_colonnes_cibles ci-dessous) ne soit plus reconnue ici.
    colonnes_avec_referentiel_norm = {_cle_colonne(c) for c in colonnes_avec_referentiel}

    # V114, sur clarification explicite de l'utilisateur : SPB France, SPB
    # Italie, SPB Espagne et SPB Pologne sont des TPA differents (pas de
    # simples variantes d'un meme "SPB"). La colonne technique source_tpa
    # distingue le pays quand il est connu.
    # V137, complement explicite de l'utilisateur : le pays n'est inclus
    # QUE si ce type de TPA a reellement plusieurs variantes pays
    # distinctes (SPB) — pour un type a un seul pays (Evy, Estaly, NEAT,
    # LAPI, GP...), le type seul suffit ("Evy", pas "Evy France").
    from core.config_manager import types_avec_plusieurs_pays, label_tpa
    pays_par_table: dict[tuple[str, str], str] = {}
    types_multi_pays: set[str] = set()
    if sources:
        types_multi_pays = types_avec_plusieurs_pays(sources, domaine)
        for s in sources:
            if s.domaine == domaine and getattr(s, "pays", None):
                pays_par_table[(s.type, s.table)] = s.pays

    def _label_source_tpa(type_tpa: str, table_source: str) -> str:
        pays = pays_par_table.get((type_tpa, table_source), "")
        return label_tpa(type_tpa, pays, types_multi_pays)

    # Les colonnes source ajoutees a une table (autre que la premiere) sans
    # correspondance dans les colonnes cible existantes sont enregistrees
    # avec une colonne_cible vide (V62 — non mappees, jamais promues en
    # nouvelle colonne cible). Elles ne doivent jamais participer a la
    # construction du SQL (colonne vide = syntaxe invalide).
    rules = [r for r in rules if r.colonne_cible]

    if not rules:
        log("error", f"Aucune regle de matching definie pour le domaine {domaine}.")
        result.errors.append(("-", "Aucune regle de matching"))
        return result

    # Regrouper les regles par TABLE PHYSIQUE (type_tpa + table_source), et
    # non par type_tpa seul (V86 — correctif critique) : plusieurs tables
    # distinctes partagent souvent le meme type_tpa (ex: "SPB" existe a la
    # fois pour la France, l'Italie, l'Espagne et la Pologne).
    par_table: dict[tuple[str, str], list[MatchingRule]] = {}
    for r in rules:
        par_table.setdefault((r.type_tpa, r.table_source), []).append(r)

    target_schema, target_name = _split_schema_table(target_table)
    # V144, suite a une question explicite de l'utilisateur (\"ses colonnes
    # sont bien les colonnes cibles ?\") : auparavant, les colonnes de la
    # table recreee provenaient UNIQUEMENT de ce qui etait actuellement
    # mappe dans les regles (matching.json) — une fragilite reelle, car si
    # ce fichier n'est pas encore synchronise (independamment de
    # target_schemas.json), la table se recreait quand meme avec
    # d'anciennes colonnes, meme apres une mise a jour de la structure
    # cible officielle. Desormais, l'UNION des deux est utilisee : la
    # structure cible officielle (target_schemas.json, source de verite)
    # ET toute colonne actuellement mappee qui n'y figurerait pas encore
    # (securite supplementaire, ne perd jamais une colonne en cours
    # d'utilisation) — la table recreee reflete ainsi toujours fidelement
    # la structure cible officielle, quel que soit l'etat de synchronisation
    # du mapping a cet instant precis.
    try:
        from core.target_schemas import TargetSchemaManager
        colonnes_officielles = set(TargetSchemaManager().get_schema(domaine))
    except Exception:
        colonnes_officielles = set()

    # V153, suite a une erreur SQL Server reelle en production ("Column
    # names in each table must be unique") : deux graphies ne differant que
    # par la casse (ex: 'Date_naissance_Client' / 'Date_Naissance_Client')
    # s'etaient glissees entre la structure cible officielle et le mapping,
    # produisant deux colonnes distinctes pour Python/JSON mais une seule
    # pour SQL Server. Desormais, toute colonne cible est ramenee a UNE
    # SEULE graphie canonique avant la creation de table (voir
    # _resolveur_colonnes_cibles) — plus largement, "il faut gerer la
    # casse" sur les noms de colonnes cible dans toute cette fonction.
    resolveur_cibles = _resolveur_colonnes_cibles(colonnes_officielles, rules)
    colonnes_officielles = {resolveur_cibles[_cle_colonne(c)] for c in colonnes_officielles}
    colonnes_mappees = {resolveur_cibles[_cle_colonne(r.colonne_cible)] for r in rules}
    toutes_colonnes_cibles = sorted(colonnes_officielles | colonnes_mappees)

    existing = get_existing_columns(engine, target_schema, target_name)
    if vider_avant or existing is None:
        cols_ddl = ",\n    ".join(f"[{c}] VARCHAR(MAX)" for c in toutes_colonnes_cibles + ["source_tpa"])
        ddl = f"""
        IF OBJECT_ID(N'[{target_schema}].[{target_name}]', N'U') IS NOT NULL
            DROP TABLE [{target_schema}].[{target_name}];
        CREATE TABLE [{target_schema}].[{target_name}] (
            {cols_ddl}
        );
        """
        with engine.begin() as conn:
            conn.execute(text(ddl))
        log("info", f"Table de fusion [{target_schema}].[{target_name}] (re)creee ({len(toutes_colonnes_cibles) + 1} colonnes).")
    else:
        missing = [c for c in toutes_colonnes_cibles + ["source_tpa"] if c not in existing]
        if missing:
            with engine.begin() as conn:
                for c in missing:
                    conn.execute(text(f"ALTER TABLE [{target_schema}].[{target_name}] ADD [{c}] VARCHAR(MAX)"))
            log("info", f"{len(missing)} colonne(s) ajoutee(s) a la table de fusion existante : {missing}")

    # Construction d'UN SEUL SELECT par table source, fournissant une valeur
    # pour CHAQUE colonne cible dans le meme ordre fixe (NULL explicite si
    # ce TPA ne la mappe pas), plus la colonne technique source_tpa. Tous
    # ces SELECT seront ensuite combines par UNION ALL (V87).
    sub_selects: list[str] = []
    tables_incluses: list[tuple[str, str]] = []

    for (type_tpa, table_source), tpa_rules in par_table.items():
        if stop_flag and stop_flag():
            log("warning", "Fusion annulee par l'utilisateur.")
            break

        src_schema, src_name = _split_schema_table(table_source)
        src_cols = get_existing_columns(engine, src_schema, src_name)
        if src_cols is None:
            log("error", f"Table source introuvable pour {type_tpa} : {table_source}")
            result.errors.append((type_tpa, f"Table source introuvable : {table_source}"))
            continue

        # V158 : resolveur colonne_source -> graphie reelle, insensible a la
        # casse ET aux accents (voir _cle_source). Necessaire pour que le
        # mapping fourni par l'utilisateur soit respecte tel quel, meme
        # quand sa graphie exacte differe legerement de celle de la table
        # source reelle (cas reel : SPB Espagne, toutes colonnes NULL).
        resolveur_sources = _resolveur_colonnes_sources(src_cols)

        # V106 : plusieurs colonnes source distinctes peuvent legitimement
        # correspondre a la MEME colonne cible pour une meme table — cas
        # reel rencontre avec SPB France, dont la table melange des lots de
        # fichiers anglais et francais au fil du temps (ex: 'lastname' ET
        # 'nom_client' correspondent tous deux a Nom_Client). Ecraser
        # silencieusement l'un par l'autre (comportement jusqu'ici) faisait
        # perdre les vraies donnees des lignes qui n'avaient de valeur que
        # dans la colonne ecartee. On collecte desormais TOUTES les
        # colonnes source concurrentes par cible, combinees ensuite par
        # COALESCE (V106) : prend la premiere valeur non vide parmi elles.
        mapping_cible_vers_sources: dict[str, list[str]] = {}
        for r in tpa_rules:
            source_reelle = resolveur_sources.get(_cle_source(r.colonne_source))
            if source_reelle is None:
                log("warning", f"  [{type_tpa}] colonne source '{r.colonne_source}' absente de {table_source}, ignoree.")
                continue
            # Ramene a la graphie canonique (voir resolveur_cibles plus haut) :
            # si cette regle utilise une casse differente de celle retenue
            # pour la table de fusion, la contribution doit quand meme
            # rejoindre le bon groupe COALESCE plutot que d'en creer un
            # second, invisible, qui resterait NULL dans toutes_colonnes_cibles.
            cible = resolveur_cibles.get(_cle_colonne(r.colonne_cible), r.colonne_cible)
            mapping_cible_vers_sources.setdefault(cible, [])
            if source_reelle not in mapping_cible_vers_sources[cible]:
                mapping_cible_vers_sources[cible].append(source_reelle)

        for cible, sources_multiples in mapping_cible_vers_sources.items():
            if len(sources_multiples) > 1:
                log("info", f"  [{type_tpa}] '{cible}' combine {len(sources_multiples)} colonnes source concurrentes ({', '.join(sources_multiples)}) via COALESCE.")

        if not mapping_cible_vers_sources:
            log("error", f"Aucune colonne valide a fusionner pour {type_tpa} ({table_source}).")
            result.errors.append((type_tpa, "Aucune colonne source valide"))
            continue

        def _valeur_sql(colonnes_source: list[str]) -> str:
            if len(colonnes_source) == 1:
                return f"[{colonnes_source[0]}]"
            # NULLIF('', '') traite aussi les chaines vides comme "absentes",
            # pas seulement les NULL SQL — plus fidele a la notion de
            # "donnee reellement renseignee" pour des colonnes VARCHAR.
            return "COALESCE(" + ", ".join(f"NULLIF([{c}], '')" for c in colonnes_source) + ")"

        select_values = []
        for c in toutes_colonnes_cibles:
            if c not in mapping_cible_vers_sources:
                select_values.append("NULL")
                continue
            expr = _valeur_sql(mapping_cible_vers_sources[c])
            if _cle_colonne(c) in colonnes_avec_referentiel_norm:
                expr = value_alias_manager.sql_case_expression(c, expr)
            select_values.append(expr)
        label_source_tpa = _label_source_tpa(type_tpa, table_source)
        select_values.append(f"'{label_source_tpa}'")  # source_tpa, distinct par pays si connu (V114)
        sub_selects.append(f"SELECT {', '.join(select_values)} FROM [{src_schema}].[{src_name}]")
        # V113 : compte directement les lignes de CETTE table source avant
        # la fusion — chaque sous-SELECT etant un INSERT inconditionnel
        # (aucun filtre ligne par ligne), ce nombre correspond exactement
        # a ce que cette table va contribuer au total. Cle par table
        # PHYSIQUE (type_tpa, table_source), et non par type_tpa seul, pour
        # ne jamais confondre deux tables partageant le meme type (ex: SPB
        # France + SPB Italie fusionnees dans le meme lancement) — c'est
        # cette confusion qui causait un comptage errone (double, voire
        # plus) dans l'approche precedente (avant/apres par etiquette).
        nb_lignes_source = _count_rows(engine, src_schema, src_name)
        tables_incluses.append((type_tpa, table_source, nb_lignes_source))

    if not sub_selects:
        log("error", "Aucune table source valide a fusionner (toutes exclues ou en erreur).")
        result.elapsed_seconds = time.perf_counter() - t_start
        return result

    insert_cols = ", ".join(f"[{c}]" for c in toutes_colonnes_cibles + ["source_tpa"])
    sql = (
        f"INSERT INTO [{target_schema}].[{target_name}] ({insert_cols})\n"
        + "\nUNION ALL\n".join(sub_selects)
    )
    result.sql_executed = sql
    log("info", f"Execution d'une requete UNION ALL combinant {len(sub_selects)} table(s) source en une seule insertion.")

    try:
        with engine.begin() as conn:
            conn.execute(text(sql))
    except Exception as e:
        log("error", f"ERREUR lors de l'execution de la fusion : {e}")
        result.errors.append(("UNION ALL", str(e)))
        result.elapsed_seconds = time.perf_counter() - t_start
        return result

    for type_tpa, table_source, nb in tables_incluses:
        label_source_tpa = _label_source_tpa(type_tpa, table_source)
        result.tpa_results[f"{label_source_tpa} ({table_source})"] = nb
        result.total_rows += nb
        log("info", f"  [{label_source_tpa}] {nb} ligne(s) fusionnee(s) depuis {table_source}")

    result.elapsed_seconds = time.perf_counter() - t_start
    if result.errors:
        log("warning", f"Fusion terminee avec {len(result.errors)} erreur(s) pour le domaine {domaine}.")
    else:
        log("info", f"Fusion terminee pour {domaine} : {result.total_rows} ligne(s) au total en {result.elapsed_seconds:.1f}s.")

    return result


def detect_new_values(
    engine: Engine,
    rules: list[MatchingRule],
    domaine: str,
    colonne_cible: str,
    manager: ValueAliasManager,
    log_cb: Optional[LogCallback] = None,
) -> int:
    """
    V151 : scanne TOUTES les tables source actuellement mappees vers
    `colonne_cible` pour ce domaine (ex: Pays_Client), et ajoute en
    PROPOSITION (jamais appliquee automatiquement — voir
    ValueAliasManager.add_proposition) toute valeur distincte, non vide,
    pas deja couverte par une correspondance confirmee ou deja proposee.

    Lecture seule (aucune ecriture en base) : seules des requetes
    SELECT DISTINCT sont executees. Retourne le nombre de nouvelles
    propositions ajoutees au referentiel.
    """
    def log(level: str, msg: str):
        if log_cb:
            log_cb(level, msg)

    # Comparaison insensible a la casse (voir _cle_colonne) : une regle dont
    # la colonne cible ne differe que par la casse (ex: 'Pays_client' au
    # lieu de 'Pays_Client') doit quand meme etre detectee ici.
    pertinentes = [r for r in rules if r.domaine == domaine and _cle_colonne(r.colonne_cible) == _cle_colonne(colonne_cible)]
    if not pertinentes:
        log("info", f"Aucune table source mappee vers '{colonne_cible}' pour le domaine {domaine}.")
        return 0

    nb_ajoutees = 0
    tables_vues: set[tuple[str, str]] = set()
    for r in pertinentes:
        cle_table = (r.table_source, r.colonne_source)
        if cle_table in tables_vues:
            continue  # une meme paire (table, colonne source) deja scannee
        tables_vues.add(cle_table)

        schema, name = _split_schema_table(r.table_source)
        cols = get_existing_columns(engine, schema, name)
        if cols is None:
            log("warning", f"Table source introuvable, ignoree pour la detection : {r.table_source}")
            continue
        # V158 : meme resolveur insensible a la casse/accents que dans
        # run_merge, pour ne pas rater une colonne pour les memes raisons.
        source_reelle = _resolveur_colonnes_sources(cols).get(_cle_source(r.colonne_source))
        if source_reelle is None:
            continue

        sql = (
            f"SELECT DISTINCT [{source_reelle}] FROM [{schema}].[{name}] "
            f"WHERE [{source_reelle}] IS NOT NULL AND LTRIM(RTRIM([{source_reelle}])) <> ''"
        )
        try:
            with engine.connect() as conn:
                rows = conn.execute(text(sql)).fetchall()
        except Exception as e:
            log("warning", f"Echec de lecture des valeurs distinctes de {r.table_source}.{source_reelle} : {e}")
            continue

        for row in rows:
            if row[0] is None:
                continue  # filet de securite : le WHERE SQL exclut deja les NULL, defense en profondeur ici
            valeur = str(row[0]).strip()
            if not valeur or manager.is_known(colonne_cible, valeur):
                continue
            manager.add_proposition(colonne_cible, valeur)
            nb_ajoutees += 1

    log("info", f"Detection terminee pour '{colonne_cible}' : {nb_ajoutees} nouvelle(s) valeur(s) proposee(s).")
    return nb_ajoutees

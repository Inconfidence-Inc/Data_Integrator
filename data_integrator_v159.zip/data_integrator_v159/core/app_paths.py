"""
app_paths.py
-------------
Resout un emplacement STABLE, hors du dossier d'installation de
l'application, pour tous les fichiers de configuration utilisateur
(connexions, mapping Fusion, dictionnaire EN/FR, historique, etc.) — V94.

Probleme corrige : jusqu'ici, chaque fichier de configuration etait stocke
dans <dossier_de_l_application>/config/, c'est-a-dire A L'INTERIEUR du
dossier livre a chaque nouvelle version. Quand l'utilisateur extrayait une
nouvelle version dans un NOUVEAU dossier (sans recopier manuellement son
ancien dossier config/ par-dessus), toute sa configuration reelle (serveur,
mot de passe, mapping construit avec soin...) etait silencieusement
remplacee par les valeurs par defaut livrees avec le code.

Desormais, tout est stocke dans un repertoire specifique a l'utilisateur
(%APPDATA%\\DataIntegrator sous Windows, ~/Library/Application Support sous
macOS, ~/.config sous Linux), totalement independant du dossier ou
l'application est extraite/installee : une nouvelle version peut etre
extraite n'importe ou, la configuration reelle survit toujours.

Migration automatique et silencieuse, une seule fois : si un fichier existe
encore a l'ancien emplacement (dossier de l'application) mais pas au nouvel
emplacement stable, il est copie automatiquement au demarrage.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

APP_FOLDER_NAME = "DataIntegrator"

# Ancien emplacement (V1 a V93) : a l'interieur du dossier de l'application,
# vulnerable a un remplacement a chaque nouvelle version extraite.
_LEGACY_CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"


def get_user_data_dir() -> Path:
    """Repertoire stable, specifique a l'utilisateur, pour toute la
    configuration de l'application — jamais affecte par une mise a jour
    du code applicatif lui-meme."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or str(Path.home())
    elif sys.platform == "darwin":
        base = str(Path.home() / "Library" / "Application Support")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    directory = Path(base) / APP_FOLDER_NAME / "config"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def resolve_config_path(filename: str) -> Path:
    """
    Retourne le chemin stable pour un fichier de configuration donne, en
    migrant automatiquement (une seule fois, silencieusement) une version
    preexistante trouvee a l'ancien emplacement (dossier de l'application)
    si le nouvel emplacement stable ne contient pas encore ce fichier.
    """
    new_dir = get_user_data_dir()
    new_path = new_dir / filename
    if not new_path.exists():
        legacy_path = _LEGACY_CONFIG_DIR / filename
        if legacy_path.exists():
            try:
                shutil.copy(str(legacy_path), str(new_path))
            except Exception:
                pass  # migration best-effort : jamais bloquant au demarrage
    return new_path


def backfill_key_if_empty(stable_path: Path, filename: str, key: str) -> None:
    """
    Filet de securite (V99, corrige en V100 apres un vrai risque trouve) :
    un utilisateur ayant deja lance une version anterieure (V94-V97) sans
    contenu reel (config/ absent du zip a l'epoque) se retrouvait avec un
    fichier VIDE mais EXISTANT au nouvel emplacement stable — ce qui
    bloquait a tort resolve_config_path() (qui ne verifie que l'existence
    du fichier, pas son contenu) de jamais migrer les valeurs par defaut
    fournies avec une version plus recente.

    CORRECTIF IMPORTANT (V100) : la toute premiere version de ce filet de
    securite copiait le fichier LEGACY EN ENTIER par-dessus le fichier
    stable des qu'UNE seule cle (ex: "sources") etait vide — ecrasant au
    passage silencieusement d'AUTRES cles du meme fichier qui, elles,
    pouvaient deja contenir un vrai travail personnalise (ex: les profils
    de connexion et leurs mots de passe, stockes dans le meme fichier que
    les sources). Corrige en V100 : seule la cle CONCERNEE est completee,
    jamais les autres, quel que soit leur contenu."""
    legacy_path = _LEGACY_CONFIG_DIR / filename
    if not legacy_path.exists() or not stable_path.exists():
        return
    try:
        stable_data = json.loads(stable_path.read_text(encoding="utf-8"))
        legacy_data = json.loads(legacy_path.read_text(encoding="utf-8"))
    except Exception:
        return

    if stable_data.get(key) or not legacy_data.get(key):
        return  # rien a completer : deja rempli, ou le legacy n'a rien de mieux

    stable_data[key] = legacy_data[key]
    try:
        stable_path.write_text(json.dumps(stable_data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass  # best-effort, jamais bloquant


def ensure_all_default_sources_present(stable_path: Path, filename: str = "sources.json") -> int:
    """
    V132, sur demande explicite de l'utilisateur (\"je dois avoir par
    defaut tous mes TPA dans ces fenetres deja parametres\") : complement
    de backfill_key_if_empty, qui ne comble que si la liste \"sources\" est
    ENTIEREMENT vide. Un utilisateur ayant deja une liste partielle (par
    exemple 4 TPA configures manuellement sur 9 attendus, chacun avec son
    propre chemin de dossier reel) ne recevait jamais les TPA manquants,
    puisque la liste n'etait pas consideree \"vide\".

    Cette fonction verifie individuellement chaque source (domaine, pays,
    type) fournie par defaut avec l'application : si cette combinaison
    precise est ABSENTE de la liste actuelle de l'utilisateur, elle est
    ajoutee telle quelle (chemin de dossier par defaut, a adapter par
    l'utilisateur si besoin) ; si elle existe deja (meme avec un chemin
    de dossier personnalise et different), elle n'est JAMAIS modifiee ni
    dupliquee. Retourne le nombre de sources ajoutees."""
    legacy_path = _LEGACY_CONFIG_DIR / filename
    if not legacy_path.exists() or not stable_path.exists():
        return 0
    try:
        stable_data = json.loads(stable_path.read_text(encoding="utf-8"))
        legacy_data = json.loads(legacy_path.read_text(encoding="utf-8"))
    except Exception:
        return 0

    sources_actuelles = stable_data.get("sources", [])
    sources_par_defaut = legacy_data.get("sources", [])
    cles_existantes = {(s.get("domaine"), s.get("pays"), s.get("type")) for s in sources_actuelles}

    ajouts = [
        s for s in sources_par_defaut
        if (s.get("domaine"), s.get("pays"), s.get("type")) not in cles_existantes
    ]
    if not ajouts:
        return 0

    stable_data["sources"] = sources_actuelles + ajouts
    try:
        stable_path.write_text(json.dumps(stable_data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        return 0
    return len(ajouts)


def sync_generated_config_if_newer(stable_path: Path, filename: str, log_cb=None) -> bool:
    """
    V141, en reponse a une friction recurrente constatee en usage reel :
    matching.json, column_aliases.json et target_schemas.json sont des
    fichiers essentiellement GENERES par le travail de construction du
    mapping (pas des reglages personnels comme sources.json ou les
    connexions, qui restent geres par backfill_key_if_empty /
    ensure_all_default_sources_present et ne sont JAMAIS touches ici).
    Sans synchronisation automatique, chaque amelioration du mapping
    livree avec une nouvelle version de l'application necessitait une
    suppression manuelle du dossier de configuration stable pour prendre
    effet — source d'incomprehension repetee (un mapping deja corrige
    cote application semblait "ne pas marcher" alors qu'il s'agissait
    simplement d'un fichier local non rafraichi).

    Chacun des 3 fichiers porte un champ "_version" (entier, incremente a
    chaque mise a jour du mapping). Si la version fournie avec
    l'application (legacy) est STRICTEMENT SUPERIEURE a celle du fichier
    stable actuel, ce dernier est integralement remplace par la version
    fournie. Retourne True si une synchronisation a eu lieu.

    V142 (diagnostic) : trace explicitement chaque etape dans la console
    (via log_cb, optionnel) — un cas reel rencontre ou la synchronisation
    ne semblait pas s'effectuer n'a pas pu etre explique par la seule
    relecture du code ; ces traces permettront de voir precisement,
    directement dans les journaux de l'utilisateur, ou le mecanisme
    s'arrete reellement (fichier legacy introuvable, exception de lecture,
    versions comparees, echec d'ecriture...)."""
    def log(msg):
        if log_cb:
            log_cb("info", f"[sync {filename}] {msg}")

    legacy_path = _LEGACY_CONFIG_DIR / filename
    log(f"chemin legacy (bundle) = {legacy_path} — existe: {legacy_path.exists()}")
    if not legacy_path.exists():
        log("ARRET : fichier legacy introuvable a cet emplacement, synchronisation impossible.")
        return False
    try:
        legacy_data = json.loads(legacy_path.read_text(encoding="utf-8"))
    except Exception as e:
        log(f"ARRET : echec de lecture du fichier legacy ({e!r}).")
        return False
    version_legacy = legacy_data.get("_version", 0)

    log(f"chemin stable = {stable_path} — existe: {stable_path.exists()}")
    version_stable = 0
    if stable_path.exists():
        try:
            stable_data = json.loads(stable_path.read_text(encoding="utf-8"))
            version_stable = stable_data.get("_version", 0)
        except Exception as e:
            log(f"lecture du fichier stable echouee ({e!r}), version consideree comme 0.")
            version_stable = 0

    log(f"version legacy = {version_legacy}, version stable = {version_stable}")
    if version_legacy <= version_stable:
        log("ARRET : la version stable est deja a jour (ou plus recente), aucune synchronisation necessaire.")
        return False

    try:
        stable_path.parent.mkdir(parents=True, exist_ok=True)
        stable_path.write_text(json.dumps(legacy_data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        log(f"ARRET : echec d'ecriture du fichier stable ({e!r}).")
        return False
    log(f"SYNCHRONISATION EFFECTUEE avec succes (version {version_stable} -> {version_legacy}).")
    return True

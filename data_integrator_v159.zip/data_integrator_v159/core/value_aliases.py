"""
value_aliases.py
------------------
Dictionnaire persistant de normalisation de VALEURS pour une colonne cible
donnee (ex: Pays_Client), utilise pendant la Fusion pour harmoniser des
saisies libres incoherentes (V151 — ex: "Fr", "FR", "France" doivent tous
etre ecrits "France" dans la table consolidee).

Different du dictionnaire de colonnes (core/column_aliases.py), qui associe
des NOMS DE COLONNES entre eux : celui-ci associe des VALEURS DE DONNEES
(contenu reel des cellules) a une valeur canonique, pour une colonne cible
precise. Applique automatiquement cote serveur dans le SQL de fusion
(core/merge_engine.py), via une expression CASE WHEN injectee directement
dans le SELECT de chaque table source — coherent avec l'architecture
UNION ALL de la fusion (une seule requete combinee, aucun traitement ligne
par ligne en Python).

Deux listes, sur le meme principe que column_aliases.py :
 - valeurs       : correspondances CONFIRMEES, appliquees automatiquement.
 - propositions  : valeurs distinctes rencontrees dans les tables sources
                   (via detect_new_values(), dans merge_engine.py) et pas
                   encore reconnues — jamais appliquees tant que non
                   acceptees, pour ne jamais fausser une donnee sur une
                   simple supposition.

Une variante NON reconnue traverse toujours INCHANGEE (jamais videe ni
remplacee par une valeur par defaut) : l'absence de correspondance
confirmee ne doit jamais faire perdre une donnee reelle.
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import asdict, dataclass
from pathlib import Path

from core.app_paths import resolve_config_path

DEFAULT_PATH = resolve_config_path("value_aliases.json")


def _normalize_key(value: str) -> str:
    """Meme logique de normalisation que column_aliases._normalize_key,
    dupliquee ici pour les memes raisons (pas de dependance circulaire) :
    casse, espaces, accents et ponctuation ignores."""
    sans_accents = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]", "", sans_accents.lower())


@dataclass
class ValueAlias:
    colonne_cible: str       # colonne cible concernee, ex: 'Pays_Client'
    variante: str            # valeur brute telle que rencontree, ex: 'Fr', 'FR'
    valeur_canonique: str    # valeur harmonisee a ecrire en base, ex: 'France'


class ValueAliasManager:
    def __init__(self, path: Path | str = DEFAULT_PATH, log_cb=None):
        self.path = Path(path)
        self.log_cb = log_cb
        self.valeurs: list[ValueAlias] = []
        self.propositions: list[ValueAlias] = []
        self._version = 0
        self.load()

    def load(self) -> None:
        # Meme mecanisme que les 3 autres fichiers "generes" (V141) :
        # synchronise integralement ce fichier si une version plus recente
        # du referentiel est fournie avec l'application.
        from core.app_paths import sync_generated_config_if_newer
        sync_generated_config_if_newer(self.path, "value_aliases.json", self.log_cb)

        if not self.path.exists():
            self.valeurs = []
            self.propositions = []
            self._version = 0
            return

        from core.app_paths import backfill_key_if_empty
        backfill_key_if_empty(self.path, "value_aliases.json", "valeurs")

        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.valeurs = [ValueAlias(**v) for v in data.get("valeurs", [])]
            self.propositions = [ValueAlias(**v) for v in data.get("propositions", [])]
            self._version = data.get("_version", 0)
        except Exception:
            self.valeurs = []
            self.propositions = []
            self._version = 0

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "valeurs": [asdict(v) for v in self.valeurs],
            "propositions": [asdict(v) for v in self.propositions],
            "_version": getattr(self, "_version", 0),  # preserve tel quel a la sauvegarde locale
        }
        self.path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    @staticmethod
    def _key(colonne_cible: str, variante: str) -> tuple[str, str]:
        return (_normalize_key(colonne_cible), _normalize_key(variante))

    def for_column(self, colonne_cible: str) -> list[ValueAlias]:
        cle = _normalize_key(colonne_cible)
        return [v for v in self.valeurs if _normalize_key(v.colonne_cible) == cle]

    def propositions_for_column(self, colonne_cible: str) -> list[ValueAlias]:
        cle = _normalize_key(colonne_cible)
        return [p for p in self.propositions if _normalize_key(p.colonne_cible) == cle]

    def columns_with_aliases(self) -> list[str]:
        """Colonnes cible pour lesquelles au moins une correspondance
        confirmee existe — permet a merge_engine de ne construire une
        expression CASE que lorsque c'est utile."""
        vues: list[str] = []
        for v in self.valeurs:
            if v.colonne_cible not in vues:
                vues.append(v.colonne_cible)
        return vues

    def is_known(self, colonne_cible: str, valeur: str) -> bool:
        """True si cette variante (pour cette colonne cible) est deja
        confirmee OU deja proposee — utilise par detect_new_values() pour
        ne jamais proposer deux fois la meme valeur."""
        cle = self._key(colonne_cible, valeur)
        return any(self._key(v.colonne_cible, v.variante) == cle for v in self.valeurs) or \
            any(self._key(p.colonne_cible, p.variante) == cle for p in self.propositions)

    def add(self, colonne_cible: str, variante: str, valeur_canonique: str) -> None:
        colonne_cible, variante, valeur_canonique = colonne_cible.strip(), variante.strip(), valeur_canonique.strip()
        if not colonne_cible or not variante or not valeur_canonique:
            return
        cle = self._key(colonne_cible, variante)
        self.valeurs = [v for v in self.valeurs if self._key(v.colonne_cible, v.variante) != cle]
        self.valeurs.append(ValueAlias(colonne_cible=colonne_cible, variante=variante, valeur_canonique=valeur_canonique))
        # une variante confirmee ne doit plus trainer en proposition
        self.propositions = [p for p in self.propositions if self._key(p.colonne_cible, p.variante) != cle]
        self.save()

    def remove(self, colonne_cible: str, variante: str) -> None:
        cle = self._key(colonne_cible, variante)
        self.valeurs = [v for v in self.valeurs if self._key(v.colonne_cible, v.variante) != cle]
        self.save()

    def add_proposition(self, colonne_cible: str, variante: str, valeur_canonique_suggeree: str = "") -> None:
        """Ajoute une variante NON reconnue, rencontree dans une table
        source (V151 — voir detect_new_values dans merge_engine.py), comme
        suggestion a verifier — jamais utilisee par resolve()/
        sql_case_expression() tant qu'elle n'a pas ete explicitement
        acceptee."""
        colonne_cible, variante = colonne_cible.strip(), variante.strip()
        if not colonne_cible or not variante:
            return
        if self.is_known(colonne_cible, variante):
            return
        self.propositions.append(
            ValueAlias(colonne_cible=colonne_cible, variante=variante, valeur_canonique=valeur_canonique_suggeree.strip())
        )
        self.save()

    def accept_proposition(self, colonne_cible: str, variante: str, valeur_canonique: str | None = None) -> None:
        cle = self._key(colonne_cible, variante)
        prop = next((p for p in self.propositions if self._key(p.colonne_cible, p.variante) == cle), None)
        if not prop:
            return
        canon = (valeur_canonique if valeur_canonique is not None else prop.valeur_canonique).strip()
        if not canon:
            return  # pas de valeur canonique renseignee : on ne peut pas confirmer sans savoir vers quoi normaliser
        self.add(prop.colonne_cible, prop.variante, canon)  # add() retire deja la proposition et sauvegarde

    def reject_proposition(self, colonne_cible: str, variante: str) -> None:
        cle = self._key(colonne_cible, variante)
        self.propositions = [p for p in self.propositions if self._key(p.colonne_cible, p.variante) != cle]
        self.save()

    def resolve(self, colonne_cible: str, valeur: str) -> str | None:
        """Retourne la valeur canonique CONFIRMEE pour cette variante dans
        cette colonne cible (comparaison normalisee : casse/espaces/accents
        ignores), ou None si aucune correspondance confirmee n'existe — la
        valeur d'origine doit alors rester inchangee."""
        cle = self._key(colonne_cible, valeur)
        for v in self.valeurs:
            if self._key(v.colonne_cible, v.variante) == cle:
                return v.valeur_canonique
        return None

    def sql_case_expression(self, colonne_cible: str, expr_sql: str) -> str:
        """Enveloppe l'expression SQL `expr_sql` (deja construite pour la
        colonne cible donnee, cote source) dans un CASE WHEN qui harmonise
        les variantes confirmees vers leur valeur canonique. Comparaison
        insensible a la casse et aux espaces de part et d'autre (UPPER +
        LTRIM/RTRIM), executee cote serveur, conformement a l'architecture
        UNION ALL de la fusion (une seule requete, aucun traitement ligne
        par ligne en Python — voir core/merge_engine.py). Toute valeur non
        reconnue traverse INCHANGEE (ELSE expr_sql) : jamais de perte de
        donnee sur une variante pas encore cataloguee."""
        regles = self.for_column(colonne_cible)
        if not regles:
            return expr_sql
        # V152, suite a un cas reel trouve par l'utilisateur (Pays_Client
        # contenant a la fois "España" avec tilde et "ESPANA" sans) : la
        # comparaison SQL doit etre insensible aux ACCENTS, pas seulement a
        # la casse. UPPER() seul ne suffit pas (il ne retire pas les signes
        # diacritiques, contrairement a la normalisation Python utilisee
        # ailleurs dans ce fichier). COLLATE Latin1_General_CI_AI (Case
        # Insensitive, Accent Insensitive) resout cela cote serveur, quelle
        # que soit la collation par defaut de la base — sans avoir besoin
        # de cataloguer separement chaque variante accentuee/non accentuee
        # du meme mot.
        whens = []
        for v in regles:
            variante_sql = v.variante.strip().upper().replace("'", "''")
            canon_sql = v.valeur_canonique.replace("'", "''")
            whens.append(
                f"WHEN UPPER(LTRIM(RTRIM({expr_sql}))) COLLATE Latin1_General_CI_AI = '{variante_sql}' THEN '{canon_sql}'"
            )
        return "(CASE " + " ".join(whens) + f" ELSE {expr_sql} END)"

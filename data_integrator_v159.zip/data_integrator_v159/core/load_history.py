"""
load_history.py
-----------------
Historique persistant des chargements, pour l'ecran statistique (V59) :
a chaque chargement d'une source (reussi ou partiel), une entree est
enregistree avec la date, le domaine, le TPA, le pays, la table cible, le
nombre de lignes recues (lues dans les fichiers) et le nombre de lignes
integrees (effectivement inserees en base).

Cet historique demarre vide a la premiere utilisation de cette version :
les 3 mois glissants de l'ecran statistique se remplissent progressivement
au fil des chargements reels, il n'y a pas de donnees retroactives
disponibles pour les chargements effectues avant l'introduction de ce
suivi.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from pathlib import Path


@dataclass
class LoadHistoryEntry:
    id: str
    timestamp: str  # format ISO, ex: 2026-08-10T14:32:05
    domaine: str
    pays: str
    type_tpa: str
    table: str
    nb_lignes_recues: int
    nb_lignes_integrees: int

    @property
    def date(self) -> datetime:
        return datetime.fromisoformat(self.timestamp)


class LoadHistoryManager:
    def __init__(self, path: str | Path | None = None):
        from core.app_paths import resolve_config_path
        self.path = Path(path) if path is not None else resolve_config_path("load_history.json")
        self.entries: list[LoadHistoryEntry] = []
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            self.entries = []
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.entries = [LoadHistoryEntry(**e) for e in data.get("entries", [])]
        except Exception:
            self.entries = []

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"entries": [asdict(e) for e in self.entries]}
        self.path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def record(
        self, domaine: str, pays: str, type_tpa: str, table: str,
        nb_lignes_recues: int, nb_lignes_integrees: int,
    ) -> LoadHistoryEntry:
        entry = LoadHistoryEntry(
            id=uuid.uuid4().hex[:8],
            timestamp=datetime.now().isoformat(timespec="seconds"),
            domaine=domaine, pays=pays, type_tpa=type_tpa, table=table,
            nb_lignes_recues=nb_lignes_recues, nb_lignes_integrees=nb_lignes_integrees,
        )
        self.entries.append(entry)
        self.save()
        return entry

    def entries_since(self, since: datetime) -> list[LoadHistoryEntry]:
        return [e for e in self.entries if e.date >= since]

    def entries_last_n_months(self, n: int = 3) -> list[LoadHistoryEntry]:
        cutoff = datetime.now() - timedelta(days=30 * n)
        return self.entries_since(cutoff)

    def entries_for_domain(self, domaine: str, n_months: int = 3) -> list[LoadHistoryEntry]:
        return [e for e in self.entries_last_n_months(n_months) if e.domaine == domaine]

    def has_been_loaded(self, table: str) -> bool:
        """Indique si cette table cible a deja ete chargee avec succes au
        moins une fois (sans limite de 3 mois, contrairement aux methodes
        ci-dessus qui servent a l'ecran statistique) — utilise par le
        prechargement Fusion (V75) pour distinguer les sources deja
        chargees des sources encore jamais chargees."""
        return any(e.table == table for e in self.entries)
